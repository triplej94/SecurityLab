# SecurityLab development

Work in a separate development directory. Treat the Desktop DSC and IQ Documentation Repository as read-only. Build runtime assets from original geometry or sources with suitable distribution permission.

Use one deterministic equipment state across the bench, controls, diagnostic readouts and assessment. Render a physical component from that state. Validate conductor connections by endpoint and terminal identity. Keep battery power, external supply, data continuity and enrollment separate. A simulator repair must change the same state that produced the original fault.

Add a page-level reference for every scored technical rule. Record the panel model, firmware and region when applicable. Record approximations explicitly. The local technical verification record explains the current evidence and its limits.

Test physical actions through their ordinary user interface, including wrong and corrected configurations, reload, reset and independent profiles. Verify the production build on its private ChatGPT Sites URL. Record hosted limitations and test results separately from local test results.

Deploy approved runtime models and the public evidence index. Keep restricted research files, extracted pages, private register paths, test data containing user details and credentials out of both hosted source and runtime assets. Connect solely to the local simulation.
