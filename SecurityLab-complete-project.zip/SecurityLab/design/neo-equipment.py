"""Author and export original illustrative Neo teaching assets. Run with Blender -b -P this-file."""
from pathlib import Path
import bpy, math, random
from mathutils import Matrix
from collections import defaultdict
root=Path(__file__).resolve().parents[1]
bpy.ops.wm.read_factory_settings(use_empty=True)
rng=random.Random(2032)
scene=bpy.context.scene
def material(name, rgb, metal=0, rough=.45):
    m=bpy.data.materials.new(name); m.diffuse_color=(*rgb,1);m.use_nodes=True
    p=m.node_tree.nodes.get("Principled BSDF");p.inputs["Base Color"].default_value=(*rgb,1);p.inputs["Metallic"].default_value=metal;p.inputs["Roughness"].default_value=rough
    return m
blue=material('Cerulean solder mask',(.008,.097,.16),.22)
mask=material('Tin over copper traces',(.043,.23,.28),.40)
silk=material('Silkscreen ink',(.82,.86,.76))
tin=material('Solder and zinc',(.54,.57,.55),.69,.33)
steel=material('Galvanized steel',(.55,.57,.53),.48,.47)
stamped=material('Stamped dimples',(.26,.30,.29),.58)
ivory=material('Screw clamp polymer',(.79,.82,.76))
poly=material('Keypad housing',(.88,.87,.82),.03,.36)
seam=material('Keypad backplate',(.49,.51,.47))
ink=material('Graphite printing',(.035,.048,.05))
ic=material('Semiconductor package',(.025,.035,.038))
brown=material('Ceramic dielectric',(.44,.28,.12))
gold=material('Bare metal pad',(.60,.37,.11),.58)
cyan=material('Anodised capacitor can',(.018,.27,.42),.6,.31)
lcd=material('LCD surround',(.16,.24,.25))
copper=material('Brass terminal cage',(.45,.32,.13),.66)
parts=[]
def obj(name,mesh,m,pos):
 o=bpy.data.objects.new(name,mesh);scene.collection.objects.link(o);o.data.materials.clear();o.data.materials.append(m);o.location=(pos[0],-pos[2],pos[1]);parts.append(o);return o
def block(n,x,z,y,w,h,d,m,bevel=0):
 a=w/2;b=d/2;c=h/2
 mesh=bpy.data.meshes.new(n);mesh.from_pydata([(-a,-b,-c),(a,-b,-c),(a,b,-c),(-a,b,-c),(-a,-b,c),(a,-b,c),(a,b,c),(-a,b,c)],[],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)])
 o=obj(n,mesh,m,(x,z,y))
 if bevel:
  mod=o.modifiers.new('Mold radius','BEVEL');mod.width=bevel;mod.segments=4
  o.modifiers.new('Surface normals','WEIGHTED_NORMAL')
 return o
def cyl(n,x,z,y,r,d,m,sides=20):
 v=[(r*math.cos(i*math.tau/sides),yy,r*math.sin(i*math.tau/sides)) for yy in [-d/2,d/2] for i in range(sides)]
 f=[tuple(range(sides)),tuple(reversed(range(sides,2*sides)))]+[(i,i+sides,(i+1)%sides+sides,(i+1)%sides) for i in range(sides)]
 mesh=bpy.data.meshes.new(n);mesh.from_pydata(v,[],f);return obj(n,mesh,m,(x,z,y))
def stroke(n,x1,z1,x2,z2,width,y,m):
 o=block(n,(x1+x2)/2,(z1+z2)/2,y,math.hypot(x2-x1,z2-z1),width,.002,m);o.rotation_euler.y=-math.atan2(z2-z1,x2-x1)
def label(txt,x,z,y,sz,m=silk):
 data=bpy.data.curves.new(txt,'FONT');data.body=txt;data.size=sz;data.align_x='CENTER';data.resolution_u=2
 o=obj(txt,data,m,(x,z,y));o.rotation_euler.x=math.pi/2
def screw(x,z,y,r):
 cyl('Washer',x,z,y,r*1.24,.012,stamped)
 cyl('Zinc head',x,z,y+.013,r,.021,tin)
 for angle in (.45,.45+math.pi/2):
  o=block('Cross recess',x,z,y+.024,r*1.42,r*.20,.002,ink);o.rotation_euler.y=angle
def export(name):
 # Collapse draw calls by material. Keep editable procedural source here.
 bpy.context.view_layer.update()
 graph=bpy.context.evaluated_depsgraph_get()
 groups=defaultdict(lambda:[[],[]])
 for o in parts:
  eo=o.evaluated_get(graph);me=eo.to_mesh();v,f=groups[o.data.materials[0]];off=len(v)
  v.extend([tuple(o.matrix_world @ vert.co) for vert in me.vertices]);f.extend([tuple(i+off for i in poly.vertices) for poly in me.polygons]);eo.to_mesh_clear()
 for o in parts:bpy.data.objects.remove(o,do_unlink=True)
 parts.clear()
 meshes=[]
 for m,(v,f) in groups.items():
  mesh=bpy.data.meshes.new(name+' / '+m.name);mesh.from_pydata(v,[],f);mesh.update();o=bpy.data.objects.new(name+' / '+m.name,mesh);scene.collection.objects.link(o);mesh.materials.append(m);meshes.append(o)
 bpy.ops.export_scene.gltf(filepath=str(root/'public'/'assets'/(name+'.glb')),export_format='GLB',export_yup=True)
 for o in meshes:bpy.data.objects.remove(o,do_unlink=True)
# HS2032-style populated board; component geometry follows the local distributor photograph.
block('FR4',0,0,0,1.64,.90,.036,blue,.012)
for x in [-.765,.765]:
 for z in [-.395,.395]:
  cyl('Annular pad',x,z,.022,.035,.009,gold);cyl('Mounting hole',x,z,.028,.019,.004,ic)
for i in range(83):
 x=rng.uniform(-.72,.68);z=rng.uniform(-.31,.39);dx=rng.choice([-1,1])*rng.uniform(.03,.13);dz=rng.uniform(.015,.075)
 stroke('PCB trace',x,z,x+dx,z,.0025,.021,mask);stroke('PCB trace',x+dx,z,x+dx+.03,z+dz,.0025,.021,mask)
def chip(x,z,w,h,pins):
 block('IC package',x,z,.053,w,h,.057,ic,.009)
 for side in [-1,1]:
  for i in range(pins):
   block('Gull wing lead',x+side*(w/2+.009),z+h*((i+.5)/pins-.5),.042,.023,h/(pins*1.9),.013,tin)
 cyl('Index mark',x-w*.3,z+h*.28,.084,.006,.003,stamped)
for x,z,w,h,n in [(.13,.13,.17,.16,11),(-.20,.10,.15,.067,6),(-.5,.25,.12,.069,5),(.5,.23,.105,.075,5),(-.42,-.075,.105,.083,5),(.48,-.06,.09,.066,4),(-.56,.03,.115,.115,4),(.69,.35,.085,.078,5)]:chip(x,z,w,h,n)
for i in range(110):
 x=rng.uniform(-.74,.74);z=rng.uniform(-.25,.4)
 if (-.78<x<-.37 and -.29<z<-.03) or any(abs(x-a)<.11 and abs(z-b)<.1 for a,b in [(.13,.13),(-.20,.1),(-.5,.25),(.5,.23)]):continue
 w=rng.uniform(.019,.041);h=w*.46
 block('SMD solder pads',x,z,.026,w*1.27,h,.009,tin);block('SMD body',x,z,.035,w*.71,h*.97,.014,rng.choice([ic,brown]))
for x,z,r in [(-.65,-.17,.095),(-.45,-.16,.078),(-.66,.2,.044),(-.48,.34,.034),(.72,.11,.033)]:
 cyl('Can sleeve',x,z,.095,r,.137,cyan);cyl('Crimped rim',x,z,.164,r*.94,.009,tin);cyl('Top',x,z,.171,r*.84,.009,tin)
 for a in (0,2.1,4.2):stroke('Pressure score',x,z,x+r*.57*math.cos(a),z+r*.57*math.sin(a),r*.043,.178,stamped)
for x,z in [(.31,.16),(.57,-.12),(-.67,-.30)]:
 block('Pin header',x,z,.068,.12,.062,.08,ivory,.007);block('Keyway',x,z,.111,.085,.036,.004,ic)
 for i in range(4):block('Header pin',x-.032+i*.021,z,.116,.007,.014,.009,gold)
for i in range(22):
 x=-.696+i*.066
 block('Peripheral terminal',x,-.355,.062,.064,.112,.075,ivory,.005);cyl('Clamp screw',x,-.33,.104,.019,.011,tin)
 stroke('Screw slot',x-.012,-.334,x+.012,-.326,.004,.112,ink);block('Wire aperture',x,-.38,.103,.039,.022,.003,ink)
label('HS2032',-.09,.315,.024,.048);label('DSC',-.025,-.15,.024,.048);label('CORBUS',.42,-.26,.024,.03)
export('neo-hs2032-board')
# Sheet metal cabinet with folded edges, embossed knockouts and standoffs.
block('Backpan',0,0,0,1.88,1.62,.045,steel,.02)
for x in [-.918,.918]:block('Side flange',x,0,.10,.046,1.61,.20,steel,.009)
for z in [-.789,.789]:block('Return lip',0,z,.10,1.84,.044,.20,steel,.008)
for x in [-.78,-.49,-.2,.09,.38,.67]:
 for z in [-.66,.66]:
  cyl('Knockout score',x,z,.026,.079,.006,stamped);cyl('Knockout disc',x,z,.030,.069,.004,steel)
for x in [-.78,.78]:
 for z in [-.48,.48]:
  cyl('Spacer',x,z,.06,.032,.06,ivory);screw(x,z,.092,.02)
export('neo-cabinet')
# Exposed keypad with shallow rounded case and buttons arranged from guide cover.
block('Wall plate',0,0,.015,1.47,1.035,.075,seam,.034)
face=block('Bowed keypad face',0,0,.078,1.45,1.02,.14,poly,.067)
for v in face.data.vertices:
 if v.co.z>0:v.co.x*=.945
for z in [-.495,-.487]:stroke('Lower molding seam',-.55,z,.55,z,.004,.14,seam)
block('Keywell',0,-.173,.137,1.26,.53,.012,ivory,.005)
block('Screen seal',-.055,.265,.138,.95,.282,.015,lcd,.006)
block('Lens',-.055,.265,.149,.912,.245,.009,lcd,.004)
for i,z in enumerate([.355,.297,.239,.181]):
 cyl('Indicator light pipe',.505,z,.151,.015,.013,seam)
 label(['✓','●','△','~'][i],.56,z-.012,.153,.034,ink)
block('Speaker slot',-.04,.069,.143,.41,.015,.006,seam,.002)
digits='123456789*0#'
for i,key in enumerate(digits):
 x=-.16+(i%3)*.151;z=-.01-(i//3)*.112
 block('Number key',x,z,.156,.139,.086,.034,poly,.025)
 label(key,x,z-.019,.175,.055,ink)
for col,x in enumerate([-.506,-.385,.42]):
 for i in range(5 if col==2 else 4):
  z=-.01-(.086 if col==2 else .112)*i;block('Function key',x,z,.154,.17 if col==2 else .10,.078,.03,poly,.023)
  label((['<','A','B','C'] if col==0 else ['>','+','-','o'] if col==1 else ['⌂','↗','☼','↺','×'])[i],x,z-.014,.173,.043,ink)
label('DSC',-.57,-.454,.137,.044,seam);label('PowerSeries Neo',.36,-.454,.137,.028,seam)
export('neo-hs2lcd')
# Removable terminal detail, screw slot remains a separate interactive part at runtime.
block('Terminal molded housing',0,0,0,.21,.20,.11,ivory,.009)
cyl('Screw well',0,.029,.059,.045,.01,ink);cyl('Clamp head',0,.029,.069,.037,.013,tin)
block('Lower wire opening',0,-.061,.058,.12,.044,.006,ink,.002)
block('Contact plate',0,-.072,.062,.089,.01,.004,copper)
export('neo-corbus-clamp')
