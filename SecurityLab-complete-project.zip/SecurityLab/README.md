# SecurityLab

A desktop browser workbench for the North American Qolsys IQ Panel 5 and DSC PowerSeries Neo HS2032. Each virtual job has its own saved equipment configuration and event history. Use the inventory and equipment controls alongside the scene. Drag empty space to orbit, scroll to zoom, and choose Fit view to return to the bench. The equipment explorer opens original GLB models and searches technical references.

## Running the project
Install Node 20 or later, open this directory in a terminal, and run `npm ci` followed by `npm run dev`. Open the URL printed by Vite. Use `npm run build` for the static production bundle. Serve dist over HTTP. The independent calibration fixture is probe.html in development.

## Jobs
In the residential lab, unpack and mount the panel, connect its battery and adapter, power it up, program the PG9945, and align its magnet. Follow the guided inspector for the training credentials. In the commercial lab, place the equipment, prepare both cable ends, land and tighten each conductor, then power, enroll, and confirm the keypad. The keypad power supply and bus continuity are evaluated separately.

Learn mode provides context, Guided mode exposes objectives, Sandbox supports experiments and Assessment scores actual state. Use the commissioning report for an export of checks and recent actions. Browser storage restores the two benches on that browser profile and origin. Use separate browser profiles for independent learners on one machine. Undo history is limited to the current session and exercise. Reset applies to the active job.

## Project structure
- src/bench.ts handles orbit, picking and drag interaction.
- src/iq.ts and src/iqState.ts implement the residential equipment and panel.
- src/neo.ts and src/neo-engine.ts implement cable manipulation, circuit checks and keypad interaction.
- src/main.ts owns session state, history, persistence, reporting and lab selection.
- public/assets contains original models. public/evidence.json contains paraphrased, model-specific source references.
- docs contains the private source register, asset audit, verification and deployment notes.

Blender is used at design time. The editable IQ scene is included with the existing IQ Panel 5 Lab package. Cabinet, keypad, conductors and workbench assembly meshes are generated from the included TypeScript sources. Refer to the technical report for model fidelity and limitations.

## Motion detector and cable update
The IQ Panel 5 exercise now includes the PG9914 hallway detector. Mount it, open its cover, start Auto Learn Sensor, and press the detector's enrollment switch. Confirm the synthetic ID and program Hall Motion in Group 17. Close the cover before running the simulated walk test. The coverage wedge is an illustrative training view. Door and motion status are independent.

The PGP9914 and PG9924 are comparison devices in the Equipment Explorer, with manufacturer photos and datasheets. The Blender model generator is design/motion-models.py. The models approximate case details and optical surfaces.

On the Neo bench the cable follows the routing grip. A green terminal highlight indicates an available landing point for the prepared conductor. An orange highlight identifies a blocked drop. The inspector reports whether the end is free, inserted, or clamped.
