import * as THREE from 'three'
import type {RegisterPart} from './bench'
import {detail} from './visual'
import {initialIQ, iqChecks, installAction, contactClosed, moveDoor, placePart, labCode, zoneID, motionID, type IQ, type Placement} from './iqState'
export {initialIQ, iqChecks}

interface Context {
  register:RegisterPart;scene:THREE.Scene;state:IQ;mode:string;ui:HTMLElement;
  update:()=>void;action:(label:string,change:()=>void)=>void;say:(msg:string)=>void;
  hit:(obj:THREE.Object3D,fn:()=>void)=>void;
  drag:(obj:THREE.Object3D,move:(p:THREE.Vector3)=>void,end?:(p:THREE.Vector3)=>void,cancel?:()=>void)=>void;
  focus:(p:THREE.Vector3,span:number)=>void;
}
const processSteps=[
  ['box','Open equipment box'],['unpacked','Lift out IQ Panel 5'],['loose','Release locking screw'],
  ['plateOff','Remove SmartMount backplate'],['plateMounted','Mount backplate level'],
  ['battery','Seat battery connector'],['cable','Insert 12 V barrel plug'],
  ['seated','Latch panel on backplate'],['secured','Tighten locking screw'],
  ['adapter','Plug in supplied adapter'],['on','Hold side power button']
] as const
const nextStep=(s:IQ)=>processSteps.find(([key])=>!s[key])
const instruction=(s:IQ)=>nextStep(s)?.[1] || (s.transmitter!=='frame'?'Mount the transmitter on the fixed header near the latch.':s.magnet!=='aligned'?'Align the magnet on the moving door.':!s.zone?'Use Auto Learn and the PG9945 enroll switch. Program Front Door in group 10.':!s.testedClosed?'Open and close the door. Watch the named zone change.':!s.motionMounted?'Mount the PG9914 at the hallway target.':!s.motionZone?'Open Auto Learn Sensor and enroll the PG9914 as Hall Motion in group 17.':!s.motionTested?'Close the detector cover and walk across the hallway.':'Inspect the commissioning results.')
function nd<K extends keyof HTMLElementTagNameMap>(name:K,text='') {
  const e=document.createElement(name);e.textContent=text;return e
}
function button(parent:HTMLElement,title:string,fn:()=>void) {
  const b=nd('button',title);b.type='button';b.onclick=fn;parent.append(b);return b
}
function text(parent:HTMLElement,msg:string){parent.append(nd('p',msg))}
function field(parent:HTMLElement,title:string,input:HTMLElement){
  const l=nd('label',title);l.style.cssText='display:grid;gap:4px;margin:8px 0';l.append(input);parent.append(l)
}
function select(options:string[],value:string){
  const s=nd('select');for(const o of options)s.add(new Option(o,o));s.value=value;return s
}
function hold(parent:HTMLElement,title:string,ms:number,done:()=>void) {
  const b=nd('button',title); b.type='button'; parent.append(b)
  let timer:ReturnType<typeof setTimeout>|undefined
  const stop=()=>{clearTimeout(timer);timer=undefined;b.textContent=title}
  const start=()=>{if(timer)return;b.textContent='Holding…';timer=setTimeout(()=>{stop();if(b.isConnected)done()},ms)}
  b.onpointerdown=e=>{b.setPointerCapture(e.pointerId);start()};b.onpointerup=stop;b.onpointercancel=stop;b.onblur=stop
  b.onkeydown=e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();if(!e.repeat)start()}}
  b.onkeyup=e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();stop()}}
}
function lcdSurface(screen:string,title:string,caption:string) {
  const canvas=document.createElement('canvas');canvas.width=960;canvas.height=560
  const p=canvas.getContext('2d')!
  function rect(x:number,y:number,w:number,h:number,color:string){p.fillStyle=color;p.fillRect(x,y,w,h)}
  function print(t:string,x:number,y:number,size:number,color='#263a42',bold=false,max=900){
    p.fillStyle=color;p.font=(bold?'600 ':'')+size+'px "Segoe UI", sans-serif';p.textBaseline='middle';p.fillText(t,x,y,max)
  }
  rect(0,0,960,560,'#f7f9fa');rect(0,0,960,69,'#edf2f3');rect(0,66,960,3,'#b5c4c8')
  print('IQ Panel 5',24,34,29,'#284e59',true);print('Partition 1',411,34,27)
  print('⌄',890,32,45,'#385a62',true)
  if(screen==='home'){
    rect(33,102,457,369,'#ffffff');rect(505,102,427,369,'#ffffff')
    print('SECURITY',65,143,24,'#59777b',true);print('SENSORS',535,143,24,'#59777b',true)
    p.fillStyle='#58a776';p.beginPath();p.arc(130,277,61,0,Math.PI*2);p.fill()
    p.strokeStyle='white';p.lineWidth=10;p.beginPath();p.arc(139,266,18,Math.PI,0);p.lineTo(157,282);p.stroke();rect(105,271,44,33,'#ffffff')
    print('System',208,253,33,'#577468');print('Disarmed',208,301,46,'#397b56',true,248)
    const chunks=caption.split(' / ');print(chunks[0],537,242,38,'#244950',true,362)
    if(chunks.length>1)print(chunks[1],537,302,41,chunks[1]==='Closed'?'#397b56':'#ae5720',true)
  }else{
    print(title,42,151,54,'#244950',true,865);rect(42,211,876,120,'#e2eded');print(caption,78,271,43,'#254d51',true,804)
  }
  rect(0,505,960,55,'#e6ecee');print('Security',30,532,25,'#43646c',true)
  for(let i=0;i<3;i++){p.beginPath();p.fillStyle=i===0?'#33545a':'#acb9bc';p.arc(462+i*17,532,4,0,Math.PI*2);p.fill()}
  const map=new THREE.CanvasTexture(canvas);map.colorSpace=THREE.SRGBColorSpace
  return new THREE.Mesh(new THREE.PlaneGeometry(.919,.535),new THREE.MeshBasicMaterial({map,toneMapped:false}))
}
export function createIQ(c:Context) {
  const s=c.state, ui=c.ui
  const assessed=c.mode.toLowerCase()==='assessment'
  function apply(label:string,change:()=>void) {c.action(label,()=>{change();s.log.unshift(label);s.log.length=Math.min(s.log.length,32)})}
  function install(key:string) {
    const probe={...s};const error=installAction(probe,key)
    if(error){c.say(error);return}
    apply(processSteps.find(([k])=>k===key)![1],()=>installAction(s,key))
  }
  const inspect=(x:number,y:number,span:number)=>c.focus(new THREE.Vector3(x,y,0),span)
  const setScreen=(page:string)=>apply('Panel · '+page,()=>{s.screen=page;s.pin=''})
  function enroll(){
    if(!s.on||s.screen!=='learn'){c.say('Open Auto Learn Sensor on the powered panel first.');return}
    if(s.zone){c.say('This contact ID is already assigned to zone 1.');return}
    apply('Yellow enrollment LED · PowerG signal received',()=>{s.sensor='contact';s.screen='confirm'})
  }
  function enrollMotion(){
    if(!s.on||s.screen!=='learn'){c.say('Open Auto Learn Sensor on the powered panel first.');return}
    if(!s.motionCover){c.say('Open the detector cover to reach its enroll switch.');return}
    if(s.motionZone){c.say('This motion detector is already enrolled.');return}
    apply('PG9914 · PowerG signal received',()=>{s.sensor='motion';s.screen='confirm'})
  }
  function mountMotion(mounted:boolean){
    apply(mounted?'PG9914 mounted in hallway':'PG9914 returned to bench',()=>{
      s.motionMounted=mounted;s.motionDetected=false;s.motionTested=false;s.commissioned=false
    })
  }
  function walk(){
    if(!s.motionMounted||s.motionCover||!s.motionZone){c.say('Mount and enroll the detector, then close its cover to run the walk test.');return}
    apply(s.motionZone.name+(s.motionDetected?' · Idle':' · Motion detected'),()=>{
      s.motionDetected=!s.motionDetected
      if(s.motionDetected)s.motionTested=true
    })
  }
  const motionStatus=()=>s.motionCover?'Cover open':s.motionDetected?'Motion detected':'Idle'
  const place=(part:'transmitter'|'magnet',pos:Placement)=>{
    if(!s.box){c.say('Open the equipment box first.');return}
    apply((part==='magnet'?'Magnet':'Transmitter')+' · '+pos,()=>placePart(s,part,pos))
  }
  const toggleDoor=()=>{const probe={...s};apply(moveDoor(probe),()=>moveDoor(s))}
  const mat=(color:number,metalness=0)=>new THREE.MeshStandardMaterial({color,metalness,roughness:.6})
  function slab(parent:THREE.Object3D,name:string,x:number,y:number,z:number,w:number,h:number,d:number,col:number,m=0) {
    const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(col,m));o.name=name;o.position.set(x,y,z);parent.add(o);return o
  }
  const group=(name:string,x:number,y:number,z:number)=>{const g=new THREE.Group();g.name=name;g.position.set(x,y,z);c.scene.add(g);return g}
  function tag(parent:THREE.Object3D,label:string,x:number,y:number,z:number,width:number,ink='#f3ffff',bg='#162e39') {
    const canvas=document.createElement('canvas');canvas.width=512;canvas.height=88
    const g=canvas.getContext('2d')!;g.fillStyle=bg;g.fillRect(0,0,512,88);g.font='600 41px sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillStyle=ink;g.fillText(label,256,45,494)
    const map=new THREE.CanvasTexture(canvas);map.colorSpace=THREE.SRGBColorSpace
    const o=new THREE.Mesh(new THREE.PlaneGeometry(width,width*88/512),new THREE.MeshBasicMaterial({map,side:THREE.DoubleSide}));o.position.set(x,y,z);parent.add(o);return o
  }
  function skin(mesh:THREE.Mesh,file:string,width:number,height:number,depth:number,z=0) {
    const m=mesh.material as THREE.MeshStandardMaterial
    m.visible=false
    detail(mesh,'iq-'+file+'.glb',[0,0,z],[width,height,depth])
  }
  const shell=0xd4dcdb,grip=0x353c42,copper=0xb1945d,board=0x226e60,accent=0x26cbbb
  const world=c.scene
  const wall=slab(world,'Training wall',1.42,.18,-.24,1.9,3.23,.15,0x536b6e)
  for(const x of [.73,2.15])slab(wall,'Oak casing',x-wall.position.x,-.10, .16,.10,2.50,.12,0xa47850)
  slab(wall,'Head casing',0,1.14,.16,1.52,.13,.12,0xa47850)
  const hinge=group('Door hinge',.79,-1.10,-.02);hinge.rotation.y=s.door?-1.0:0
  const leaf=slab(hinge,'Door leaf',.65,1.14,.065,1.30,2.28,.10,0x966944)
  skin(leaf,'door',1.30,2.28,.174,.028)
  c.hit(leaf,toggleDoor);c.register('iq-door','Entry door',leaf,2.55)
  const labels=group('Workbench labels',0,0,0)
  tag(labels,'ENTRY DOOR',1.44,-1.32,.05,.98)
  const box=group('Equipment box',-1.63,-.94,.04)
  slab(box,'Box base',0,0,0,1.24,.59,.11,0x96734d)
  const lid=slab(box,'Box lid',0,s.box?.45:0,s.box?-.03:.12,1.27,.60,.08,0xb7996d)
  if(s.box)lid.rotation.x=-.65
  skin(lid,'box-lid',1.27,.60,.085);c.register('iq-box','Equipment box',box,1.55)
  if(s.box){
    slab(box,'Foam tray',0,0,.061,1.19,.54,.035,0x354143)
    slab(box,'Packing well',0,0,.080,.96,.40,.009,0x1c2a2c)
  }
  c.hit(box,()=>s.box?inspect(-1.55,-.91,1.65):install('box'))
  const px=s.seated?-.42:(s.unpacked?-1.26:-1.64),py=s.seated?.50:(s.unpacked?.35:-.94)
  const panel=group('IQ Panel 5',px,py,.20)
  panel.visible=s.box
  const housing=slab(panel,'Housing',0,0,0,1.17,.88,.12,shell)
  if(s.box)c.register('iq-panel','IQ Panel 5',housing,1.48)
  const rear=s.plateOff&&!s.seated
  skin(housing,rear?'panel-rear':'panel-front',1.17,.88,rear?.223:.139,rear?.035:0)
  if(rear) {
    const batteryView=detail(panel,'iq-battery.glb',[-.21,-.12,.12],[.27,.16,.05]);c.register('iq-battery','Standby battery',batteryView,.37)
    const jack=slab(panel,'Battery harness socket',.081,-.13,.145,.09,.055,.016,s.battery?accent:0xdadee0);c.hit(jack,()=>install('battery'))
    const plug=slab(panel,'DC socket',.262,-.184,.15,.075,.05,.02,s.cable?accent:0x152531);c.hit(plug,()=>install('cable'))
    tag(panel,'BATTERY',.065,-.218,.153,.17);tag(panel,'12 V DC',.275,-.265,.151,.155)
  }else{
    if(s.on){
      const pageLabels:Record<string,string>={home:'SYSTEM DISARMED',tray:'Settings tray',settings:'Settings',pin:'Enter installer code',advanced:'Advanced Settings',dealer:'Dealer contact',installation:'Installation',devices:'Devices',sensors:'Security Sensors',learn:'Auto Learn Sensor',confirm:'Sensor detected',configure:'Add sensor',edit:'Edit Sensor',status:'Sensor Status'}
      const nextPage:Record<string,[string,string]>={tray:['Settings','settings'],settings:['Advanced Settings','pin'],advanced:['Installation',s.dealer?'installation':'dealer'],installation:['Devices','devices'],devices:['Security Sensors','sensors'],sensors:['Auto Learn Sensor','learn']}
      const currentZone=s.motionDetected&&s.motionZone?s.motionZone.name+' / '+motionStatus():s.zone?s.zone.name+' / '+(contactClosed(s)?'Closed':'Open'):s.motionZone?s.motionZone.name+' / '+motionStatus():'No sensors enrolled'
      const caption=s.screen==='home'||s.screen==='status'?currentZone:nextPage[s.screen]?.[0]||
        ({pin:'Use keypad',dealer:'Company and phone',learn:'Listening…',confirm:s.sensor==='motion'?motionID:zoneID,configure:s.sensor==='motion'?'Motion':'Door / Window',edit:s.sensor==='motion'?s.motionZone?.name:s.zone?.name} as Record<string,string|undefined>)[s.screen]||''
      const screen=lcdSurface(s.screen,pageLabels[s.screen]||'IQ Panel 5',caption)
      screen.position.set(0,.034,.075);panel.add(screen)
      const header=slab(panel,'Settings tray touch area',0,.266,.077,.90,.076,.001,0)
      const body=slab(panel,'Panel menu touch area',0,-.008,.077,.90,.430,.001,0)
      header.material.visible=false;body.material.visible=false
      c.hit(header,()=>setScreen('tray'));c.hit(body,()=>{if(nextPage[s.screen])setScreen(nextPage[s.screen][1]);else{inspect(px,py,1.5);ui.querySelector('.iq-touch')?.scrollIntoView({block:'nearest'})}})
    }
  }
  const screw=slab(panel,'Lock screw',0,-.426,.075,.10,.035,.03,s.loose&&!s.secured?0xa8a896:0x777c7e,.6)
  c.hit(screw,()=>install(s.seated?'secured':'loose'))
  const powerButton=slab(panel,'Side power button',.595,.16,.015,.035,.13,.05,s.on?accent:grip)
  c.hit(powerButton,()=>{inspect(px,py,1.65);c.say('Use the hold control on the inspector to hold the side button for three seconds.')})
  c.hit(housing,()=>!s.unpacked?install('unpacked'):inspect(px,py,1.72))
  const plate=group('SmartMount',s.plateMounted?-.42:-.20,s.plateMounted?.5:-.74,.065)
  plate.visible=s.plateOff&&!s.seated
  if(plate.visible)c.register('iq-plate','SmartMount backplate',plate,1.02)
  skin(slab(plate,'Backplate',0,0,0,.90,.67,.05,0x767f80),'smartmount',.90,.67,.067)
  if(!s.plateMounted && s.plateOff){
    const spot=slab(world,'SmartMount wall position',-.42,.50,-.22,.95,.70,.04,0x485960)
    tag(spot,'WALL MOUNT',0,0,.03,.59)
    c.drag(plate,p=>plate.position.set(p.x,p.y,.16),p=>{
      if(Math.hypot(p.x+.42,p.y-.50)<.50)install('plateMounted')
      else{c.say('Place the backplate inside the wall mounting outline.');c.update()}
    },c.update)
  }
  if(s.unpacked && !s.plateOff){
    const rearCover=slab(panel,'Rear SmartMount',0,0,.13,1.0,.69,.045,0x758083)
    skin(rearCover,'smartmount',1,.69,.058)
    c.hit(rearCover,()=>install('plateOff'));c.register('iq-plate','SmartMount backplate',rearCover,1.02)
  }
  const adapter=group('Adapter',-.32,-1.22,.06);detail(adapter,'iq-adapter.glb',[0,0,.03],[.30,.36,.19])
  c.register('iq-adapter','12 V DC adapter',adapter,.60)
  tag(adapter,'12 V DC',0,0,.13,.28);c.hit(adapter,()=>install('adapter'))
  if(s.cable){
    const pts=[new THREE.Vector3(px+(rear?.262:.32),py+(rear?-.184:-.41),rear?.36:.14),new THREE.Vector3(px+.55,-.36,.19),new THREE.Vector3(-.57,-1.24,.12),new THREE.Vector3(-.33,-1.2,.12)]
    world.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts),36,.016,6,false),mat(grip)))
  }
  const txAt=s.transmitter==='frame'?[1.87,1.264]:[-1.48,-1.42]
  const tx=group('PG9945 · '+zoneID,txAt[0],txAt[1],.16);tx.visible=s.box
  skin(slab(tx,'PG9945 case',0,0,0,.11,.25,.07,shell),'contact',.11,.25,.07)
  if(s.transmitter==='frame')tx.rotation.z=Math.PI/2
  const light=slab(tx,'Enroll button',0,.068,.037,.025,.014,.006,s.screen==='confirm'?0xffcd46:grip)
  c.hit(light,enroll)
  const magX=1.08
  const mWorld=new THREE.Vector3(magX,s.magnet==='wide'?2.16:2.275,.20);hinge.updateMatrixWorld(true);hinge.localToWorld(mWorld)
  const mpos=s.magnet==='bench'?new THREE.Vector3(-1.26,-1.42,.16):mWorld
  const magnet=group('Moving magnet',mpos.x,mpos.y,mpos.z);magnet.visible=s.box
  magnet.rotation.y=s.magnet==='bench'?0:hinge.rotation.y
  if(s.magnet!=='bench')magnet.rotateZ(Math.PI/2)
  skin(slab(magnet,'Magnet',0,0,0,.055,.15,.05,shell),'magnet',.055,.15,.05)
  if(s.box){
    c.register('iq-contact','PG9945 transmitter',tx,.40);c.register('iq-magnet','PG9945 magnet',magnet,.29)
    c.drag(tx,p=>tx.position.set(p.x,p.y,.20),p=>place('transmitter',p.distanceTo(new THREE.Vector3(1.87,1.264,p.z))<.34?'frame':'bench'),c.update)
    c.drag(magnet,p=>magnet.position.set(p.x,p.y,.20),p=>{
      if(s.door){c.say('Close the door to set the mounting gap.');c.update();return}
      const pos=Math.abs(p.x-1.87)<.24 && p.y>.92 && p.y<1.31?(p.y>=1.13?'aligned':'wide'):'bench'
      place('magnet',pos)
    },c.update)
  }
  const motion=group('PG9914 motion detector',s.motionMounted?1.29:1.12,s.motionMounted?1.59:-1.21,.16)
  motion.visible=s.box
  const motionBody=slab(motion,'PG9914 housing',0,0,0,.23,.31,.13,shell)
  motionBody.material.visible=false
  detail(motionBody,s.motionCover?'PG9914-open.glb':'PG9914.glb',[0,0,0],[.23,.31,.14])
  if(s.box){
    c.register('iq-pir','PG9914 motion detector',motion,.46)
    c.drag(motion,p=>motion.position.set(p.x,p.y,.16),p=>mountMotion(Math.hypot(p.x-1.29,p.y-1.59)<.35),c.update)
    if(s.motionCover){const switchHit=slab(motion,'PG9914 enroll switch',.054,.092,.09,.054,.054,.024,0)
      switchHit.material.visible=false;c.hit(switchHit,enrollMotion)}
    const target=slab(world,'Hallway mount',1.29,1.59,-.11,.29,.39,.035,0x536b6e)
    if(!s.motionMounted)tag(target,'PIR MOUNT',0,-.23,.02,.34)
    if(s.motionMounted&&s.motionZone&&!s.motionCover){
      const shape=new THREE.Shape();shape.moveTo(0,0);shape.lineTo(-.43,-.83);shape.quadraticCurveTo(0,-1.01,.43,-.83);shape.closePath()
      const field=new THREE.Mesh(new THREE.ShapeGeometry(shape),new THREE.MeshBasicMaterial({color:s.motionDetected?0xcff476:0x74b8cf,transparent:true,opacity:.25,depthWrite:false}))
      field.position.set(1.29,1.44,.23);world.add(field);c.hit(field,walk);c.register('iq-coverage','Motion coverage',motion,.46,field)
    }
  }
  const row=(name:string)=>{const d=nd('details');const h=nd('summary',name);d.append(h);ui.append(d);return d}
  if(!assessed)text(ui,instruction(s))
  const toolkit=s.on?row('Installation tools'):ui
  if(!s.on){const next=nextStep(s);const controls=nd('div');controls.className='iq-actions';toolkit.append(controls)
    for(const [key,title] of processSteps)if(!s[key]){
      if(key==='on')hold(controls,'Hold power · 3 seconds',3000,()=>install('on'))
      else button(controls,title,()=>install(key))
    }
    if(next && c.mode.toLowerCase()==='learn')text(toolkit,'Inspect the rear connections before latching the panel. The supplied adapter powers the panel after its battery is connected.')
  }
  button(toolkit,'Inspect panel',()=>inspect(px,py,1.68));button(toolkit,'Inspect entry door',()=>inspect(1.45,.42,2.6))
  if(s.box)button(toolkit,'Inspect contact',()=>inspect(tx.position.x,tx.position.y,.47))
  if(s.box){
    const hardware=s.on?ui:row('PG9945 door hardware')
    const details=nd('details');details.open=s.on && ['learn','confirm'].includes(s.screen);details.append(nd('summary','PG9945 · hardware controls'));hardware.append(details)
    text(details,'Training label '+zoneID+' · Mount on the fixed header near the latch, with the magnet on the moving door')
    hold(details,'Hold enroll until yellow flash',1100,enroll)
    button(details,'Mount transmitter on frame',()=>place('transmitter','frame'))
    button(details,'Mount magnet · 4 mm gap',()=>place('magnet','aligned'))
    button(details,'Mount magnet · 18 mm gap',()=>place('magnet','wide'))
    button(details,'Remove magnet',()=>place('magnet','bench'))
  }
  button(ui,s.door?'Close door':'Open door',toggleDoor)
  if(s.box){
    const motionTools=row('PG9914 · hallway motion')
    motionTools.open=s.on&&['learn','confirm','status'].includes(s.screen)
    text(motionTools,'Training label '+motionID+' · Mount above the doorway at 2.2 m, facing across the walking path')
    button(motionTools,'Inspect motion detector',()=>inspect(motion.position.x,motion.position.y,.55))
    button(motionTools,s.motionMounted?'Return motion detector to bench':'Mount motion detector in hallway',()=>mountMotion(!s.motionMounted))
    button(motionTools,s.motionCover?'Close motion cover':'Open motion cover',()=>apply(s.motionCover?'PG9914 cover closed':'PG9914 cover opened',()=>{s.motionCover=!s.motionCover;s.motionDetected=false}))
    if(s.motionCover)button(motionTools,'Press PG9914 enroll switch',enrollMotion)
    if(s.motionZone)button(motionTools,s.motionDetected?'Clear hallway motion':'Walk across hallway',walk)
  }
  if(s.on)renderPanel()
  const report=row('Commissioning');report.open=s.commissioned||(s.on&&s.screen==='status')
  button(report,'Run installation test',()=>apply('Installation test recorded',()=>{s.commissioned=true}))
  if(s.commissioned){for(const item of iqChecks(s))text(report,(item.pass?'✓ ':'× ')+item.label)}
  if(c.mode.toLowerCase()==='learn')text(report,'IQ Panel 5 installation manual, software 5.0, pp. 9, 12, 14, 16, 21, 26, 61, 67 and 93. PG9945 installation sheet, p. 1. Device spacing and enrollment LED time are visual approximations.')
  function renderPanel(){
    const display=nd('section');display.className='iq-touch'
    display.style.cssText='background:#e5efed;color:#173b38;border:7px solid #cfdbda;border-bottom-width:13px;border-radius:15px;padding:12px;margin:12px 0;box-shadow:0 3px 8px #0003'
    ui.append(display)
    const header=button(display,'IQ Panel 5  ·  Settings tray',()=>setScreen('tray'))
    header.style.cssText='width:100%;background:#274d49;color:white;text-align:center'
    let sy=0;header.ontouchstart=e=>{sy=e.touches[0].clientY};header.ontouchend=e=>{if(e.changedTouches[0].clientY-sy>14)setScreen('tray')}
    const title=(t:string)=>display.append(nd('h3',t))
    const page=(label:string,key:string)=>button(display,label,()=>setScreen(key))
    const showZones=(details:boolean)=>{
      if(s.zone)text(display,(details?'Front door · Group '+s.zone.group+' · ':'')+s.zone.name+' · '+(contactClosed(s)?'Closed':'Open'))
      if(s.motionZone)text(display,(details?'Hallway PIR · Group '+s.motionZone.group+' · ':'')+s.motionZone.name+' · '+motionStatus())
      if(!s.zone&&!s.motionZone)text(display,'No sensors enrolled')
    }
    const isMotion=s.sensor==='motion'
    switch(s.screen){
      case 'home':title('System disarmed');showZones(false);break
      case 'tray':title('Settings tray');text(display,'System disarmed · Battery connected');page('Settings','settings');break
      case 'settings':title('Settings');page('Advanced Settings','pin');break
      case 'pin':{
        title('Enter code');text(display,'Bench installer code '+labCode)
        const dots=nd('output');display.append(dots);const pad=nd('div');pad.style.cssText='display:grid;grid-template-columns:repeat(3,1fr);gap:3px';display.append(pad)
        let digits='';for(const n of ['1','2','3','4','5','6','7','8','9','Clear','0','Enter'])button(pad,n,()=>{
          if(n==='Clear')digits=''
          else if(n==='Enter'){if(digits===labCode)setScreen('advanced');else{c.say('Code not recognized.');digits=''}}
          else if(digits.length<4)digits+=n
          dots.value='•'.repeat(digits.length)
        });break}
      case 'advanced':title('Advanced Settings');page('Installation',s.dealer?'installation':'dealer');break
      case 'dealer':title('Dealer contact');text(display,'Use the fictional training company and telephone number.');text(display,'Bench Training · 604-555-0146');button(display,'Save dealer details',()=>apply('Dealer details saved',()=>{s.dealer=true;s.screen='installation'}));break
      case 'installation':title('Installation');page('Devices','devices');break
      case 'devices':title('Devices');page('Security Sensors','sensors');break
      case 'sensors':
        title('Security Sensors');page('Auto Learn Sensor','learn');page('Sensor Status','status')
        if(s.zone)button(display,'Edit door contact',()=>apply('Edit door contact',()=>{s.sensor='contact';s.screen='edit'}))
        if(s.motionZone)button(display,'Edit motion detector',()=>apply('Edit motion detector',()=>{s.sensor='motion';s.screen='edit'}))
        break
      case 'learn':title('Auto Learn Sensor');text(display,'Listening for a wireless sensor…');if(!assessed)text(display,'Hold PG9945 enroll until its LED flashes, or open the PG9914 cover and press its enroll switch.');page('Cancel','sensors');break
      case 'confirm':title('Sensor detected');text(display,'DL ID '+(isMotion?motionID:zoneID)+' · Compare with the device label.');button(display,'OK · Confirm ID',()=>apply('PowerG label confirmed',()=>{if(!isMotion)s.identified=true;s.screen='configure'}));page('Cancel','learn');break
      case 'configure':case 'edit':{
        const edit=s.screen==='edit',old=isMotion?s.motionZone:s.zone;title(edit?'Edit Sensor':'Add sensor')
        text(display,'Partition 1 · PowerG · '+(isMotion?motionID:zoneID))
        const deviceType=isMotion?'Motion':'Door / Window'
        const type=select([deviceType],deviceType),name=nd('input');name.value=old?.name||'';name.maxLength=36
        const groups=isMotion?['17 · Away Instant Motion','15 · Stay Instant Motion']:['10 · Entry-Exit Normal Delay','13 · Instant Perimeter']
        const group=select(groups,groups.find(value=>value.startsWith(old?.group+' ·'))||groups[0])
        const chime=select(['Default','Off'],old?.chime||'Default'),voice=select(['On','Off'],old?.voice===false?'Off':'On')
        field(display,'Sensor type',type);field(display,'Sensor group',group);field(display,'Sensor name',name);field(display,'Chime',chime);field(display,'Voice prompts',voice)
        button(display,edit?'Save changes':'Add New',()=>{if(!name.value.trim()){name.focus();c.say('Enter the zone name.');return}
          apply(edit?'Zone updated':(isMotion?'Motion detector':'Door contact')+' enrolled',()=>{
            const zone={name:name.value.trim(),group:group.value.slice(0,2),chime:chime.value,voice:voice.value==='On'}
            if(isMotion){s.motionZone=zone;s.motionTested=false;s.motionDetected=false}
            else{s.zone=zone;s.testedOpen=false;s.testedClosed=false}
            s.commissioned=false;s.screen='sensors'
          })});break}
      case 'status':title('Sensor Status');showZones(true);page('Back to sensors','sensors');break
    }
    if(s.screen!=='home')page('Home','home')
  }
}

