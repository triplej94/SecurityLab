const {spawn}=require('child_process'),path=require('path'),fs=require('fs'),assert=require('assert/strict');
const {pathToFileURL}=require('url');
const os=require('node:os');const profile=fs.mkdtempSync(path.join(os.tmpdir(),'securitylab-neo-'));const exe=process.env.BROWSER_EXECUTABLE||'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const proc=spawn(exe,['--headless=new','--use-angle=swiftshader','--enable-unsafe-swiftshader','--window-size=1400,1000','--no-first-run','--disable-background-networking','--remote-debugging-pipe','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','ignore','pipe','pipe'],windowsHide:true});
let seq=0,pending=new Map(),buffer='',session,errors=[];
proc.stdio[4].on('data',chunk=>{buffer+=chunk;while(buffer.includes('\0')){const j=buffer.indexOf('\0');const v=JSON.parse(buffer.slice(0,j));buffer=buffer.slice(j+1);if(v.method==='Runtime.exceptionThrown')errors.push(v.params.exceptionDetails.exception?.description??v.params.exceptionDetails.text);if(pending.has(v.id)){pending.get(v.id)(v);pending.delete(v.id)}}});
function call(method,params={},id){return new Promise((resolve,reject)=>{const n=++seq;pending.set(n,v=>v.error?reject(Error(v.error.message)):resolve(v.result));proc.stdio[3].write(JSON.stringify({id:n,method,params,sessionId:id})+'\0')})}
async function run(code){const r=await call('Runtime.evaluate',{expression:code,returnByValue:true},session);if(r.exceptionDetails)throw Error(r.exceptionDetails.exception.description);return r.result.value}
const click=t=>run("(()=>{const b=[...document.querySelectorAll('button')].find(b=>b.textContent==="+JSON.stringify(t)+");if(!b)throw Error('Missing button: '+"+JSON.stringify(t)+");b.click()})()");
const wait=ms=>new Promise(r=>setTimeout(r,ms));

const base=path.resolve(__dirname,'../dist');
const http=require('http').createServer((req,res)=>{const segment=new URL(req.url,'http://localhost').pathname;const file=path.join(base,segment==='/'?'index.html':segment);try{const data=fs.readFileSync(file);res.writeHead(200,{'Content-Type':({'.js':'text/javascript','.html':'text/html','.css':'text/css','.json':'application/json'})[path.extname(file)]||'application/octet-stream'});res.end(data)}catch{res.writeHead(404);res.end()}});
http.listen(0,'127.0.0.1');
const timer=setTimeout(()=>{console.error('Timeout');proc.kill();process.exit(1)},240000);
(async()=>{
 const tab=await call('Target.createTarget',{url:'about:blank'});session=(await call('Target.attachToTarget',{targetId:tab.targetId,flatten:true})).sessionId;await call('Runtime.enable',{},session);
 await call('Page.navigate',{url:'http://127.0.0.1:'+http.address().port},session);
 for(let i=0;i<120&&!await run("document.querySelector('#title')?.textContent");i++)await wait(180);
 await run("localStorage.clear()");await call('Page.reload',{},session);for(let i=0;i<100&&!await run('document.getElementById('+JSON.stringify('title')+')?.textContent');i++)await wait(150);await click('DSC Neo');
 const state=()=>run("JSON.parse(localStorage.getItem('securitylab.bench.v1')).neo");
 await run(`(()=>{
 const btn=t=>{const b=[...document.querySelectorAll('button')].find(b=>b.textContent===t);if(!b)throw Error('Missing '+t);b.click()};
 const sel=(label,v)=>{const el=document.querySelector('select[aria-label="'+label+'"]');el.value=v;el.dispatchEvent(new Event('change'))};

 btn('Open HS2032 carton');btn('Mount cabinet on backboard');btn('Mount HS2032');btn('Mount HS2LCD');btn('Close cabinet');btn('Open cabinet');btn('Corbus terminal close-up');btn('Open keypad flap');btn('Select 22/4 cable');btn('Route cable');btn('Strip board jacket');btn('Strip keypad jacket');
 for(const side of ['board','keypad'])for(let i=0;i<4;i++){sel('Conductor end',side+':'+i);btn('Strip conductor');sel('Destination terminal',''+i);btn('Insert lead');btn('Tighten screw')}
 btn('Return to mechanical room');btn('Mount 7939WG header contact');btn('Mount LC-100-PI above door');btn('Remove detector cover');
 ['Z1','COM','Z2','COM','AUX+','AUX−'].forEach((n,i)=>{sel('Field conductor',''+i);btn('Land at '+n);btn('Clamp field lead')});
 btn('Fit Door 5.6 kΩ resistor');btn('Fit Motion 5.6 kΩ resistor');btn('Close detector cover');btn('Inspect wiring');btn('Connect battery');btn('Apply transformer power');
 for(const k of '1*84256903000*')btn(k);
 for(const k of '*842560010010010010020050131#20100112#')btn(k);
 btn('Open front door');btn('Close front door');btn('Walk across detection area');btn('Leave detection area');
 if(!document.querySelector('#score').textContent.includes('9 of 9'))throw Error(document.querySelector('#inspector').innerText);
 })()`);
 await run("(()=>{const k='securitylab.bench.v1',s=JSON.parse(localStorage.getItem(k));for(const name of ['cabinet','coverOpen','service'])delete s.neo[name];s.neo.field.view=true;localStorage.setItem(k,JSON.stringify(s))})()");
 await wait(900);await call('Page.reload',{},session);for(let i=0;i<100&&!await run('document.querySelector(' + JSON.stringify('#score') + ')?.textContent');i++)await wait(150);assert.match(await run("document.querySelector('#score').textContent"),/9 of 9/);
 const rect=await run("(()=>{const r=document.querySelector('#bench').getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,scale:1}})()");
 const shot=await call('Page.captureScreenshot',{format:'png',clip:rect,captureBeyondViewport:true},session);fs.writeFileSync(path.join(__dirname,'../docs/Visual checks/Neo mechanical room.png'),Buffer.from(shot.data,'base64'));
 await click('Isolate power');await click('Remove detector cover');await click('Loosen field lead');await click('Land at Z1');await click('Fit view');await wait(450);
 const viewport=await run("(()=>{const c=document.querySelector('#bench canvas');c.scrollIntoView({block:'center'});const r=c.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}})()");
 const project=(x,y,z)=>{const scale=viewport.h/(2*Math.tan(16*Math.PI/180)*(Math.max(5.6,5.6*viewport.h/viewport.w)*1.86+.21-z));return {x:viewport.x+viewport.w/2+x*scale,y:viewport.y+viewport.h/2-(y-.14)*scale}};
 const mouse=(type,p,buttons)=>call('Input.dispatchMouseEvent',{type,...p,button:type==='mouseMoved'?'none':'left',buttons,clickCount:1},session);
 const start=project(.594,.40,.34),end=project(1.43,.48,.34);
 await mouse('mousePressed',start,1);await mouse('mouseMoved',end,1);await mouse('mouseReleased',end,0);
 assert.equal((await state()).field.ends[5],'AUX−','Dragged PIR return must land at AUX−');
 await click('Clamp field lead');await click('Close detector cover');
 await wait(450); const activate=async point=>{await mouse('mousePressed',point,1);await mouse('mouseReleased',point,0)};
 await activate(project(1.66,-.03,.37));assert.equal((await state()).battery,true);
 await activate(project(2.38,-1.02,.187));assert.equal((await state()).ac,true);
 await click('Walk across detection area');await click('Leave detection area');
 assert.match(await run("document.querySelector('#score').textContent"),/9 of 9/);

 await click('Equipment explorer');
 for(let i=0;i<25&&!await run("document.querySelector('.equipment-comparison img')?.complete");i++)await wait(160);
 assert.match(await run("document.querySelector('.equipment-comparison figcaption').textContent"),/HS2032 control board/);
 assert.equal(await run("document.querySelector('.equipment-comparison img').naturalWidth>0"),true);
 const comparisonShot=await call('Page.captureScreenshot',{format:'png'},session);
 fs.writeFileSync(path.join(__dirname,'../docs/Visual checks/Equipment explorer photo comparison.png'),Buffer.from(comparisonShot.data,'base64'));
 await click('Close');
 await call('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:false},session);
 await click('Equipment explorer');await run("(()=>{let s=document.querySelector('[aria-label=\"Inspect equipment model\"]');s.value='LC-100-PI-open';s.dispatchEvent(new Event('change'))})()");
 await wait(400);assert.equal(await run("document.documentElement.scrollWidth<=innerWidth"),true);
 assert.equal(await run("document.querySelector('.equipment-comparison img').naturalWidth>0"),true);
 assert.match(await run("document.querySelector('.equipment-comparison figcaption').textContent"),/wiring terminals/);
 await call('Page.bringToFront',{},session);
 await run("document.querySelector('.equipment-comparison .equipment-photo-open').focus()");
 await call('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter',windowsVirtualKeyCode:13,nativeVirtualKeyCode:13},session);
 await call('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter',windowsVirtualKeyCode:13,nativeVirtualKeyCode:13},session);
 assert.equal(await run("Boolean(document.querySelector('.equipment-photo-dialog[open]'))"),true);
 await click('Close photo');await wait(100);
 assert.equal(await run("document.activeElement.classList.contains('equipment-photo-open')"),true);
 await run("document.querySelector('.equipment-comparison img').dispatchEvent(new Event('error'))");
 assert.match(await run("document.querySelector('.equipment-comparison figcaption').textContent"),/Image unavailable/);
 assert.equal(await run("Boolean(document.querySelector('.equipment-comparison figcaption a').href)"),true);
 const canvas=await run("(()=>{let c=document.querySelector('#dialog canvas');c.scrollIntoView({block:'center'});const r=c.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,scale:1}})()");
 const grab=async()=>(await call('Page.captureScreenshot',{format:'png',clip:canvas,captureBeyondViewport:true},session)).data;
 const center={x:canvas.x+canvas.width/2,y:canvas.y+canvas.height/2};
 const before=await grab();await mouse('mousePressed',center,1);await mouse('mouseMoved',{x:center.x+53,y:center.y+20},1);await mouse('mouseReleased',{x:center.x+53,y:center.y+20},0);await wait(150);
 const rotated=await grab();assert.notEqual(rotated===before,true,'Orbit changes the model view');
 await call('Input.dispatchMouseEvent',{type:'mouseWheel',...center,deltaX:0,deltaY:-120},session);await wait(250);assert.notEqual((await grab())===rotated,true,'Zoom changes the model view');

 await click('Close'); await click('IQ Panel 5');
 const bulk=labels=>run('('+((names)=>{for(const n of names){const b=[...document.querySelectorAll('button')].find(b=>b.textContent===n);if(!b)throw Error(n);b.click()}}).toString()+')('+JSON.stringify(labels)+')');
 const hold=async(label,ms)=>{await run("(()=>{let b=[...document.querySelectorAll('button')].find(b=>b.textContent==="+JSON.stringify(label)+");b.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter'}))})()");await wait(ms)};
 await bulk(['Open equipment box','Lift out IQ Panel 5','Release locking screw','Remove SmartMount backplate','Mount backplate level','Seat battery connector','Insert 12 V barrel plug','Latch panel on backplate','Tighten locking screw','Plug in supplied adapter']);await hold('Hold power · 3 seconds',3300);
 await bulk(['Mount transmitter on frame','Mount magnet · 4 mm gap','IQ Panel 5  ·  Settings tray','Settings','Advanced Settings','4','7','2','6','Enter','Installation','Save dealer details','Devices','Security Sensors','Auto Learn Sensor']);await hold('Hold enroll until yellow flash',1400);
 await click('OK · Confirm ID');await run("document.querySelector('.iq-touch input').value='Front Door'");await bulk(['Add New','Mount magnet · 18 mm gap','Sensor Status']);assert.match(await run("document.querySelector('.iq-touch').textContent"),/Front Door · Open/);
 await bulk(['Mount magnet · 4 mm gap','Open door','Close door','Back to sensors','Mount motion detector in hallway','Auto Learn Sensor','Open motion cover','Press PG9914 enroll switch','OK · Confirm ID']);
 await run("document.querySelector('.iq-touch input').value='Hall Motion'");await bulk(['Add New','Close motion cover','Sensor Status','Walk across hallway','Clear hallway motion']);assert.match(await run("document.querySelector('#score').textContent"),/7 of 7/);
 await click('DSC Neo');await click('Reset exercise');await click('Reset this exercise');await click('IQ Panel 5');assert.match(await run("document.querySelector('#score').textContent"),/7 of 7/);

 assert.deepEqual(errors,[]);console.log('Passed Neo room commissioning, cabinet, Corbus and field wiring, PIR repair by dragging, reload, narrow explorer, IQ regression and independent reset.');

})().catch(e=>{console.error(e,errors);return run("document.body.innerText.slice(0,900)").then(t=>{console.log(t);process.exitCode=1})}).finally(async()=>{http.close();clearTimeout(timer);await call('Browser.close').catch(()=>{});proc.kill()});












