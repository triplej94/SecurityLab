"""Generate SecurityLab's original IQ workbench GLBs in Blender 5.3.

Run blender -b -P design/iq-models.py -- <public/assets directory>.
Front elevations and component layout follow IQ Panel 5 v5.0 manual pp. 5–9
and the PG9945 sheet p. 1. Hidden details and wall construction are illustrative.
Blender coordinates use x across, z up, and -y towards the technician.
"""
import math
import sys
from pathlib import Path
import bpy

out = Path(sys.argv[-1]).resolve()
out.mkdir(parents=True, exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
def material(name, rgb, rough=.48, metal=0):
    m=bpy.data.materials.new(name); m.diffuse_color=(*rgb,1); m.use_nodes=True
    b=m.node_tree.nodes.get('Principled BSDF')
    for k,v in [('Base Color',(*rgb,1)),('Roughness',rough),('Metallic',metal)]: b.inputs[k].default_value=v
    return m
pearl=material('Pearl PC-ABS',(.88,.9,.88),.35)
side=material('Moulded base',(.56,.60,.60),.45)
black=material('Optical black',(.011,.021,.024),.20)
rubber=material('Graphite elastomer',(.063,.079,.081),.60)
silver=material('Nickel plated steel',(.55,.62,.62),.22,.75)
gold=material('Brushed brass',(.56,.36,.17),.30,.71)
board=material('Solder mask',(.023,.157,.11))
blue=material('Battery sleeve',(.19,.38,.50))
cream=material('Connector nylon',(.9,.85,.72))
red=material('Battery positive',(.55,.04,.029))
oak=material('Fumed oak',(.29,.145,.077))
face=material('Oak face',(.33,.17,.094))
grain=material('Oak pore',(.205,.111,.064))
kraft=material('Kraft',(.49,.315,.18),.86)
paper=material('Printed label',(.86,.86,.78),.79)
ink=material('Packaging ink',(.06,.09,.09))
foam=material('Protective insert',(.085,.105,.105),.93)
def finish(o,m):
    o.data.materials.append(m)
    return o
def rounded(n,x,h,f,w,height,d,r,m):
    ring=[]
    for cx,cz,base in [(w/2-r,height/2-r,0),(-w/2+r,height/2-r,90),(-w/2+r,-height/2+r,180),(w/2-r,-height/2+r,270)]:
        for j in range(7):
            a=math.radians(base+j*15);ring.append((cx+r*math.cos(a),cz+r*math.sin(a)))
    verts=[(x+u,-(f+z),h+v) for z in [-d/2,d/2] for u,v in ring]
    k=len(ring);faces=[tuple(reversed(range(k))),tuple(range(k,2*k))]
    faces.extend((i,(i+1)%k,k+(i+1)%k,k+i) for i in range(k))
    mesh=bpy.data.meshes.new(n);mesh.from_pydata(verts,[],faces);mesh.update()
    o=bpy.data.objects.new(n,mesh);bpy.context.collection.objects.link(o)
    bevel=o.modifiers.new('Tooling radius','BEVEL');bevel.width=min(r*.20,d*.20);bevel.segments=2
    o.modifiers.new('Surface normals','WEIGHTED_NORMAL')
    return finish(o,m)
def disk(n,x,h,f,r,d,m):
    bpy.ops.mesh.primitive_cylinder_add(vertices=24,radius=r,depth=d,location=(x,-f,h),rotation=(math.pi/2,0,0))
    o=bpy.context.object;o.name=n;return finish(o,m)
def screw(x,h,f,r=.021):
    disk('Captive fastener',x,h,f,r,.013,silver)
    rounded('Drive slot',x,h,f+.007,r*1.36,r*.22,.003,.001,black)
    rounded('Cross drive',x,h,f+.007,r*.22,r*1.36,.003,.001,black)
def word(t,x,h,f,size,m=ink):
    bpy.ops.object.text_add(location=(x,-f,h),rotation=(math.pi/2,0,0));o=bpy.context.object
    o.name=t;o.data.body=t;o.data.size=size;o.data.align_x='CENTER';o.data.align_y='CENTER'
    finish(o,m);bpy.ops.object.convert(target='MESH')
def save(n):
    # Each file is one rigid interaction part. Joining keeps a single draw
    # batch per material when the browser repeatedly changes equipment state.
    bpy.ops.object.select_all(action='SELECT')
    bpy.context.view_layer.objects.active=next(o for o in bpy.context.selected_objects if o.type=='MESH')
    bpy.ops.object.convert(target='MESH')
    bpy.ops.object.join()
    bpy.context.object.name=n
    bpy.ops.export_scene.gltf(filepath=str(out/('iq-'+n+'.glb')),export_format='GLB',export_apply=True)
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete()
def chassis():
    rounded('Body taper',0,0,-.025,1.12,.845,.14,.075,side)
    rounded('Split line',0,0,.032,1.156,.866,.029,.07,rubber)
    rounded('Front shell',0,0,.054,1.17,.88,.072,.068,pearl)
chassis()
rounded('Glass surround',0,.036,.090,.946,.559,.007,.017,black)
rounded('Off-state glass',0,.036,.094,.929,.541,.004,.011,black)
disk('Portrait camera rim',0,.379,.089,.023,.005,silver)
disk('Optical lens',0,.379,.094,.015,.006,black)
disk('Lens reflection',-.003,.383,.099,.004,.002,blue)
for x in [-.104,.103]: disk('Microphone port',x,.376,.091,.004,.005,rubber)
disk('Ambient sensor',.086,.367,.090,.004,.004,black)
rounded('Speaker seam',0,-.33,.091,1.141,.008,.006,.0025,rubber)
disk('Lower sound grille',0,-.381,.090,.033,.005,silver)
disk('Grille inset',0,-.381,.093,.026,.004,rubber)
for i in range(-2,3):
    for j in range(-2,3):
        if i*i+j*j<7:disk('Grille perforation',i*.008,-.381+j*.008,.096,.002,.002,black)
disk('Status lamp',.54,.02,.09,.008,.004,cream)
save('panel-front')
chassis()
rounded('Inner service rim',0,0,.092,.83,.655,.025,.049,side)
rounded('Electronics well',0,0,.107,.78,.61,.02,.033,rubber)
rounded('Controller PCB',0,.007,.12,.72,.554,.017,.023,board)
for x,h,w,height in [(-.21,.12,.20,.19),(.215,.15,.23,.16)]:
    rounded('Radio shield frame',x,h,.142,w,height,.026,.011,silver)
    rounded('Shield lid',x,h,.161,w-.016,height-.016,.017,.01,side)
for x,h in [(-.055,.20),(.008,.12),(.06,.02),(-.27,-.01)]:
    rounded('Integrated package',x,h,.144,.046,.06,.016,.002,black)
    for j in range(4):
        for sg in [-1,1]:rounded('Package contact',x+sg*.025,h-.021+j*.014,.142,.009,.004,.004,.001,silver)
for k in range(14):
    x=-.31+(k%7)*.045;h=.25-(k//7)*.075
    rounded('Passive component',x,h,.139,.019,.008,.008,.001,cream)
rounded('Li-ion pack',-.148,-.170,.166,.404,.162,.075,.028,blue)
rounded('Battery specification label',-.146,-.171,.207,.291,.091,.004,.005,paper)
word('Li-ion',-.146,-.170,.212,.055)
rounded('White keyed battery port',.081,-.13,.16,.080,.049,.036,.005,cream)
for i,m in enumerate([red,rubber]):
    rounded('Battery lead',-.013,-.145+i*.014,.181,.124,.009,.009,.003,m)
rounded('Barrel connector base',.262,-.184,.171,.125,.085,.076,.012,black)
disk('Ground ring',.262,-.184,.212,.031,.009,silver);disk('DC bore',.262,-.184,.218,.023,.005,black)
disk('Center pin',.262,-.184,.222,.007,.004,gold)
for a in [-.49,.49]:
    for b in [-.25,.29]:screw(a,b,.10)
save('panel-rear')
rounded('SmartMount flange',0,0,0,.90,.67,.045,.054,side)
rounded('Reinforced plate',0,0,.023,.824,.61,.021,.039,pearl)
rounded('Cable access',0,.036,.038,.39,.224,.005,.019,rubber)
for x in [-.28,0,.28]:
    disk('Keyhole lower',x,.205,.038,.028,.006,black)
    rounded('Keyhole stem',x,.226,.039,.029,.060,.005,.012,black)
for x in [-.30,.30]:
    rounded('Lower lug',x,-.207,.053,.109,.041,.036,.012,side)
    screw(x,-.207,.075,.014)
rounded('Latch',0,-.264,.052,.109,.037,.047,.009,black)
save('smartmount')
for is_magnet in [False,True]:
    w,h,d=(.055,.15,.05) if is_magnet else (.11,.25,.073)
    rounded('Mounting foot',0,0,-d*.28,w*.96,h*.95,d*.28,w*.15,side)
    rounded('Service seam',0,0,-d*.13,w*.995,h*.99,d*.07,w*.15,rubber)
    rounded('Polymer cover',0,0,d*.11,w,h,d*.55,w*.16,pearl)
    for z in [-.018,.018]:rounded('Reed alignment marks',(-1 if not is_magnet else 1)*w*.41,z,d*.389,.006,.017,.002,.002,side)
    if not is_magnet:
        rounded('Signal light pipe',0,.069,.030,.023,.009,.004,.003,black)
        rounded('Case release',0,-.113,.029,.025,.003,.003,.0007,rubber)
    save('magnet' if is_magnet else 'contact')
rounded('Door slab',0,0,0,1.30,2.28,.10,.01,oak)
for z in [-.51,.56]:
    rounded('Raised border',0,z,.058,1.07,.93,.015,.009,face)
    rounded('Shadow recess',0,z,.07,.975,.84,.009,.006,grain)
    rounded('Inner panel',0,z,.078,.942,.805,.012,.006,face)
    for i in range(7): rounded('Narrow vertical grain',-.393+i*.13,z,.085,.0024,.772,.003,.001,oak)
disk('Lever rose',.503,-.075,.078,.059,.021,gold)
disk('Hub',.503,-.075,.106,.024,.04,gold)
rounded('Return lever',.435,-.075,.132,.166,.027,.029,.012,gold)
disk('Deadbolt face',.503,.080,.070,.043,.018,gold)
rounded('Thumb turn',.503,.080,.086,.017,.047,.015,.007,gold)
save('door')
rounded('Carton lid',0,0,0,1.27,.60,.08,.017,kraft)
rounded('Dark bottom crease',0,-.273,.041,1.24,.004,.003,.001,grain)
rounded('Packing label',-.18,.034,.044,.73,.34,.005,.009,paper)
word('IQ PANEL 5',-.18,.096,.05,.083);word('WIRELESS CONTROL PANEL',-.18,.012,.05,.028)
for i in range(28):
    rounded('Stock mark',-.480+i*.015,-.063,.052,.005+(i%3)*.0015,.057,.002,.0007,ink)
rounded('Pull tab',.575,-.02,.043,.085,.20,.004,.009,rubber)
word('OPEN',.575,-.02,.047,.025,paper)
save('box-lid')
