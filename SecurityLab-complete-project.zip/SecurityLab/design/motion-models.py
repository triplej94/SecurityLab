"""Blender 5.3 motion detector exhibit. See local PG9914, PGP9914 and PG9924 guides."""
import bpy, sys
from pathlib import Path
from math import pi
out=Path(sys.argv[-1]).resolve()
bpy.ops.wm.read_factory_settings(use_empty=True)
def mat(n,c,r=.4,m=0):
    x=bpy.data.materials.new(n); x.diffuse_color=(*c,1);x.use_nodes=True
    p=x.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=r;p.inputs['Metallic'].default_value=m
    return x
white=mat('Ivory injection molded polymer',(.89,.88,.83))
base=mat('Rear polymer',(.48,.51,.50))
seam=mat('Dark recess',(.055,.07,.073))
lens=mat('Frosted Fresnel optic',(.77,.82,.82),.3)
line=mat('Optical segmentation',(.59,.67,.68),.53)
pcb=mat('Solder mask',(.035,.22,.11))
steel=mat('Tin plating',(.45,.5,.55),.29,.7)
cell=mat('Lithium battery jacket',(.14,.32,.49),.58)
amber=mat('LED optic',(.85,.39,.04),.25)
def block(n,x,z,y,w,h,d,r,m):
    bpy.ops.mesh.primitive_cube_add(size=1,location=(x,-y,z));o=bpy.context.object;o.name=n;o.dimensions=(w,d,h)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    b=o.modifiers.new('Tooling radius','BEVEL');b.width=r;b.segments=5
    o.modifiers.new('Surface normals','WEIGHTED_NORMAL')
    o.data.materials.append(m)
    return o
def disk(n,x,z,y,r,d,m):
    bpy.ops.mesh.primitive_cylinder_add(vertices=24,radius=r,depth=d,location=(x,-y,z),rotation=(pi/2,0,0))
    o=bpy.context.object;o.name=n;o.data.materials.append(m)
def label(n,x,z,y,height):
    bpy.ops.object.text_add(location=(x,-y,z),rotation=(pi/2,0,0));o=bpy.context.object
    o.data.body=n;o.data.size=height;o.data.align_x='CENTER';o.data.materials.append(seam)
    bpy.ops.object.convert(target='MESH')
def body(w,h,d):
    block('Screw mount base',0,0,-d*.36,w*.88,h*.93,d*.25,w*.10,base)
    block('Housing seam',0,0,-d*.19,w*.97,h*.98,d*.20,w*.11,seam)
    for z in [-h*.35,h*.35]:disk('Mounting recess',0,z,-d*.48,w*.04,.003,seam)
def finish(n):
    bpy.ops.export_scene.gltf(filepath=str(out/(n+'.glb')),export_format='GLB',export_apply=True)
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete()
for n,w,h,d,optics in [('PG9914',.061,.083,.042,'wide'),('PGP9914',.061,.083,.042,'wide'),('PG9924',.035,.105,.031,'curtain')]:
    body(w,h,d)
    block('Domed cover',0,0,.002,w,h,d*.66,w*.19,white)
    ow=w*(.76 if optics=='wide' else .54);oh=h*(.42 if optics=='wide' else .60)
    block('Lens border',0,-h*.045,d*.32,ow+.003,oh+.003,.004,.008,seam)
    block('Frosted lens',0,-h*.045,d*.37,ow,oh,.008,.009,lens)
    for i in range(1,6):
        block('Individual Fresnel band',0,-h*.045+oh*(i/6-.5),d*.37+.004,ow*(.80 if i in (1,5) else .93),.00065,.0006,.00025,line)
    for i in [-1,1]:
        if optics=='wide':block('Optical column',i*ow*.18,-h*.045,d*.37+.004,.00065,oh*.87,.0006,.00025,line)
    disk('Status lens',0,h*.32,d*.333,w*.029,.003,amber if n=='PGP9914' else base)
    label(n,0,-h*.39,d*.335,.0042)
    finish(n)
body(.061,.083,.042)
block('Open shell',0,0,0,.061,.083,.019,.010,white)
block('Circuit board',0,0,.011,.049,.070,.003,.002,pcb)
block('Battery cradle',0,-.015,.016,.037,.021,.007,.003,seam)
bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.0085,depth=.033,location=(0,-.021,-.015),rotation=(0,pi/2,0))
bpy.context.object.data.materials.append(cell);bpy.context.object.name='Battery'
block('PIR element',0,.011,.015,.012,.012,.006,.002,steel)
disk('Enroll switch',.015,.025,.015,.004,.004,amber)
for i in range(5):block('Surface-mount part',-.017+i*.007,.033,.014,.004,.003,.002,.0003,seam)
finish('PG9914-open')
