import * as T from 'three'
import type {RegisterPart} from './bench'
import {detail} from './visual'
import type {NeoState} from './neo-engine'

export const roomViews = [
 ['Door and sensors',-1,.36,.10,2.8],
 ['Cabinet and terminals',1.32,.61,.20,1.95],
 ['Battery and transformer',1.76,-.32,.19,1.79],
 ['Keypad',.09,.43,.14,.74]
] as const

type RoomContext={register:RegisterPart;scene:T.Scene;hit:(object:T.Object3D,action:()=>void)=>void}
type Actions={unpack:()=>void;cabinet:()=>void;cover:()=>void;board:()=>void;keypad:()=>void;key:(key:string)=>void;battery:()=>void;transformer:()=>void}
export function drawRoom(c:RoomContext,s:NeoState,a:Actions,readout:string){
 const {scene}=c
 const point=(x:number,y:number,z:number)=>new T.Vector3(x,y,z)
 function block(name:string,x:number,y:number,z:number,w:number,h:number,d:number,color:number,parent:T.Object3D=scene){
   const o=new T.Mesh(new T.BoxGeometry(w,h,d),new T.MeshStandardMaterial({color,roughness:.67}))
   o.name=name;o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o
 }
 function model(file:string,x:number,y:number,z:number,w:number,h:number,d:number,action?:()=>void){
   const group=new T.Group();group.position.set(x,y,z);scene.add(group)
   detail(group,file+'.glb',[0,0,0],[w,h,d])
   if(action){const hit=block(file,0,0,0,w,h,d,0,group);hit.visible=false;c.hit(hit,action)}
   return group
 }
 function label(value:string,x:number,y:number,z:number,w:number,h:number){
   const canvas=document.createElement('canvas');canvas.width=512;canvas.height=112
   const ctx=canvas.getContext('2d')!;ctx.fillStyle='#172931';ctx.fillRect(0,0,512,112)
   ctx.fillStyle='#f2f5ee';ctx.font='600 63px sans-serif';ctx.textAlign='center';ctx.fillText(value,256,77,488)
   const map=new T.CanvasTexture(canvas);map.colorSpace=T.SRGBColorSpace
   const mesh=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshBasicMaterial({map}));mesh.position.set(x,y,z);scene.add(mesh)
 }
 function cable(points:T.Vector3[],color:number,r=.024){
   const curve=new T.CatmullRomCurve3(points,false,'centripetal')
   const mesh=new T.Mesh(new T.TubeGeometry(curve,32,r,8,false),new T.MeshStandardMaterial({color,roughness:.72}))
   scene.add(mesh)
 }
 // The opening stays clear as the door swings into the room.
 for(const [x,y,w,h] of [[-2.13,.15,.79,3.45],[-.95,1.48,1.58,.79],[1.24,.15,2.80,3.45]]){
   block('Painted block wall',x,y,-.30,w,h,.17,0x849588)
 }
 const floor=block('Concrete floor',0,-1.60,1.08,5.2,.10,3.0,0x646a66);floor.receiveShadow=true
 block('Adjoining wall',-2.57,.12,.60,.13,3.45,1.92,0x758981)
 for(const [x,w] of [[-2.13,.79],[1.24,2.8]])block('Rubber baseboard',x,-1.49,-.18,w,.12,.05,0x4e5b55)
 block('Work shelf',-2.08,-.93,.31,.72,.10,.88,0x847967)
 for(const x of [-2.34,-1.82])block('Shelf leg',x,-1.25,.60,.065,.61,.065,0x4d5957)
 c.register('neo-backboard','Plywood backboard',block('Plywood backboard',1.27,.62,-.15,1.93,2.06,.11,0xb9905b),2.30)
 for(let i=0;i<16;i++){
   const grain=block('Plywood grain',1.27,.63+(i-7.5)*.12,-.092,1.82,.003,.004,i%2?0xc1a06c:0xa88458)
   grain.rotation.z=Math.sin(i)*.012
 }
 for(const x of [.39,2.15])for(const y of [-.31,1.55]){
   block('Backboard washer',x,y,-.075,.055,.055,.025,0x858d89)
   block('Fastener slot',x,y,-.057,.032,.007,.007,0x384742)
 }
 if(!s.board){
   model('neo-packing-tray',-2.08,-.74,.30,.66,.34,.23)
   if(!s.unpacked)c.register('neo-carton','Equipment carton',model('iq-box-lid',-2.08,-.74,.46,.67,.35,.05,a.unpack),.86)
   else c.register('neo-board','HS2032 control board',model('neo-hs2032-board',-2.08,-.74,.45,.59,.29,.10,a.board),.80)
 }
 if(!s.cabinet){
   const target=block('Cabinet mounting area',1.25,.68,-.077,1.5,1.65,.023,0x9f815b)
   c.hit(target,a.cabinet);c.register('neo-cabinet','Cabinet mounting position',target,2.15);label('Mount Neo cabinet',1.25,.73,-.056,1.04,.17)
 }else{
   c.register('neo-cabinet','Cabinet',model('neo-cabinet',1.25,.71,.012,1.68,1.87,.20),2.15)
   const hinge=new T.Group();hinge.position.set(2.09,.71,.14);hinge.rotation.y=s.coverOpen?2.15:0;scene.add(hinge)
   const cover=block('Hinged cabinet door',-.84,0,0,1.68,1.87,.055,0xb4baba,hinge)
   block('Cabinet latch',-1.55,0,.04,.07,.12,.036,0x465450,hinge);c.hit(cover,a.cover);c.register('neo-cover','Cabinet door',cover,2.15)
   if(s.coverOpen){
     if(s.board)c.register('neo-board','HS2032 control board',model('neo-hs2032-board',1.25,1.01,.15,1.47,.84,.16),1.68)
     else label('Seat HS2032',1.25,1.01,.17,.83,.14)
     c.register('neo-battery','Standby battery',block('12 V standby battery',1.08,-.035,.13,.63,.34,.23,0x293332),.78)
     label('12 V standby',1.08,-.035,.25,.53,.12)
     for(const [i,color] of [0xd44b40,0x384847].entries()){
       const x=.86+i*.43
       const tab=block('Battery terminal',x,.15,.17,.09,.053,.073,color);c.hit(tab,a.battery)
       cable([point(.85+i*.19,.58,.22),point(.74+i*.15,.41,.30),point(x,s.battery?.16:.25,.23)],color,.017)
     }
     label(s.battery?'Battery connected':'Connect battery',1.67,-.03,.27,.54,.10)
     const batteryPick=block('Battery harness',1.66,-.03,.32,.54,.14,.09,0)
     batteryPick.visible=false;c.hit(batteryPick,a.battery)
     for(const x of [.60,1.81]){
       block('Cable knockout',x,-.23,.12,.10,.045,.11,0x394747)
     }
   }
 }
 block('Receptacle plate',2.37,-.67,-.10,.31,.50,.075,0xf1ece0)
 for(const y of [-.77,-.59])for(const x of [2.33,2.41])block('Outlet slot',x,y,-.052,.014,.055,.008,0x41504a)
 const txY=s.ac?-.68:-1.02
 const tx=block('16.5 V AC transformer',2.38,txY,.067,.27,.27,.24,0xe3ded3)
 c.hit(tx,a.transformer);c.register('neo-transformer','16.5 V AC transformer',tx,.43);label('16.5 V AC',2.38,txY,.192,.25,.075)
 if(s.board){
   cable([point(2.38,txY-.13,.14),point(2.13,-.66,.04),point(1.81,-.24,.11),point(1.79,.50,.23)],0xd5d1bc)
   if(s.coverOpen)label('AC',1.79,.54,.26,.20,.075)
 }
 if(s.routed){
   cable([point(.08,.12,.07),point(.25,-.45,.04),point(.59,-.45,.06),point(.60,-.22,.13)],0xe2d9b9)
   for(const x of [.30,.47])block('Corbus cable clip',x,-.45,.068,.048,.062,.035,0x7b8075)
 }
 if(s.routed&&s.cabinet&&s.coverOpen){
   for(const [i,color] of [0xd95749,0x343e41,0xf0c849,0x56a875].entries()){
     const lead=s.ends[i].board
     if(!s.jacket.board)continue
     const x=1.55+(lead.terminal??i)*.09
     cable([point(.60+i*.013,-.22,.14),point(.64+i*.014,.34+i*.018,.18),
       point(x,lead.terminal===null?.39:.50,.22)],color,.010)
   }
   const terminals=block('Corbus inspect area',1.68,.50,.255,.39,.14,.055,0);terminals.visible=false;
   c.register('neo-board-corbus','Board Corbus terminals',terminals,.49)
   label('Corbus',1.67,.44,.23,.32,.067)
 }
 const keypadX=.09,keypadY=.43
 if(!s.keypad){
   const mount=block('HS2LCD mounting plate',keypadX,keypadY,-.10,.41,.30,.047,0xa8a797);c.hit(mount,a.keypad);c.register('neo-keypad','Keypad mounting plate',mount,.58)
   label('Mount keypad',keypadX,keypadY,-.067,.38,.08)
 }else{
   c.register('neo-keypad','HS2LCD keypad',model('neo-hs2lcd',keypadX,keypadY,.01,.45,.32,.095),.55)
   label(readout||'Offline',keypadX-.018,keypadY+.078,.073,.28,.056)
   for(const [i,key] of [...'123456789*0#'].entries()){
     const hit=block('Key '+key,keypadX+(-.16+i%3*.151)*.296,keypadY+(-.01-Math.floor(i/3)*.112)*.304,.074,.048,.034,.027,0)
     hit.visible=false;c.hit(hit,()=>a.key(key))
   }
 }
}

