"""Render the motion detector comparison from the exported Blender geometry."""
from pathlib import Path
import sys
import bpy
from mathutils import Vector

project=Path(sys.argv[-1]).resolve()
bpy.ops.wm.read_factory_settings(use_empty=True)
s=bpy.context.scene

def material():
    m=bpy.data.materials.new('Workbench ground')
    m.diffuse_color=(.105,.16,.18,1)
    m.use_nodes=True
    m.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=(.035,.060,.075,1)
    return m

for i,name in enumerate(['PG9914','PG9914-open','PGP9914','PG9924']):
    before=set(s.objects)
    bpy.ops.import_scene.gltf(filepath=str(project/'public'/'assets'/(name+'.glb')))
    rig=bpy.data.objects.new(name,None);s.collection.objects.link(rig)
    for o in set(s.objects)-before-{rig}:
        if not o.parent:o.parent=rig
    rig.location=((i-1.5)*.108,0,.057)

bpy.ops.mesh.primitive_plane_add(size=3,location=(0,0,0))
bpy.context.object.data.materials.append(material())
def aim(obj,target):obj.rotation_euler=(Vector(target)-obj.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(.03,-.65,.22))
camera=bpy.context.object;aim(camera,(0,0,.055))
camera.data.type='ORTHO';camera.data.ortho_scale=.47;s.camera=camera
def light(location,energy,size,color):
    bpy.ops.object.light_add(type='AREA',location=location);o=bpy.context.object
    aim(o,(0,0,.05));o.data.energy=energy;o.data.size=size;o.data.color=color
light((-.14,-.25,.34),8,.28,(1,.91,.81))
light((.19,-.14,.17),3,.20,(.77,.89,1))
light((.12,.13,.22),5,.19,(.84,.93,1))
s.world=bpy.data.worlds.new('Studio');s.world.color=(.26,.26,.26)
s.render.engine='CYCLES';s.cycles.samples=6;s.cycles.use_denoising=True
s.render.resolution_x=1320;s.render.resolution_y=515;s.render.resolution_percentage=100
s.render.filepath=str(project/'docs'/'Visual checks'/'Wireless motion models.png')
bpy.ops.render.render(write_still=True)

