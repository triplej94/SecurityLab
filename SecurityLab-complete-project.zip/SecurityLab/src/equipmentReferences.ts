type Reference = readonly [label:string,url:string]
type Visual = {kind:'Product photo'|'Installation diagram';image:string;source:string;alt:string;caption:string}
type Equipment = { id:string; name:string; model?:string; references:Reference[];visual:Visual }
type ListedPart = Omit<Equipment,'id'|'visual'> & {id?:string}
const photo=(image:string,source:string,alt:string,caption=alt):Visual=>({kind:'Product photo',image,source,alt,caption})
const diagram=(id:string,source:string,alt:string):Visual=>({kind:'Installation diagram',image:'./equipment/'+id+'.png',source,alt,caption:alt+' · SecurityLab illustration'})

const iqManual='https://docs.johnsoncontrols.com/dsc/api/khub/documents/r7kCPnzuFIlpB~1qNC9E7A/content'
const neoManual='https://cdn.thefirepanel.com/docs/dsc/Dsc%20-%20Hs2016%20Hs2032%20Hs2064%20Hs2128%20V1%2035%20Reference%20Manual%20English.pdf'
const iqPhoto:Reference=['Product photo','https://tyco.widen.net/content/ozrtfykncf/jpeg/Front_IQ%20Panel%205_694x400.jpeg?color=ffffffff&position=c&quality=80&u=ka7j8u']
const iqSheet:Reference=['Datasheet','https://d1unzhqf5a606m.cloudfront.net/documents/iq-panel-5-specifications-sheet.pdf?1769718523=']
const contactPhoto:Reference=['Product photo (transmitter and magnet)','https://d1unzhqf5a606m.cloudfront.net/images/product/dsc-pg9945-powerg-915mhz-wireless-door-window-contact.jpg?1695224997=']
const contactSheet:Reference=['Datasheet','https://docs.johnsoncontrols.com/dsc/api/khub/documents/GU0k8p1RYMPQxtsF4zSVXw/content']
const contactDiagram:Reference=['Installation diagram · p. 1','https://d1unzhqf5a606m.cloudfront.net/documents/dsc-pg9945-installation-manual.pdf?1532905816=#page=1']

const listedParts:ListedPart[]=[
 {name:'IQ Panel 5 · front housing',model:'iq-panel-front',references:[iqPhoto,iqSheet,['Installation diagram · p. 9',iqManual+'#page=9'],['Battery and power connections · p. 12',iqManual+'#page=12']]},
 {name:'IQ Panel 5 · rear connections',model:'iq-panel-rear',references:[['Interior diagram · p. 7',iqManual+'#page=7'],iqSheet,['Battery and power connections · p. 12',iqManual+'#page=12']]},
 {name:'IQ Panel 5 · SmartMount backplate',model:'iq-smartmount',references:[['Installation diagram · p. 9',iqManual+'#page=9'],iqSheet]},
 {name:'IQ Panel 5 · supplied 12 V DC adapter',model:'iq-adapter',references:[['Interior diagram · p. 7',iqManual+'#page=7'],['Power wiring diagram · p. 11',iqManual+'#page=11'],['Power-up instructions · p. 12',iqManual+'#page=12'],iqSheet]},
 {name:'PG9945 transmitter',model:'iq-contact',references:[contactPhoto,contactSheet,contactDiagram]},
 {name:'PG9945 magnet',model:'iq-magnet',references:[contactPhoto,contactSheet,contactDiagram]},
 {name:'PG9914 motion detector',model:'PG9914',references:[['Product photo','https://d1unzhqf5a606m.cloudfront.net/images/product/dsc-pg9914-powerg-915mhz-out-wireless-motion-detector.png?1531939271='],['Datasheet','https://docs.johnsoncontrols.com/dsc/api/khub/documents/ZmWGfUVG092i5r96ET~4iA/content']]},
 {name:'PG9914 · cover removed',model:'PG9914-open',references:[['Installation diagram · p. 1','https://docs.johnsoncontrols.com/dsc/api/khub/documents/lUF4uSMvG9eVMB_9rw413Q/content#page=1'],['Datasheet','https://docs.johnsoncontrols.com/dsc/api/khub/documents/ZmWGfUVG092i5r96ET~4iA/content']]},
 {name:'PGP9914 PowerG+ indoor motion',model:'PGP9914',references:[['Product photo','https://tyco.widen.net/content/rvptultaes/jpeg/Front_PowerG%20%2B%20Motion_694x400.jpeg?color=ffffffff&position=c&quality=80&u=ka7j8u'],['Datasheet','https://tyco.widen.net/s/wq2wjvczn7/pgp9914_spec_sheet_english']]},
 {name:'PG9924 curtain motion detector',model:'PG9924',references:[['Product photo','https://tyco.widen.net/content/ionxcmqtkp/jpeg/SEC_Commercialproductdetail_product_Front_PowerG%20Curtain%20PIR%20Motion%20Detector_1.jpeg?color=ffffffff&position=c&quality=80&u=ytcytf'],['Datasheet','https://docs.johnsoncontrols.com/dsc/api/khub/documents/kB6PKPRv1m5XxyeDX2UHsw/content']]},
 {name:'Honeywell 7939WG · wired contact',model:'7939WG',references:[['Product photo · Resideo','https://www.resideo.com/us/en/pro/products/security/wired-sensors/wired-contacts/surface-mount/7939wg-wh-surface-mount-magnetic-contact-with-terminals-white-7939wg-wh/'],['Datasheet · p. 2','https://prod-edam.honeywell.com/content/dam/honeywell-edam/hbt/en-us/documents/literature-and-specs/datasheets/hon-ba-omincatin-surfacemount.pdf#page=2']]},
 {name:'Honeywell 7939WG · moving magnet',model:'7939WG-magnet',references:[['Product photo · Resideo','https://www.resideo.com/us/en/pro/products/security/wired-sensors/wired-contacts/surface-mount/7939wg-wh-surface-mount-magnetic-contact-with-terminals-white-7939wg-wh/'],['Datasheet · p. 2','https://prod-edam.honeywell.com/content/dam/honeywell-edam/hbt/en-us/documents/literature-and-specs/datasheets/hon-ba-omincatin-surfacemount.pdf#page=2']]},
 {name:'DSC LC-100-PI · wired motion',model:'LC-100-PI',references:[['Manufacturer product page','https://www.dsc.com/alarm-security-products/LC-100%20PI%20-%20LC-100%20PI/1019'],['Installation diagram · p. 1','https://cdn.thefirepanel.com/docs/dsc/Dsc%20-%20Lc100pi%20Lc120pi%20Installation%20Manual%20En%20Sp%20Fr%20Ita%20Pol.pdf']]},
 {name:'DSC LC-100-PI · wiring terminals',model:'LC-100-PI-open',references:[['Manufacturer product page','https://www.dsc.com/alarm-security-products/LC-100%20PI%20-%20LC-100%20PI/1019'],['Installation diagram · p. 1','https://cdn.thefirepanel.com/docs/dsc/Dsc%20-%20Lc100pi%20Lc120pi%20Installation%20Manual%20En%20Sp%20Fr%20Ita%20Pol.pdf']]},
 {name:'IQ Panel 5 · battery pack',model:'iq-battery',references:[['Installation diagram',iqManual+'#page=12']]},
 {name:'HS2032 control board',model:'neo-hs2032-board',references:[['Product photo','https://cdn11.bigcommerce.com/s-xzfjt4oy/products/436/images/103239/hs2032pcb__92292.1692721434.600.600.png?c=2'],['Manufacturer specifications','https://docs.johnsoncontrols.com/dsc/r/DSC/en-US/PowerSeries-Neo-HS2016/HS2016-4/HS2032/HS2064/HS2064-E/HS2128/HS2128-E-Alarm-Control-Installation-Guide-TIS/1.35/Specifications'],['Installation diagram · p. 253',neoManual+'#page=253']]},
 {name:'HS2LCD keypad',model:'neo-hs2lcd',references:[['Product photo on GeoArm','https://www.geoarm.com/hs2lcd-dsc-full-message-lcd-hardwired-keypad.html'],['Datasheet','https://www.spy-shop.ro/fileuploader/download/download/?d=0&file=custom%2Fupload%2FFisa_tehnica_Tastatura_LCD_NEO_HS2LCD.pdf'],['Installation instructions','https://docs.johnsoncontrols.com/dsc/api/khub/documents/VbwQ79Y6X2gWDQV~8dR1qA/content']]},
 {name:'HS2032 · Corbus terminal clamp',model:'neo-corbus-clamp',references:[['Control board photo','https://cdn11.bigcommerce.com/s-xzfjt4oy/products/436/images/103239/hs2032pcb__92292.1692721434.600.600.png?c=2'],['Terminal diagram and descriptions · p. 22',neoManual+'#page=22']]},
 {name:'HS2032 · Neo enclosure',model:'neo-cabinet',references:[['Enclosure installation · p. 21',neoManual+'#page=21'],['Cabinet and wiring diagram · p. 253',neoManual+'#page=253'],['Connecting power','https://docs.johnsoncontrols.com/dsc/r/DSC/en-US/PowerSeries-Neo-HS2016/HS2016-4/HS2032/HS2064/HS2064-E/HS2128/HS2128-E-Alarm-Control-Installation-Guide-TIS/1.35/Installation/Current-Ratings/Connecting-Power']]},
 {id:'neo-battery',name:'DSC BD7-12 · standby battery',references:[['Distributor product page','https://www.jmac.com/DSC_BD7_12_p/TYCO-DSC-BD7-12.htm']]},
 {id:'neo-transformer',name:'DSC PTC1640CG · 16.5 V AC transformer',references:[['Connecting power',neoManual+'#page=24']]},
]

const contact=photo(contactPhoto[1],contactPhoto[1],'DSC PG9945 wireless door contact kit','The larger housing is the transmitter. The smaller piece is the magnet.')
const resideo='https://www.resideo.com/us/en/pro/products/security/wired-sensors/wired-contacts/surface-mount/7939wg-wh-surface-mount-magnetic-contact-with-terminals-white-7939wg-wh/'
const lcPage='https://www.geoarm.com/lc-100pi-dsc-pet-immune-motion-detector.html'
const cabinetPage='https://www.dsc.com/alarm-security-products/PC5003C%20-%20PC5003C/1058'
const iqInteriorSource='https://support.suretyhome.com/t/how-to-install-the-iq-card-legacy-radio-into-the-iq-panel-5/48585'
const iqInterior='https://cdn-424.communiteq-cloud.com/uploads/db7965/original/2X/d/da27b8c87f83098754b55aadd0392a7e0eab7548.jpeg'
const wiredContact=photo('https://www.worldeyecam.com/images/product/7939WG-WH-c1-6-alt-1.jpg',resideo,'Honeywell 7939WG-WH contact set','The piece with screw terminals is the switch. The matching piece is the magnet.')
const pgMotion='https://docs.johnsoncontrols.com/dsc/api/khub/documents/lUF4uSMvG9eVMB_9rw413Q/content#page=1'
const visuals:Record<string,Visual>={
 'iq-panel-front':photo(iqPhoto[1],'https://www.iqsecurityproducts.com/panels/iqpanel5_sec','Qolsys IQ Panel 5 front and touchscreen'),
 'iq-panel-rear':photo(iqInterior,iqInteriorSource,'IQ Panel 5 rear housing with backplate removed'),
 'iq-smartmount':diagram('iq-smartmount',iqManual+'#page=9','SmartMount wall plate and panel locking screw'),
 'iq-adapter':diagram('iq-adapter',iqManual+'#page=11','Supplied 12 V DC adapter and barrel connector'),
 'iq-battery':photo(iqInterior,iqInteriorSource,'IQ Panel 5 battery pack shown inside the panel'),
 'iq-contact':contact,
 'iq-magnet':contact,
 PG9914:photo(listedParts.find(part=>part.model==='PG9914')!.references[0][1],pgMotion,'DSC PG9914 wireless motion detector with cover installed'),
 'PG9914-open':diagram('PG9914-open',pgMotion,'PG9914 battery compartment and enrollment control'),
 PGP9914:photo(listedParts.find(part=>part.model==='PGP9914')!.references[0][1],listedParts.find(part=>part.model==='PGP9914')!.references[1][1],'DSC PGP9914 PowerG+ motion detector'),
 PG9924:photo(listedParts.find(part=>part.model==='PG9924')!.references[0][1],listedParts.find(part=>part.model==='PG9924')!.references[1][1],'DSC PG9924 curtain motion detector'),
 '7939WG':wiredContact,
 '7939WG-magnet':wiredContact,
 'LC-100-PI':photo('https://s.turbifycdn.com/aah/yhst-51756635596032/lc-100pi-dsc-pet-immune-motion-detector-55-lbs-93.png',lcPage,'DSC LC-100-PI detector and its Fresnel lens'),
 'LC-100-PI-open':diagram('LC-100-PI-open',listedParts.find(part=>part.model==='LC-100-PI-open')!.references[1][1],'LC-100-PI low-voltage power and alarm relay terminals'),
 'neo-hs2032-board':photo(listedParts.find(part=>part.model==='neo-hs2032-board')!.references[0][1],'https://shop.ssandsi.com/dsc-powerseries-neo-alarm-panel-board-32-zone-pcb-only-hs2032pcb/','DSC HS2032 control board and screw terminal strip'),
 'neo-hs2lcd':photo('https://s.turbifycdn.com/aah/yhst-51756635596032/hs2lcd-dsc-full-message-lcd-hardwired-alarm-keypad-for-powerseries-neo-control-panel-79.png','https://www.geoarm.com/hs2lcd-dsc-full-message-lcd-hardwired-keypad.html','DSC HS2LCD keypad with the key cover closed'),
 'neo-corbus-clamp':diagram('neo-corbus-clamp',neoManual+'#page=22','HS2032 Corbus terminals RED, BLK, YEL and GRN'),
 'neo-cabinet':photo('https://cdn11.bigcommerce.com/s-xzfjt4oy/images/stencil/500x659/products/487/103393/3w-pc5003c_lg__41337.1692721493.jpg?c=2',cabinetPage,'DSC PC5003C metal cabinet, an example of the enclosure shown in the lab'),
 'neo-battery':photo('https://cdn11.bigcommerce.com/s-xw7e0ujcno/products/169717/images/4748196/65dc2999ceb1846e940b1f65271cb99402b9526cde1dee8e00e54d14b1220919__02699.1720444978.386.513.jpg?c=1','https://www.jmac.com/DSC_BD7_12_p/TYCO-DSC-BD7-12.htm','DSC BD7-12 standby battery, an example of the 12 V battery shown in the cabinet'),
 'neo-transformer':photo('https://cdn11.bigcommerce.com/s-b8b6a/images/stencil/1280x1280/products/4570/9351/Photoroom_000_20250703_135546__87587.1751561802.jpg?c=2','https://docs.johnsoncontrols.com/dsc/r/DSC/en-US/PowerSeries-Neo-HS2016/HS2016-4/HS2032/HS2064/HS2064-E/HS2128/HS2128-E-Alarm-Control-Installation-Guide-ADT/1.35/Aux-Loading-and-Battery-Selection','DSC PTC1640CG plug-in transformer rated 16.5 V AC')
}
export const equipment:Equipment[]=listedParts.map(part=>{
 const id=(part.id??part.model)!
 return {...part,id,visual:visuals[id]}
})

export function evidenceSource(title:string,page:string){
 const firstPage=Number.parseInt(page,10)
 if(title.startsWith('IQ Panel 5 Installation'))return iqManual+(firstPage?'#page='+firstPage:'')
 if(/^(PowerSeries Neo Reference|Neo Reference)/.test(title))return neoManual+(firstPage?'#page='+firstPage:'')
 if(title.startsWith('PG9945 /'))return contactDiagram[1]
 if(title.startsWith('HS2LCD family'))return 'https://docs.johnsoncontrols.com/dsc/api/khub/documents/VbwQ79Y6X2gWDQV~8dR1qA/content'+(firstPage?'#page='+firstPage:'')
 if(title.startsWith('DSC LC-100-PI'))return equipment.find(part=>part.id==='LC-100-PI-open')?.visual.source
 if(title.startsWith('Honeywell surface'))return equipment.find(part=>part.id==='7939WG')?.references[1]?.[1]
 if(title.startsWith('DSC PowerSeries Neo Installation'))return equipment.find(part=>part.id==='neo-cabinet')?.references[2]?.[1]
}
export function equipmentSelector(content:HTMLElement, lab:'iq'|'neo', modelsOnly=false){
 const options=equipment
 const label=document.createElement('label')
 label.className='equipment-selector'
 label.textContent='Equipment'
 const select=document.createElement('select')
 select.setAttribute('aria-label',modelsOnly?'Inspect equipment model':'Choose equipment reference')
 for(const item of options)select.add(new Option(item.name,item.id))
 if(lab==='neo')select.value='neo-hs2032-board'
 label.append(select)
 const links=document.createElement('nav')
 links.className='equipment-references'
 links.setAttribute('aria-label','Equipment photos and documents')
 const current=()=>options[select.selectedIndex]
 function showReferences(){
   links.replaceChildren(...current().references.map(([name,url])=>{
     const a=document.createElement('a')
     a.href=url
     a.target='_blank'
     a.rel='noopener noreferrer'
     a.textContent=name
     return a
   }))
 }
 select.addEventListener('change',showReferences)
 content.append(label,links)
 showReferences()
 return {select,current}
}





