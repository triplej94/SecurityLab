# DSC Neo mechanical room

Open **DSC Neo** to see the full installation wall. The carton sits on the work shelf. Fit the cabinet to the plywood backboard, open its door, and seat the HS2032. The HS2LCD mounts beside the door. The 7939WG and LC-100-PI mount at the header and above the door.

The **Corbus terminal close-up** enlarges both ends of the keypad cable. Return to the mechanical room to land field conductors at the labeled cabinet terminals. The room and the close-up share the same conductor placements and power state. The wall keypad supports enrollment, confirmation, zone programming, and trip and restore feedback.

Finish and inspect both wiring systems before powering up. Click the battery terminals inside the cabinet and then the transformer beside it. The inspector offers the same actions. Select **Isolate power** before any wiring changes. The power hardware and the enlarged service terminals use illustrative geometry based on the Neo v1.35 installation guide. The receptacle and power sources operate only within the simulator.

[DSC Neo v1.35 power connection guidance](https://docs.johnsoncontrols.com/dsc/r/DSC/en-US/PowerSeries-Neo-HS2016/HS2016-4/HS2032/HS2064/HS2064-E/HS2128/HS2128-E-Alarm-Control-Installation-Guide-TIS/1.35/Installation/Current-Ratings/Connecting-Power)

