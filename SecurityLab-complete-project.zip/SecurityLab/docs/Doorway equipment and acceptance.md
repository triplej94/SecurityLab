# Doorway installation equipment

| Station | Equipment learners handle | What to inspect |
|---|---|---|
| Wireless panel | IQ Panel 5, SmartMount backplate, standby battery, supplied 12 V adapter | Front and rear views, battery plug, locking screw and power jack |
| Wireless door | DSC PG9945 and magnet | Transmitter on the fixed header, magnet on moving leaf, enrollment switch and alignment |
| Wireless motion | DSC PG9914 | Closed housing, open cover, enroll switch and direction of travel |
| Wireless comparison | DSC PGP9914 and PG9924 | Indoor and curtain motion housings in Equipment Explorer |
| Wired panel | DSC PowerSeries Neo HS2032, cabinet, mounting hardware, standby battery and transformer supply | Carton, protective tray, standoffs, board, screw terminals and power controls |
| Keypad | DSC HS2LCD, keypad flap, four-conductor cable and Corbus clamps | LCD and status lights, physical keys, bus power and data continuity |
| Wired door | Honeywell 7939WG-WH switch and magnet | Header placement, magnetic alignment, two-lead relay loop and field resistor |
| Wired motion | DSC LC-100-PI | Cover, alarm relay NC/C, EOL tie point, DC terminals, cable and field resistor |

## Training conventions

Both stations simulate an installation on a local browser profile. The models use original illustrative geometry. The field terminal strip is enlarged for tracing connections. The carton illustrates unpacking and makes no claim about a particular sales bundle. Neo transformer and battery connections are operated through the power controls. Field conductors are pre-stripped at the sensor end. A single resistor action represents fitting the 5.6 kΩ resistor in series at the device. The walk-test control represents crossing and leaving the room.

The simulated HS2LCD programming menu covers the sections used in this exercise. Zone definitions, partition assignment and loop supervision are stored separately. The two training zones start unassigned. Learners can trace an installation fault from the device to its assigned terminal before retesting.

## References

The Equipment Explorer links the wired contact to the Resideo 7939WG-WH product and Honeywell catalogue, PDF page 2. The DSC LC-100-PI product and installation sheet identify the lens, terminals and mounting options, PDF page 1. The Neo v1.35 reference manual covers SEOL on pages 31–32, system option 013 on pages 111–112, zone definitions on pages 82–83 and partition-zone assignment on page 189. The PG9914 installation sheet gives a mounting range of 1.8–2.4 m. This scene illustrates 2.2 m.

