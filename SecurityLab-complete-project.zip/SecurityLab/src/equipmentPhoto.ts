import {equipment} from './equipmentReferences'

export function equipmentPhoto(id:string,compact=false){
 const item=equipment.find(part=>part.id===id)
 if(!item)throw new Error('Unknown equipment reference: '+id)
 const visual=item.visual
 const figure=document.createElement('figure')
 figure.className='equipment-photo'+(compact?' compact':'')
 const caption=document.createElement('figcaption')
 const title=document.createElement('strong')
 title.textContent=item.name
 const description=document.createElement('span')
 description.textContent=visual.caption
 const source=document.createElement('a')
 source.href=visual.source
 source.target='_blank'
 source.rel='noopener noreferrer'
 source.textContent='View source'
 caption.append(title,description,source)
 const image=document.createElement('img')
 image.loading=compact?'lazy':'eager'
 image.decoding='async'
 image.referrerPolicy='no-referrer'
 image.alt=visual.alt
 const open=document.createElement('button')
 open.type='button'
 open.className='equipment-photo-open'
 open.ariaLabel='Enlarge '+item.name+' '+visual.kind.toLowerCase()
 open.append(image)
 const kind=document.createElement('small')
 kind.textContent=visual.kind
 figure.append(kind,open,caption)
 image.onerror=()=>{
   open.hidden=true
   description.textContent=visual.caption+' Image unavailable. Open the source to view the reference.'
 }
 image.src=visual.image
 open.onclick=()=>{
   const dialog=document.createElement('dialog')
   dialog.className='equipment-photo-dialog'
   const heading=document.createElement('h2')
   heading.textContent=item.name
   const large=image.cloneNode() as HTMLImageElement
   large.loading='eager'
   const close=document.createElement('button')
   close.type='button'
   close.textContent='Close photo'
   close.onclick=()=>dialog.close()
   dialog.append(heading,close,large,caption.cloneNode(true))
   dialog.addEventListener('close',()=>{dialog.remove();if(open.isConnected)open.focus()},{once:true})
   document.body.append(dialog)
   dialog.showModal()
   close.focus()
 }
 open.onkeydown=event=>{
   if(event.key!=='Enter'||event.repeat)return
   event.preventDefault()
   open.click()
 }
 return figure
}

export function equipmentPhotos(parent:HTMLElement,...ids:string[]){
 const group=document.createElement('div')
 group.className='equipment-photos'
 for(const id of ids)group.append(equipmentPhoto(id,true))
 parent.append(group)
}

