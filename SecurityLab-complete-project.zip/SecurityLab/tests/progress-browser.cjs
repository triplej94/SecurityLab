const {spawn}=require('child_process'),path=require('path'),fs=require('fs'),assert=require('assert/strict');
const {pathToFileURL}=require('url');
const os=require('node:os');const profile=fs.mkdtempSync(path.join(os.tmpdir(),'securitylab-neo-'));const exe=process.env.BROWSER_EXECUTABLE||'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const proc=spawn(exe,['--headless=new','--use-angle=swiftshader','--enable-unsafe-swiftshader','--window-size=1400,1000','--no-first-run','--disable-background-networking','--remote-debugging-pipe','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','ignore','pipe','pipe'],windowsHide:true});
let seq=0,pending=new Map(),buffer='',session,errors=[];
proc.stdio[4].on('data',chunk=>{buffer+=chunk;while(buffer.includes('\0')){const j=buffer.indexOf('\0');const v=JSON.parse(buffer.slice(0,j));buffer=buffer.slice(j+1);if(v.method==='Runtime.exceptionThrown')errors.push(v.params.exceptionDetails.exception?.description??v.params.exceptionDetails.text);if(pending.has(v.id)){pending.get(v.id)(v);pending.delete(v.id)}}});
function call(method,params={},id){return new Promise((resolve,reject)=>{const n=++seq;pending.set(n,v=>v.error?reject(Error(v.error.message)):resolve(v.result));proc.stdio[3].write(JSON.stringify({id:n,method,params,sessionId:id})+'\0')})}
async function run(code){const r=await call('Runtime.evaluate',{expression:code,returnByValue:true},session);if(r.exceptionDetails)throw Error(r.exceptionDetails.exception.description);return r.result.value}
const click=t=>run("(()=>{const b=[...document.querySelectorAll('button')].find(b=>b.textContent==="+JSON.stringify(t)+");if(!b)throw Error('Missing button: '+"+JSON.stringify(t)+");b.click()})()");
const wait=ms=>new Promise(r=>setTimeout(r,ms));

const base=path.resolve(__dirname,'../dist');
const http=require('http').createServer((req,res)=>{const segment=new URL(req.url,'http://localhost').pathname;const file=path.join(base,segment==='/'?'index.html':segment);try{const data=fs.readFileSync(file);res.writeHead(200,{'Content-Type':({'.js':'text/javascript','.html':'text/html','.css':'text/css','.json':'application/json'})[path.extname(file)]||'application/octet-stream'});res.end(data)}catch{res.writeHead(404);res.end()}});
http.listen(0,'127.0.0.1');
const timer=setTimeout(()=>{console.error('Timeout');proc.kill();process.exit(1)},240000);
(async()=>{
 const tab=await call('Target.createTarget',{url:'about:blank'});session=(await call('Target.attachToTarget',{targetId:tab.targetId,flatten:true})).sessionId;await call('Runtime.enable',{},session);
 await call('Page.navigate',{url:'http://127.0.0.1:'+http.address().port},session);
 for(let i=0;i<120&&!await run("document.querySelector('#title')?.textContent");i++)await wait(180);
 await run("localStorage.clear()");await call('Page.reload',{},session);for(let i=0;i<100&&!await run('document.getElementById('+JSON.stringify('title')+')?.textContent');i++)await wait(150);await click('DSC Neo');
 const select=(selector,value)=>run("(()=>{const s=document.querySelector("+JSON.stringify(selector)+");s.value="+JSON.stringify(value)+";s.dispatchEvent(new Event('change',{bubbles:true}))})()");
 const state=()=>run("JSON.parse(localStorage.getItem('securitylab.bench.v1'))");
 await click('IQ Panel 5');
 await select('[aria-label="Jump to step"]','4');
 let saved=await state();assert.equal(saved.iq.on,true);assert.equal(saved.iq.motionZone.name,'Hall Motion');assert.equal(saved.iq.testedOpen,false);assert.equal(saved.iq.motionTested,false);assert.equal(saved.progress.iq.skipped.length,4);
 assert.match(await run("document.querySelector('#score').textContent"),/0 of 7/);
 await click('Walk across hallway');assert.match(await run("document.querySelector('#score').textContent"),/1 of 7/);
 await click('Undo');assert.equal((await state()).iq.motionTested,false);
 await call('Page.reload',{},session);for(let i=0;i<100&&!await run('Boolean(document.querySelector(' + JSON.stringify('#step-list select') + '))');i++)await wait(150);
 assert.equal((await state()).progress.iq.skipped.length,4);
 await select('[aria-label="Jump to step"]','2');
 await click('Open door');await click('Close door');assert.equal((await state()).progress.iq.skipped.includes('iq-door-test'),false);
 await select('[aria-label="Jump to step"]','1');await click('Practice skipped step');
 saved=await state();assert.equal(saved.iq.zone,null);assert.equal(saved.iq.on,true);assert.equal(saved.progress.iq.practice[0],'iq-contact');
 await click('Undo');assert.equal((await state()).iq.zone.name,'Front Door');
 await click('DSC Neo');await click('Skip this step');
 saved=await state();assert.equal(saved.neo.board,true);assert.equal(saved.neo.service,true);assert.deepEqual(saved.progress.neo.skipped,['neo-mount']);
 await select('[aria-label="Jump to step"]','5');
 saved=await state();assert.deepEqual(saved.neo.field.types,['001','005']);assert.equal(saved.neo.ac,true);assert.deepEqual(saved.neo.field.restored,[false,false]);assert.equal(saved.progress.neo.skipped.length,5);
 await click('Fit view');await click('Inspect devices');await wait(500);
 assert.equal(await run("[...document.querySelector('#closeup').options].some(o=>o.value==='neo-pir')"),true);
 const projection=await run("(()=>{let b=document.querySelector('#bench canvas');b.scrollIntoView({block:'center'});let r=b.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}})()");
 const z=.18,scale=projection.h/(2*Math.tan(16*Math.PI/180)*(Math.max(5.6,5.6*projection.h/projection.w)*1.86+.21-z));
 const point={x:projection.x+projection.w/2-1.04*scale,y:projection.y+projection.h/2-(1.35-.14)*scale};
 await call('Input.dispatchMouseEvent',{type:'mousePressed',...point,button:'left',buttons:1,clickCount:1},session);
 await call('Input.dispatchMouseEvent',{type:'mouseReleased',...point,button:'left',buttons:0,clickCount:1},session);
 assert.equal(await run("document.querySelector('#closeup').value"),'neo-pir');
 assert.equal((await state()).neo.field.motion,false);
 await click('Work mode');await click('Open front door');await click('Close front door');await click('Walk across detection area');await click('Leave detection area');
 assert.equal((await state()).neo.field.restored.every(Boolean),true);
 assert.match(await run("document.querySelector('#score').textContent"),/2 of 9/);
 await select('#mode','Assessment');
 assert.equal(await run("document.querySelector('[aria-label=\"Jump to step\"]')===null"),true);
 await select('#mode','Guided');
 await click('Equipment explorer');for(let i=0;i<100&&!await run('document.querySelectorAll(' + JSON.stringify('#dialog article a') + ').length>15');i++)await wait(150);
 const scroll=()=>run("document.querySelector('#dialog #content').scrollTop");
 const results=await run("document.querySelectorAll('#dialog #content article a').length");assert(results>15);
 const viewport=await run("(()=>{const r=document.querySelector('#dialog #content').getBoundingClientRect();return {x:r.right-25,y:r.bottom-14}})()");
 await call('Input.dispatchMouseEvent',{type:'mouseWheel',...viewport,deltaX:0,deltaY:1200},session);await wait(350);assert((await scroll())>0);
 await run("document.querySelector('#dialog #content').focus()");
 await call('Input.dispatchKeyEvent',{type:'keyDown',key:'End',code:'End',windowsVirtualKeyCode:35,nativeVirtualKeyCode:35},session);
 await call('Input.dispatchKeyEvent',{type:'keyUp',key:'End',code:'End',windowsVirtualKeyCode:35,nativeVirtualKeyCode:35},session);await wait(350);
 assert.equal(await run("(()=>{const e=document.querySelector('#dialog #content');return Math.abs(e.scrollHeight-e.clientHeight-e.scrollTop)<3})()"),true);
 await call('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true},session);
 await call('Emulation.setTouchEmulationEnabled',{enabled:true,maxTouchPoints:1},session);
 await run("document.querySelector('#dialog #content').scrollTop=0");
 const swipe=await run("(()=>{const r=document.querySelector('#dialog #content').getBoundingClientRect();return {x:r.right-17,y:r.bottom-28}})()");
 await call('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[swipe]},session);
 for(const dy of [35,78,120]){await call('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:swipe.x,y:swipe.y-dy}]},session);await wait(28)}
 await call('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]},session);await wait(250);
 assert((await scroll())>0,'A swipe outside the canvas must scroll Explorer');
 await click('Close');await click('IQ Panel 5');await click('Fit view');await click('Inspect devices');await wait(450);
 assert(await run("[...document.querySelector('#closeup').options].some(o=>o.value==='iq-magnet')"));
 await select('#closeup','iq-pir');assert.equal(await run("document.querySelector('#closeup').value"),'iq-pir');
 assert.equal((await state()).iq.motionDetected,false);
 await click('Work mode');await click('DSC Neo');
 await click('Reset exercise');await click('Reset this exercise');
 saved=await state();assert.deepEqual(saved.progress.neo.skipped,[]);assert.equal(saved.iq.zone.name,'Front Door');
 assert.deepEqual(errors,[]);console.log('Passed both lab shortcuts, credit, undo, restore, replay, assessment, Neo inspect click, Explorer scroll, source links and independent reset.');

})().catch(e=>{console.error(e,errors);return run("document.body.innerText.slice(0,900)").then(t=>{console.log(t);process.exitCode=1})}).finally(async()=>{http.close();clearTimeout(timer);await call('Browser.close').catch(()=>{});proc.kill()});













