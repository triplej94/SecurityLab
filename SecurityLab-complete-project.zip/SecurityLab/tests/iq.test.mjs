import {test} from 'node:test'
import assert from 'node:assert/strict'
import {readFile} from 'node:fs/promises'
import ts from 'typescript'

const source=await readFile(new URL('../src/iqState.ts',import.meta.url),'utf8')
const code=ts.transpile(source,{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022})
const {initialIQ,installAction,moveDoor,placePart,contactClosed,iqChecks}=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'))

test('a missing rear connection prevents latching and power-up',()=>{
  const s=initialIQ()
  assert.ok(installAction(s,'on'))
  for(const key of ['box','unpacked','loose','plateOff','plateMounted'])assert.equal(installAction(s,key),null)
  assert.ok(installAction(s,'cable'))
  assert.ok(installAction(s,'seated'))
  for(const key of ['battery','cable','seated','secured','adapter','on'])assert.equal(installAction(s,key),null)
  assert.ok(s.on && s.secured)
})

test('an open/close test reflects the installed magnet, including repair',()=>{
  const s=initialIQ()
  Object.assign(s,{on:true,identified:true,zone:{name:'Front Door',group:'10',chime:'Default',voice:true}})
  placePart(s,'transmitter','frame');placePart(s,'magnet','wide')
  assert.equal(contactClosed(s),false)
  moveDoor(s);moveDoor(s);assert.equal(s.testedOpen,false)
  placePart(s,'magnet','aligned');assert.equal(contactClosed(s),true)
  assert.equal(moveDoor(s),'Front Door · Open');assert.equal(moveDoor(s),'Front Door · Closed')
  assert.equal(iqChecks(s)[4].pass,true)
  placePart(s,'magnet','bench');assert.equal(iqChecks(s)[4].pass,false)
})

