# Source and asset inventory

The inventory covers 174 files in the DSC and IQ Documentation Repository. Every entry has a repository-relative path and SHA-256 digest. Open the CSV in a spreadsheet to filter by title, path, model, or extension. Page matches are search aids and may include indexes. Only the individually listed evidence rules have been checked for training use. PDF metadata dates are file metadata, not confirmed publication dates.

- 1 .blend files
- 11 .csv files
- 3 .glb files
- 1 .html files
- 15 .md files
- 93 .pdf files
- 22 .png files
- 3 .txt files
- 25 .url files

| Reusable model | Nodes | Mesh definitions | Materials |
|---|---:|---:|---:|
| IQ Panel 5.glb | 17 | 16 | 6 |
| PG9914.glb | 10 | 9 | 4 |
| PG9945.glb | 5 | 4 | 3 |

Existing models cover the exterior IQ5, PG9945 and PG9914. The Blender scene contains the installed entryway. Existing rendered illustrations and distributor photos are private references. Geometry inside the units, mating surfaces, PCB dimensions and screw mechanics require original meshes or clearly identified approximations.
