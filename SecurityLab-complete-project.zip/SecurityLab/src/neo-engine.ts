import {newField,zoneReady} from './field-engine';
export const terminals = ['RED','BLK','YEL','GRN'] as const;
export type Side = 'board' | 'keypad';
export type End = { stripped:boolean; terminal:number | null; tight:boolean; position:[number,number] | null };
export type NeoState = ReturnType<typeof initialNeo>;
const freshEnd = ():End => ({stripped:false,terminal:null,tight:false,position:null});
export function initialNeo(){
  return {
    cabinet:false,coverOpen:true,service:false,unpacked:false,flap:true,field:newField(),board:false,keypad:false,cable:false,routed:false,bend:[0,-1.28] as [number,number],
    jacket:{board:false,keypad:false}, ends:Array.from({length:4},()=>({board:freshEnd(),keypad:freshEnd()})),
    side:'board' as Side,wire:0, battery:false,ac:false,enrolled:false,inspected:false,
    confirmed:false,keys:'',lcd:'',test:'',tool:'select'
  };
}
export function physicalCircuit(s:NeoState){
  const pairs=s.ends.filter(w=>w.board.stripped && w.board.tight && w.keypad.stripped && w.keypad.tight && w.board.terminal!==null && w.keypad.terminal!==null);
  const line=(terminal:number)=>pairs.some(w=>w.board.terminal===terminal && w.keypad.terminal===terminal);
  const powered=s.ac && s.board && s.keypad && line(0) && line(1);
  const communicating=powered && line(2) && line(3);
  return {powered,communicating,line,pairs};
}
export function wiringFaults(s:NeoState){
  const issues:string[]=[];
  for(const side of ['board','keypad'] as const){
    for(const [i,w] of s.ends.entries()){
      const end=w[side];
      if(end.terminal===null)issues.push(side+' '+terminals[i]+' lead is free.');
      else if(!end.tight)issues.push(side+' '+terminals[end.terminal]+' screw is loose.');
    }
  }
  for(const w of s.ends){
    if(w.board.terminal!==null && w.keypad.terminal!==null && w.board.terminal!==w.keypad.terminal)
      issues.push('Trace '+terminals[w.board.terminal]+' at the board to '+terminals[w.keypad.terminal]+' at the keypad.');
  }
  return issues;
}
export function programKey(s:NeoState,key:string):string{
  const circuit=physicalCircuit(s);
  if(!circuit.powered)return 'The keypad has no power.';
  if(!circuit.communicating)return 'The keypad has power. Inspect the data pair.';
  if(!s.enrolled){s.enrolled=true;s.lcd='Keypad enrolled · Slot 01';return s.lcd}
  if(key==='#'){s.keys='';s.lcd='System ready';return s.lcd}
  s.keys+=key;
  const prefix='*84256'; // Fictional installer code used only in this exercise.
  const full=prefix+'903000*';
  if(!full.startsWith(s.keys)){s.keys='';s.lcd='Invalid entry';return s.lcd}
  if(s.keys==='*8')s.lcd='Enter installer code';
  else if(s.keys===prefix)s.lcd='Enter section';
  else if(s.keys===prefix+'903')s.lcd='Confirm module';
  else if(s.keys===prefix+'903000')s.lcd='HS2LCD · Press *';
  else if(s.keys===full){s.confirmed=true;s.lcd='HS2LCD · Slot 01';s.keys=''}
  else s.lcd=s.keys.length>2&&s.keys.length<prefix.length?'Enter installer code':'Continue entry';
  return s.lcd;
}
export function neoChecks(s:NeoState){
 const circuit=physicalCircuit(s);
 return [
   {label:'Equipment mounted',pass:s.board&&s.keypad},
   {label:'Cable routed and prepared at both ends',pass:s.routed&&s.jacket.board&&s.jacket.keypad},
   {label:'Four clamped point-to-point circuits',pass:wiringFaults(s).length===0},
   {label:'Wiring inspected',pass:s.inspected},
   {label:'Keypad powered',pass:circuit.powered},
   {label:'Corbus communication',pass:circuit.communicating},
   {label:'Keypad enrolled and confirmed',pass:circuit.communicating&&s.enrolled&&s.confirmed},
   ...['Front Door','Hall Motion'].map((name,i)=>({label:name+' programmed, tripped and restored',pass:zoneReady(s.field,i,circuit.communicating&&s.confirmed)&&s.field.restored[i]}))
 ];
}
