const {spawn}=require('child_process'),path=require('path'),fs=require('fs'),assert=require('assert/strict');
const {pathToFileURL}=require('url');
const os=require('node:os');const profile=fs.mkdtempSync(path.join(os.tmpdir(),'securitylab-neo-'));const exe=process.env.BROWSER_EXECUTABLE||'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const proc=spawn(exe,['--headless=new','--use-angle=swiftshader','--enable-unsafe-swiftshader','--window-size=1400,1000','--no-first-run','--disable-background-networking','--remote-debugging-pipe','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','ignore','pipe','pipe'],windowsHide:true});
let seq=0,pending=new Map(),buffer='',session,errors=[];
proc.stdio[4].on('data',chunk=>{buffer+=chunk;while(buffer.includes('\0')){const j=buffer.indexOf('\0');const v=JSON.parse(buffer.slice(0,j));buffer=buffer.slice(j+1);if(v.method==='Runtime.exceptionThrown')errors.push(v.params.exceptionDetails.exception?.description??v.params.exceptionDetails.text);if(pending.has(v.id)){pending.get(v.id)(v);pending.delete(v.id)}}});
function call(method,params={},id){return new Promise((resolve,reject)=>{const n=++seq;pending.set(n,v=>v.error?reject(Error(v.error.message)):resolve(v.result));proc.stdio[3].write(JSON.stringify({id:n,method,params,sessionId:id})+'\0')})}
async function run(code){const r=await call('Runtime.evaluate',{expression:code,returnByValue:true},session);if(r.exceptionDetails)throw Error(r.exceptionDetails.exception.description);return r.result.value}
const click=t=>run("(()=>{const b=[...document.querySelectorAll('button')].find(b=>b.textContent==="+JSON.stringify(t)+");if(!b)throw Error('Missing button: '+"+JSON.stringify(t)+");b.click()})()");
const wait=ms=>new Promise(r=>setTimeout(r,ms));

const base=path.resolve(__dirname,'../dist');
const http=require('http').createServer((req,res)=>{const segment=new URL(req.url,'http://localhost').pathname;const file=path.join(base,segment==='/'?'index.html':segment);try{const data=fs.readFileSync(file);res.writeHead(200,{'Content-Type':({'.js':'text/javascript','.html':'text/html','.css':'text/css','.json':'application/json'})[path.extname(file)]||'application/octet-stream'});res.end(data)}catch{res.writeHead(404);res.end()}});
http.listen(0,'127.0.0.1');
const timer=setTimeout(()=>{console.error('Timeout');proc.kill();process.exit(1)},240000);
(async()=>{
 const tab=await call('Target.createTarget',{url:'about:blank'});session=(await call('Target.attachToTarget',{targetId:tab.targetId,flatten:true})).sessionId;await call('Runtime.enable',{},session);
 await call('Page.navigate',{url:'http://127.0.0.1:'+http.address().port},session);
 for(let i=0;i<120&&!await run("document.querySelector('#title')?.textContent");i++)await wait(180);
 await run("localStorage.clear()");await call('Page.reload',{},session);for(let i=0;i<100&&!await run('document.getElementById('+JSON.stringify('title')+')?.textContent');i++)await wait(150);await click('DSC Neo');
const saved=()=>run("JSON.parse(localStorage.getItem('securitylab.bench.v1'))");
const primary=()=>run("(()=>{const b=document.querySelector('#guide>.primary');if(!b||b.textContent==='Show all controls')throw Error(document.querySelector('#guide').innerText);b.click()})()");
const keys=text=>run('('+((keys)=>{
 for(const key of keys){
   const b=[...document.querySelectorAll('#guide button')].find(b=>b.textContent===key);
   if(!b)throw Error('Missing guided keypad key '+key+' in '+document.querySelector('#guide').innerText);
   b.click();
 }
}).toString()+')('+JSON.stringify(text)+')');
const hold=ms=>run("document.querySelector('#guide>.primary').dispatchEvent(new KeyboardEvent('keydown',{key:'Enter'}))").then(()=>wait(ms));
const guideText=()=>run("document.querySelector('#guide').innerText");
await click('Expand bench');
assert.equal(await run("getComputedStyle(document.querySelector('.workspace')).gridTemplateColumns.split(' ').length"),2);
assert.equal(await run("document.querySelector('#guide').getBoundingClientRect().top<innerHeight&&document.querySelector('#report-panel').getBoundingClientRect().top<innerHeight"),true);
assert.equal(await run("document.querySelector('#inspector .equipment-photo')===null&&document.querySelector('#equipment-resources').open===false"),true);
await run("document.querySelector('#report-panel summary').click()");
assert.equal(await run("document.querySelector('#report-panel').open&&document.querySelectorAll('#checks button').length===9"),true);
await run("document.querySelector('#checks button').click()");
await run("document.querySelector('#report-panel summary').click();window.scrollTo(0,0)");
await click('Fit view');await wait(700);
const snap=await call('Page.captureScreenshot',{format:'png'},session);
fs.writeFileSync(path.join(__dirname,'../docs/Visual checks/Guided Neo bench.png'),Buffer.from(snap.data,'base64'));
const view=await run("(()=>{const r=document.querySelector('#bench canvas').getBoundingClientRect();return {x:r.left+110,y:r.top+140}})()");
await call('Input.dispatchMouseEvent',{type:'mouseWheel',...view,deltaX:0,deltaY:360},session);await wait(450);
assert((await run("scrollY"))>0,'Wheel over the scene scrolls the page');
await run("window.scrollTo(0,0)");await wait(200);
const clip=await run("(()=>{const r=document.querySelector('#bench canvas').getBoundingClientRect();return {x:r.left+30,y:r.top+20,width:Math.min(r.width-60,650),height:220,scale:1}})()");
const image=async()=>(await call('Page.captureScreenshot',{format:'png',clip,captureBeyondViewport:true},session)).data;
const initial=await image();await run("document.getElementById('zoom-in').click()");await wait(250);
assert.notEqual(await image(),initial,'Zoom in changes the scene');
await run("document.getElementById('zoom-out').click()");await click('Fit view');
await run(`(()=>{
 for(let i=0;i<95&&!JSON.parse(localStorage.getItem('securitylab.bench.v1')).neo.ac;i++){
   const b=document.querySelector('#guide>.primary');
   if(!b||b.textContent==='Show all controls')throw Error(document.querySelector('#guide').innerText);
   b.click();
 }
})()`);
assert.equal((await saved()).neo.ac,true);
await keys('1*84256903000*');
assert.equal((await saved()).neo.confirmed,true);
await keys('*842560010010010010020050131#20100112');
assert.deepEqual((await saved()).neo.field.types,['001','005']);
for(let i=0;i<4;i++)await primary();
assert.match(await run("document.querySelector('#score').textContent"),/9 of 9/);
await click('IQ Panel 5');
for(let i=0;i<10;i++)await primary();
assert.match(await guideText(),/Hold power/);await hold(3200);
for(let i=0;i<5;i++)await primary();
assert.match(await guideText(),/installer code/);await keys('4726');await click('Enter');
for(let i=0;i<5;i++)await primary();
assert.match(await guideText(),/Hold enroll/);await hold(1250);await primary();
await run("document.querySelector('#guide input').value='Front Door'");await click('Add New');
for(let i=0;i<7;i++)await primary();
assert.match(await guideText(),/Hall Motion in group 17/);
await run("document.querySelector('#guide input').value='Hall Motion'");await click('Add New');
await primary();await primary();
assert.match(await run("document.querySelector('#score').textContent"),/7 of 7/);
await call('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true},session);await wait(450);
assert.equal(await run("document.documentElement.scrollWidth<=innerWidth"),true);
assert.equal(await run("document.querySelector('.training-rail').getBoundingClientRect().top<document.querySelector('.viewport').getBoundingClientRect().top"),true);
await run("document.querySelector('#report-panel').open=true");
assert.equal(await run("document.querySelector('#report-panel').open&&document.querySelectorAll('#checks button').length===7"),true);
await click('Reset exercise');assert.equal(await run("document.querySelector('#dialog').open"),true);await click('Close');
assert.deepEqual(errors,[]);console.log('Passed expanded bench, page wheel, zoom buttons, full guided sequences, report links, reset access, and phone layout.');

})().catch(e=>{console.error(e,errors);return run("document.body.innerText.slice(0,900)").then(t=>{console.log(t);process.exitCode=1})}).finally(async()=>{http.close();clearTimeout(timer);await call('Browser.close').catch(()=>{});proc.kill()});












