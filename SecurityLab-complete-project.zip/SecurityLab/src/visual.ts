import * as T from 'three'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'

const loader = new GLTFLoader()
const assets = new Map<string, Promise<T.Group>>()
type XYZ = [number, number, number]

// Every redraw gets a new object hierarchy. Its immutable Blender meshes and
// materials belong to the asset cache and survive exercise state transitions.
export function detail(parent:T.Object3D, file:string, position:XYZ, size:XYZ) {
  const anchor = new T.Group()
  anchor.position.fromArray(position)
  parent.add(anchor)
  const url = file.includes('/') ? file : './assets/' + encodeURIComponent(file)
  let asset = assets.get(url)
  if (!asset) {
    asset = loader.loadAsync(url).then(({scene}) => {
      scene.traverse(obj => {
        obj.userData.blenderAsset = true
        if (obj instanceof T.Mesh) {obj.castShadow = true; obj.receiveShadow = true}
      })
      return scene
    })
    assets.set(url, asset)
  }
  asset.then(source => {
    let root:T.Object3D = anchor
    while (root.parent) root = root.parent
    if (!(root instanceof T.Scene)) return
    const model = source.clone(true)
    const bounds = new T.Box3().setFromObject(model)
    const center = bounds.getCenter(new T.Vector3())
    const extents = bounds.getSize(new T.Vector3())
    anchor.scale.set(size[0]/(extents.x||1),size[1]/(extents.y||1),size[2]/(extents.z||1))
    model.position.sub(center)
    anchor.add(model)
    root.userData.invalidate?.()
  }).catch(error => {assets.delete(url);console.warn('Equipment surface could not load:', file, error)})
  return anchor
}
