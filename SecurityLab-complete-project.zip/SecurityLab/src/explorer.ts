import * as T from 'three'
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js'
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls.js'
import {equipmentPhoto} from './equipmentPhoto'
import {equipmentSelector} from './equipmentReferences'
export function equipmentViewer(content:HTMLElement,dialog:HTMLDialogElement,lab:'iq'|'neo'){
 const {select,current}=equipmentSelector(content,lab,true)
 const comparison=document.createElement('div');comparison.className='equipment-comparison'
 const simulated=document.createElement('section');simulated.className='equipment-simulation'
 const heading=document.createElement('strong');heading.textContent='3D simulation'
 const preview=document.createElement('section')
 comparison.append(simulated,preview);content.append(comparison)
 const height=Math.min(300,Math.round(innerHeight*.35))
 const view=document.createElement('div');view.style.cssText='height:'+height+'px;margin:8px 0;position:relative';const status=document.createElement('small');simulated.append(heading,view,status)
 let render:T.WebGLRenderer
 try{render=new T.WebGLRenderer({antialias:true})}catch{status.textContent='3D preview unavailable.';const show=()=>preview.replaceChildren(equipmentPhoto(current().id));select.addEventListener('change',show);show();return}
 const width=Math.max(1,view.clientWidth);render.setPixelRatio(Math.min(1.6,devicePixelRatio));render.setSize(width,height);render.setClearColor(0x28373f);view.append(render.domElement);render.domElement.style.cssText='width:100%;height:100%;touch-action:none'
 const scene=new T.Scene(),cam=new T.PerspectiveCamera(32,width/height,.001,50),controls=new OrbitControls(cam,render.domElement)
 const light=new T.DirectionalLight(0xffffff,3);light.position.set(-1,2,2);scene.add(new T.HemisphereLight(0xfcffff,0x666862,2),light)
 let obj:T.Group|undefined,serial=0
 function dispose(o:T.Object3D){o.traverse(v=>{if(v instanceof T.Mesh){v.geometry.dispose();for(const m of ([] as T.Material[]).concat(v.material))m.dispose()}})}
 function paint(){render.render(scene,cam)}controls.addEventListener('change',paint)
 function load(){
   const id=++serial
   const selected=current()
   preview.replaceChildren(equipmentPhoto(selected.id))
   if(obj){scene.remove(obj);dispose(obj);obj=undefined}
   view.hidden=!selected.model
   if(!selected.model){status.textContent='Reference only';return}
   status.textContent='Loading '+selected.name
 new GLTFLoader().load('./assets/'+encodeURIComponent(selected.model)+'.glb',g=>{if(id!==serial){dispose(g.scene);return}
 obj=g.scene;scene.add(obj);const box=new T.Box3().setFromObject(obj),mid=box.getCenter(new T.Vector3()),sz=box.getSize(new T.Vector3());controls.target.copy(mid);const span=Math.max(sz.y,sz.x/cam.aspect,sz.z*.65);cam.far=Math.max(50,span*20);cam.updateProjectionMatrix();cam.position.copy(mid).add(new T.Vector3(.22,.14,2.2).multiplyScalar(span));controls.update();paint();status.textContent='Drag to rotate · Scroll to inspect'},undefined,()=>{if(id===serial)status.textContent='Model could not load.'})}
 const resize=new ResizeObserver(()=>{
   if(!view.clientWidth)return
   render.setSize(view.clientWidth,height)
   cam.aspect=view.clientWidth/height;cam.updateProjectionMatrix();paint()
 })
 resize.observe(view)
 select.onchange=load;load();dialog.addEventListener('close',()=>{serial++;resize.disconnect();controls.dispose();if(obj)dispose(obj);render.dispose();render.forceContextLoss()},{once:true})
}
