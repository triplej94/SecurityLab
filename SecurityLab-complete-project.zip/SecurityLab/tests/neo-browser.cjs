const {spawn}=require('child_process'),path=require('path'),fs=require('fs'),assert=require('assert/strict');
const {pathToFileURL}=require('url');
const os=require('node:os');const profile=fs.mkdtempSync(path.join(os.tmpdir(),'securitylab-neo-'));const exe=process.env.BROWSER_EXECUTABLE||'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const proc=spawn(exe,['--headless=new','--use-angle=swiftshader','--enable-unsafe-swiftshader','--window-size=1400,1000','--no-first-run','--disable-background-networking','--remote-debugging-pipe','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','ignore','pipe','pipe'],windowsHide:true});
let seq=0,pending=new Map(),buffer='',session,errors=[];
proc.stdio[4].on('data',chunk=>{buffer+=chunk;while(buffer.includes('\0')){const j=buffer.indexOf('\0');const v=JSON.parse(buffer.slice(0,j));buffer=buffer.slice(j+1);if(v.method==='Runtime.exceptionThrown')errors.push(v.params.exceptionDetails.exception?.description??v.params.exceptionDetails.text);if(pending.has(v.id)){pending.get(v.id)(v);pending.delete(v.id)}}});
function call(method,params={},id){return new Promise((resolve,reject)=>{const n=++seq;pending.set(n,v=>v.error?reject(Error(v.error.message)):resolve(v.result));proc.stdio[3].write(JSON.stringify({id:n,method,params,sessionId:id})+'\0')})}
async function run(code){const r=await call('Runtime.evaluate',{expression:code,returnByValue:true},session);if(r.exceptionDetails)throw Error(r.exceptionDetails.exception.description);return r.result.value}
const click=t=>run("(()=>{const b=[...document.querySelectorAll('button')].find(b=>b.textContent==="+JSON.stringify(t)+");if(!b)throw Error('Missing button: '+"+JSON.stringify(t)+");b.click()})()");
const wait=ms=>new Promise(r=>setTimeout(r,ms));

const base=path.resolve(__dirname,'../dist');
const http=require('http').createServer((req,res)=>{const segment=new URL(req.url,'http://localhost').pathname;const file=path.join(base,segment==='/'?'index.html':segment);try{const data=fs.readFileSync(file);res.writeHead(200,{'Content-Type':({'.js':'text/javascript','.html':'text/html','.css':'text/css','.json':'application/json'})[path.extname(file)]||'application/octet-stream'});res.end(data)}catch{res.writeHead(404);res.end()}});
http.listen(0,'127.0.0.1');
const timer=setTimeout(()=>{console.error('Timeout');proc.kill();process.exit(1)},240000);
(async()=>{
 const tab=await call('Target.createTarget',{url:'about:blank'});session=(await call('Target.attachToTarget',{targetId:tab.targetId,flatten:true})).sessionId;await call('Runtime.enable',{},session);
 await call('Page.navigate',{url:'http://127.0.0.1:'+http.address().port},session);
 for(let i=0;i<120&&!await run("document.querySelector('#title')?.textContent");i++)await wait(180);
 await run("localStorage.clear()");await call('Page.reload',{},session);for(let i=0;i<100&&!await run('document.getElementById('+JSON.stringify('title')+')?.textContent');i++)await wait(150);await click('DSC Neo');
 const state=()=>run("JSON.parse(localStorage.getItem('securitylab.bench.v1')).neo");
 const select=(name,val)=>run("(()=>{const s=document.querySelector('select[aria-label="+JSON.stringify(name)+"]');s.value="+JSON.stringify(val)+";s.dispatchEvent(new Event('change'));})()");
 for(const k of ['Open HS2032 carton','Mount cabinet on backboard','Mount HS2032','Mount HS2LCD','Corbus terminal close-up','Open keypad flap','Select 22/4 cable','Route cable','Strip board jacket','Strip keypad jacket'])await click(k);
 for(const side of ['board','keypad'])for(let i=0;i<4;i++){
  await select('Conductor end',side+':'+i);await click('Strip conductor');
  await click('Fit view');
  const rect=await run("(()=>{const r=document.querySelector('#bench canvas').getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}})()");
  const xy=(x,y,z)=>{const f=rect.h/(2*Math.tan(16*Math.PI/180)*(Math.max(4,4*rect.h/rect.w)*1.86-z));return {x:rect.x+rect.w/2+x*f,y:rect.y+rect.h/2-y*f}};
  const center=side==='board'?-1.04:1.04,destination=side==='keypad'&&i>=2?5-i:i;
  const a=xy(center+(i-1.5)*.24,-.57,.352),b=xy(center-.33+.22*destination,-.32,.352);
  const mouse=(type,p,buttons)=>call('Input.dispatchMouseEvent',{type,...p,button:type==='mouseMoved'?'none':'left',buttons,clickCount:1},session);
  if(side==='board'&&i===0){
   await mouse('mousePressed',a,1);await mouse('mouseMoved',b,1);
   await run("document.querySelector('#bench canvas').dispatchEvent(new PointerEvent('pointercancel',{pointerId:1,pointerType:'mouse',isPrimary:true}))");
   await mouse('mouseReleased',b,0);
   assert.equal((await state()).ends[0].board.terminal,null,'Canceled drag must leave the lead free');
  }
  await mouse('mousePressed',a,1);await mouse('mouseMoved',b,1);await mouse('mouseReleased',b,0);
  assert.equal((await state()).ends[i][side].terminal,destination,'Spatial drag must land on the chosen terminal');
  await click('Tighten screw');
 }
 await click('Return to mechanical room');
 for(const k of ['Mount 7939WG header contact','Mount LC-100-PI above door','Remove detector cover'])await click(k);
 for(const [i,port] of ['Z1','COM','Z2','COM','AUX+','AUX−'].entries()){
  await select('Field conductor',String(i));await click('Land at '+port);await click('Clamp field lead');
 }
 for(const k of ['Fit Door 5.6 kΩ resistor','Fit Motion 5.6 kΩ resistor','Close detector cover','Corbus terminal close-up'])await click(k);
 await click('Inspect wiring');await click('Connect battery');await click('Apply transformer power');
 assert.match(await run("document.querySelector('#inspector').textContent"),/data unavailable/);
 await click('Isolate power');
 for(const i of [2,3]){await select('Conductor end','keypad:'+i);await click('Loosen screw');await click('Withdraw lead')}
 for(const i of [2,3]){await select('Conductor end','keypad:'+i);await select('Destination terminal',String(i));await click('Insert lead');await click('Tighten screw')}
 await click('Inspect wiring');await click('Connect battery');await click('Apply transformer power');
 for(const k of '1*84256903000*')await click(k);
 assert((await state()).confirmed);
 assert.match(await run("document.querySelector('#score').textContent"),/7 of 9/);
 const models=await run("performance.getEntriesByType('resource').map(e=>e.name.split('/').pop())");
 for(const asset of ['neo-cabinet.glb','neo-hs2032-board.glb','neo-hs2lcd.glb','neo-corbus-clamp.glb'])assert(models.includes(asset),'Missing Neo asset: '+asset);
 await call('Page.reload',{},session);for(let i=0;i<100&&!await run('document.getElementById('+JSON.stringify('title')+')?.textContent');i++)await wait(150);assert((await state()).confirmed);
 const shot=await call('Page.captureScreenshot',{format:'png'},session);fs.writeFileSync(path.join(profile,'commissioning.png'),Buffer.from(shot.data,'base64'));
 await click('Reset exercise');await click('Reset this exercise');assert.equal((await state()).board,false);
 assert.deepEqual(errors,[]);console.log('Passed actual board lead drag, eight endpoints, crossed-data fault, isolate/repair, enrollment, commissioning, reload and reset.');
})().catch(e=>{console.error(e,errors);return run("document.body.innerText.slice(0,900)").then(t=>{console.log(t);process.exitCode=1})}).finally(async()=>{http.close();clearTimeout(timer);await call('Browser.close').catch(()=>{});proc.kill()});






