import {iqTask,neoTask,showTask} from './guide'
import {equipmentPhoto,equipmentPhotos} from './equipmentPhoto'
import {equipmentSelector,evidenceSource} from './equipmentReferences'
import {equipmentViewer} from './explorer'
import './app.css'
import * as T from 'three'
import {workbench} from './bench'
import {initialIQ,createIQ,iqChecks} from './iq'
import {iqStages,neoStages,newProgress,jump,replay,reconcile,stageRows,type Progress} from './progress'
import {initialNeo,createNeo,neoChecks} from './neo'
const $=<K extends HTMLElement=HTMLElement>(id:string)=>document.getElementById(id) as K
const key='securitylab.bench.v1', choices=['Guided','Learn','Sandbox','Assessment']
const factories={iq:initialIQ,neo:initialNeo}
type Lab=keyof typeof factories
type Session={lab:Lab, mode:string,iq:any,neo:any,events:Record<Lab,string[]>;progress:Record<Lab,Progress>}
function fresh():Session{return {lab:'iq',mode:'Guided',iq:initialIQ(),neo:initialNeo(),events:{iq:[],neo:[]},progress:{iq:newProgress(),neo:newProgress()}}}
function restore(){try{const v=JSON.parse(localStorage.getItem(key)||'null');if(v&&v.lab in factories&&choices.includes(v.mode)&&v.iq&&v.neo&&Array.isArray(v.events?.iq)&&Array.isArray(v.events?.neo))return {...v,progress:{iq:{...newProgress(),...v.progress?.iq},neo:{...newProgress(),...v.progress?.neo}},neo:{...initialNeo(),cabinet:Boolean(v.neo.board),unpacked:Boolean(v.neo.board||v.neo.keypad),...v.neo},iq:{...initialIQ(),...v.iq}} as Session}catch{}return fresh()}
let session=restore(),past:string[]=[],future:string[]=[]
let bench:ReturnType<typeof workbench>|undefined
const say=(m:string)=>{$('notice').textContent=m}
try{bench=workbench($('bench'))}catch{$('bench').textContent='WebGL could not start in this browser. Equipment controls are available alongside the workbench.'}
function save(){try{localStorage.setItem(key,JSON.stringify(session))}catch{say('Browser storage is unavailable. This session will last until the page closes.')}}
function snapshot(){past.push(JSON.stringify(session));if(past.length>80)past.shift();future=[]}
function action(label:string,fn:()=>void){snapshot();fn();updateCredit();const list=session.events[session.lab];list.unshift(label);list.splice(20);say(label);draw()}
function labStages<R>(fn:<S>(stages:Parameters<typeof stageRows<S>>[0],state:S,progress:Progress)=>R):R{
 return session.lab==='iq'?fn(iqStages,session.iq,session.progress.iq):fn(neoStages,session.neo,session.progress.neo)
}
const updateCredit=()=>labStages(reconcile)
function checks(){
 const iq=session.lab==='iq'
 const skipped=session.progress[session.lab].skipped
 const ids=iq?['iq-panel','iq-panel','iq-contact','iq-contact','iq-door-test','iq-motion','iq-walk']:
   ['neo-mount','neo-corbus','neo-corbus','neo-power','neo-power','neo-power','neo-power','neo-test','neo-test']
 return (iq?iqChecks(session.iq):neoChecks(session.neo)).map((row,index)=>({
   ...row,pass:row.pass&&!skipped.includes(ids[index]),skipped:skipped.includes(ids[index]),stage:ids[index]
 }))
}
const shotList=$<HTMLSelectElement>('closeup')
shotList.onchange=()=>bench?.inspectPart(shotList.value)
$('bench').addEventListener('partfocus',event=>{shotList.value=(event as CustomEvent<string>).detail})
$('inspect-mode').onclick=()=>{
 const button=$('inspect-mode'),on=button.getAttribute('aria-pressed')!=='true'
 button.setAttribute('aria-pressed',String(on));button.textContent=on?'Work mode':'Inspect devices'
 bench?.setInspect(on)
 $('bench-legend').lastElementChild!.textContent=on?'Click or tap a device to zoom':'Click a part to interact'
}
const stageFocus:Record<string,string>={
 'iq-panel':'iq-box','iq-contact':'iq-contact','iq-door-test':'iq-door','iq-motion':'iq-pir','iq-walk':'iq-pir',
 'neo-mount':'neo-carton','neo-corbus':'neo-board-corbus','neo-field':'neo-contact','neo-power':'neo-battery',
 'neo-program':'neo-keypad','neo-test':'neo-door'
}
function routeStage(id:string){
 if(session.lab==='iq'){
   const s=session.iq
   s.screen=s.on?(id==='iq-contact'||id==='iq-motion'?'learn':id==='iq-door-test'||id==='iq-walk'?'status':'home'):'home'
   s.pin=''
 }else{
   const s=session.neo
   s.service=id==='neo-corbus'&&s.board&&s.keypad
   if(id==='neo-field'||id==='neo-power')s.coverOpen=true
   if(id==='neo-program'||id==='neo-test')s.flap=false
 }
}
function focusStage(id:string){
 const alternatives:Record<string,string[]>={
   'iq-panel':['iq-panel','iq-plate','iq-box'],'neo-mount':['neo-board','neo-cabinet','neo-carton'],
   'neo-corbus':['neo-board-corbus','neo-board','neo-keypad'],'neo-power':['neo-battery','neo-transformer']
 }
 const part=(alternatives[id]??[stageFocus[id]]).find(key=>bench?.parts.has(key))
 if(part&&bench)bench.inspectPart(part)
 else fitBench()
}
function nextRow(rows:ReturnType<typeof stageRows>){
 const actionable=(row:typeof rows[number])=>!row.ready&&(!row.skipped||row.practice)
 return rows.find(row=>row.selected&&actionable(row))??rows.find(actionable)
}
function renderProgress(parent:HTMLElement){
 const rows=labStages(stageRows)
 const assessment=session.mode==='Assessment'
 const next=nextRow(rows)
 const active=session.progress[session.lab].active==='review'?rows.length:rows.findIndex(row=>row.id===(next?.id??rows.find(item=>item.selected)?.id))
 $('step-summary').textContent=next?'Step '+(rows.indexOf(next)+1)+' of '+rows.length+' · '+next.label:
   rows.some(row=>row.skipped)?'Review · '+rows.filter(row=>row.skipped).length+' skipped':'Exercise ready to review'
 const section=document.createElement('section');section.className='lab-progress';section.ariaLabel='Exercise progress'

 const tree=document.createElement('ol')
 const stepButtons:HTMLButtonElement[]=[]
 rows.forEach((row,index)=>{
   const li=document.createElement('li'),label=document.createElement(assessment?'span':'button'),status=document.createElement('small')
   if(label instanceof HTMLButtonElement){label.type='button';stepButtons.push(label)}
   label.textContent=row.label
   status.textContent=row.skipped?'Skipped':row.ready?'Completed':row.id===next?.id?'In progress':'Pending'
   li.dataset.status=status.textContent.toLowerCase()
   if(row.id===next?.id)li.setAttribute('aria-current','step')
   li.append(label,status);tree.append(li)
 })
 section.append(tree)
 if(!assessment){
   const label=document.createElement('label');label.textContent='Jump to step '
   const select=document.createElement('select');select.ariaLabel='Jump to step'
   select.add(new Option('Choose a step',''))
   rows.forEach((row,index)=>select.add(new Option(row.label,String(index))))
   if(active===rows.length)select.options[0].text='Review exercise'
   const actionRow=document.createElement('div');actionRow.className='progress-actions'
   const go=(index:number)=>{
     if(index<0||index>rows.length)return
     const id=rows[index]?.id??'review'
     action(id==='review'?'Review exercise':'Jump to '+rows[index].label,()=>{
       if(index>active||active===-1)labStages((stages,state,progress)=>jump(stages,state,progress,index))
       else session.progress[session.lab].active=id
       routeStage(id)
     });focusStage(id)
   }
   stepButtons.forEach((button,index)=>{button.onclick=()=>go(index)})
   select.onchange=()=>{if(select.value!=='')go(Number(select.value))}
   label.append(select);actionRow.append(label)
   if(active>=0&&active<rows.length){
     const skip=document.createElement('button');skip.type='button';skip.textContent='Skip this step';skip.onclick=()=>go(active+1);actionRow.append(skip)
     const row=rows.find(item=>item.selected&&item.skipped&&!item.practice)??rows[active]
     if(row.skipped&&!row.practice){
       const practice=document.createElement('button');practice.type='button';practice.textContent='Practice skipped step'
       practice.onclick=()=>{action('Practice '+row.label,()=>{labStages((stages,state,progress)=>replay(stages,state,progress,rows.indexOf(row)));routeStage(row.id)});focusStage(row.id)}
       const note=document.createElement('small');note.textContent='Practice restarts this step and later steps. You can undo it.'
       actionRow.append(practice,note)
     }
   }
   section.append(actionRow)
 }
 parent.append(section)
}
$('expand').onclick=()=>{const on=document.body.classList.toggle('expanded');$('expand').textContent=on?'Restore layout':'Expand bench';$('expand').setAttribute('aria-pressed',String(on))}
let resourceLab=''
function draw(){const lab=session.lab;const ui=$('inspector');const guide=$('guide');const focused=guide.contains(document.activeElement)?document.activeElement:null
 ui.replaceChildren();$('step-list').replaceChildren();guide.replaceChildren();bench?.reset()
 const lastPart=shotList.value
 renderProgress($('step-list'))
 const fallback=()=>{};const ctx={scene:bench?.scene??new T.Scene(),state:session[lab],register:bench?.register??fallback,mode:session.mode,ui,hit:bench?.hit??fallback,drag:bench?.drag??fallback,focus:bench?.focus??fallback,say,update:draw,action}
 if(lab==='iq')createIQ(ctx);else createNeo(ctx)
 shotList.replaceChildren(new Option('Choose a part',''),...[...(bench?.parts??[])].map(([id,part])=>new Option(part.label,id)))
 if(bench?.parts.has(lastPart))shotList.value=lastPart
 bench?.followPart()
 const selected=nextRow(labStages(stageRows))
 const guided=session.mode==='Guided'||session.mode==='Learn'
 guide.hidden=!guided
 if(guided){
   const task=selected?(lab==='iq'?iqTask(session.iq,selected.id):neoTask(session.neo,selected.id)):null
   showTask(guide,ui,task,()=>{$<HTMLDetailsElement>('report-panel').open=true;$('report-panel').querySelector('summary')?.focus()})
   if(focused instanceof HTMLButtonElement){
     const candidates=[...guide.querySelectorAll('button')]
     ;(candidates.find(button=>button.textContent===focused.textContent)??candidates[0])?.focus({preventScroll:true})
   }
 }
 if(resourceLab!==lab){
   resourceLab=lab;const cards=$('equipment-cards');cards.replaceChildren()
   equipmentPhotos(cards,...(lab==='iq'?
     ['iq-panel-front','iq-panel-rear','iq-smartmount','iq-battery','iq-adapter','iq-contact','PG9914','PG9914-open']:
     ['neo-cabinet','neo-hs2032-board','neo-hs2lcd','neo-battery','neo-transformer','neo-corbus-clamp','7939WG','LC-100-PI','LC-100-PI-open']))
 }
 $('title').textContent=lab==='iq'?'Residential wireless installation':'DSC Neo mechanical room'
 $('brief').textContent=lab==='iq'?'Install the IQ Panel 5, enroll the front door and hallway motion detector, and verify both zones.':'Install the HS2032 and HS2LCD, wire Front Door and Hall Motion, then program and test both zones.'
 for(const k of ['iq','neo'])$(k).setAttribute('aria-pressed',String(k===lab))
 $<HTMLSelectElement>('mode').value=session.mode
 const rows=checks();$('score').textContent=rows.filter(r=>r.pass).length+' of '+rows.length+' checks passed'
 $('checks').replaceChildren(...rows.map(row=>{
   const button=document.createElement('button');button.className='report-check';button.type='button'
   const status=document.createElement('small');status.textContent=row.skipped?'Skipped':row.pass?'Passed':'Pending'
   status.dataset.status=status.textContent.toLowerCase()
   const description=document.createElement('span');description.textContent=row.label
   button.append(description,status)
   button.onclick=()=>{focusStage(row.stage);$('bench').scrollIntoView({block:'nearest'})}
   return button
 }))
 $('log').replaceChildren(...(session.events[lab].length?session.events[lab].slice(0,6):['Waiting for your first action.']).map(t=>{const li=document.createElement('li');li.textContent=t;return li}))
 $<HTMLButtonElement>('undo').disabled=!past.length;$<HTMLButtonElement>('redo').disabled=!future.length
 save();bench?.render()
}
for(const lab of ['iq','neo'] as Lab[])$(lab).onclick=()=>{session.lab=lab;past=[];future=[];say('');draw();fitBench()}
$('mode').onchange=e=>{
 session.mode=(e.target as HTMLSelectElement).value
 $<HTMLDetailsElement>('all-controls').open=session.mode==='Sandbox'||session.mode==='Assessment'
 draw()
}
function fitBench(){
 bench?.clearPart();shotList.value=''
 if(session.lab==='neo'&&!session.neo.service)bench?.focus(new T.Vector3(0,.14,.21),5.6)
 else bench?.focus(new T.Vector3(),4)
}
$('fit').onclick=fitBench
$('zoom-in').onclick=()=>bench?.zoom(.78)
$('zoom-out').onclick=()=>bench?.zoom(1/.78)
function travel(from:string[],to:string[]){if(!from.length)return;to.push(JSON.stringify(session));session=JSON.parse(from.pop()!);say('');draw()}
$('undo').onclick=()=>travel(past,future);$('redo').onclick=()=>travel(future,past)
const dialog=$<HTMLDialogElement>('dialog'),content=$('content')
function openDialog(){dialog.showModal();content.scrollTop=0}
$('close').onclick=()=>dialog.close()
$('restart').onclick=()=>{content.replaceChildren();const p=document.createElement('p');p.textContent='Restart this exercise with the equipment back in its box?';const b=document.createElement('button');b.textContent='Reset this exercise';b.onclick=()=>{dialog.close();action('Restarted exercise',()=>{session[session.lab]=factories[session.lab]();session.events[session.lab]=[];session.progress[session.lab]=newProgress()});fitBench()};content.append(p,b);openDialog()}
$('download').onclick=()=>{const data={lab:session.lab,mode:session.mode,checks:checks(),stages:labStages(stageRows),events:session.events[session.lab],generated:new Date().toISOString()};const a=document.createElement('a');const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));a.href=url;a.download='SecurityLab-'+session.lab+'-report.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500)}
$('explore').onclick=async()=>{content.replaceChildren();const h=document.createElement('h2');h.textContent='Equipment explorer';const query=document.createElement('input');query.placeholder='Search equipment, terminal or procedure';query.ariaLabel=query.placeholder;const results=document.createElement('div');content.append(h,query);openDialog();const viewer=document.createElement('div');content.append(viewer,results);equipmentViewer(viewer,dialog,session.lab);try{const rows=await(await fetch('./evidence.json')).json();function filter(){const hits=rows.filter((r:any)=>Object.values(r).join(' ').toLowerCase().includes(query.value.toLowerCase()));results.replaceChildren(...hits.map((r:any)=>{const item=document.createElement('article'),a=document.createElement('h3'),b=document.createElement('p'),c=document.createElement('small');a.textContent=r.model;b.textContent=r.rule;c.textContent=r.title+' · '+r.page+' · '+r.confidence;item.append(a,b,c);
 const ref=evidenceSource(r.title,r.page);
 if(ref){const link=document.createElement('a');link.href=ref;link.target='_blank';link.rel='noopener noreferrer';link.textContent='Open reference';item.append(link)}
 return item}));if(!hits.length)results.textContent='No matching references.'}query.oninput=filter;filter()}catch{results.textContent='Equipment references could not be loaded.'}}
$<HTMLDetailsElement>('all-controls').open=session.mode==='Sandbox'||session.mode==='Assessment'
draw();fitBench()

$('references').onclick=event=>{
 event.preventDefault()
 content.replaceChildren()
 const title=document.createElement('h2')
 title.id='equipment-references'
 title.textContent='Photos & datasheets'
 content.append(title)
 const {select,current}=equipmentSelector(content,session.lab)
 const preview=document.createElement('div')
 const renderPhoto=()=>preview.replaceChildren(equipmentPhoto(current().id))
 select.addEventListener('change',renderPhoto)
 content.append(preview);renderPhoto()
 openDialog()
}

$('angle').onclick=()=>bench?.angle()


