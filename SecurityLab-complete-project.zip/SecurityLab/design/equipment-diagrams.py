"""Generate original reference diagrams for equipment views without suitable photos."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

output = Path(__file__).resolve().parents[1] / 'public' / 'equipment'
output.mkdir(exist_ok=True)
regular = 'C:/Windows/Fonts/segoeui.ttf'
bold = 'C:/Windows/Fonts/segoeuib.ttf'
ink = '#213839'
line = '#627873'

def render(name, title, parts):
    im = Image.new('RGB', (640, 390), '#f0f1ed')
    draw = ImageDraw.Draw(im)
    draw.text((32,22),title,fill=ink,font=ImageFont.truetype(bold,30))
    for bounds, label, color in parts:
        x, y, right, bottom = bounds
        draw.rounded_rectangle(bounds, radius=8, fill=color, outline=line, width=3)
        if label:
            draw.text(((x+right)/2,(y+bottom)/2),label,anchor='mm',fill=ink,font=ImageFont.truetype(regular,19))
    draw.text((32,356),'Illustrative layout · see the linked manual for details',fill=ink,font=ImageFont.truetype(regular,17))
    im.save(output / (name + '.png'), optimize=True)

render('iq-smartmount','IQ Panel 5 · SmartMount',[
    ((150,75,490,330),'','#dce0d9'),((207,105,433,138),'Top mounting tabs','#c4cdc4'),
    ((224,164,416,244),'Cable opening','#f0f1ed'),((242,282,398,313),'Locking screw','#dbc9a4')])
render('iq-adapter','IQ Panel 5 · supplied adapter',[
    ((64,108,248,280),'12 V DC adapter','#dddcd0'),((246,187,476,197),'','#c3cfc7'),
    ((462,164,566,220),'Barrel plug','#d4c8ac')])
render('PG9914-open','PG9914 · cover removed',[
    ((136,75,504,328),'','#dae1db'),((202,108,438,165),'Battery compartment','#d5c5a3'),
    ((235,240,405,291),'Enroll control','#cad8cb')])
render('LC-100-PI-open','LC-100-PI · field terminals',[
    ((52+i*77,125,114+i*77,203),label,'#d6ded4')
    for i,label in enumerate(['T1','T2','NC','C','EOL','–','+'])]+[
    ((198,227,378,276),'Alarm relay and EOL','#e5d7b9'),
    ((428,227,586,276),'DC supply','#cbd9ce')])
render('neo-corbus-clamp','HS2032 · Corbus terminal detail',[
    ((80+i*121,116,191+i*121,195),label,color)
    for i,(label,color) in enumerate(zip(['RED','BLK','YEL','GRN'],['#e8bfb4','#bdc9c7','#eadba1','#c6dbbe']))]+[
    ((80,230,310,278),'Keypad power','#d6ded4'),((322,230,554,278),'Corbus data','#d6ded4')])

