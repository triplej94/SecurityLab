# Release status
Implemented two playable equipment benches, camera orbit/zoom, picking, conductor dragging, physical sensor placement, power interlocks, IQ programming and live zone status, basic Neo keypad enrollment/confirmation, source search, GLB inspection, state-based assessment, local saves and reset/undo/redo.

Local browser acceptance covered the complete IQ installation and Neo wiring exercises. The IQ bench passed 5 commissioning checks. The Neo bench passed 7 after a crossed data pair was isolated and repaired. See the technical verification and hosting reports for scope. Scene geometry and electrical behavior are educational approximations; firmware emulation, quantitative electrical analysis and real service connections are outside this release.

## Expansion order
1. Add the second door and PG9914 lesson to the shared residential simulation.
2. Extend the Neo cable collection, routing, measurement tools and expander lab with documented electrical behavior.
3. Add firmware-scoped programming sections, diagnostics and additional panel families from the source register.
4. Add instructor and multi-device progress storage when separate learner accounts are required.
