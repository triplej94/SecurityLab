export const routes = [
  ['7939WG · switch', 'Z1'], ['7939WG · return', 'COM'],
  ['LC-100-PI · NC', 'Z2'], ['LC-100-PI · C', 'COM'],
  ['LC-100-PI · +12V', 'AUX+'], ['LC-100-PI · −12V', 'AUX−']
] as const
export function newField() {
  return {mounted:[false,false], aligned:true, cover:false, door:false, motion:false,
    ends:routes.map(()=>''), tight:routes.map(()=>false), resistor:[false,false],
    types:['000','000'], partition:[false,false], nc:true, double:false,
    observed:[false,false], restored:[false,false], section:'', entry:'', selected:0}
}
export type Field = ReturnType<typeof newField>
export function connected(f:Field,i:number) {return f.tight[i] && f.ends[i]===routes[i][1]}
export function zoneReady(f:Field,i:number,powered:boolean) {
  return powered && f.mounted[i] && f.partition[i] && f.types[i]===(i===0?'001':'005') &&
    !f.nc && !f.double && f.resistor[i] && connected(f,2*i) && connected(f,2*i+1) &&
    (i===0?f.aligned:connected(f,4)&&connected(f,5)&&!f.cover)
}
export function fieldStatus(f:Field,i:number,powered:boolean) {
  if(!powered)return 'Panel offline'
  if(!f.partition[i]||f.types[i]==='000')return 'Unassigned'
  if(!f.mounted[i]||!connected(f,2*i)||!connected(f,2*i+1))return 'Open loop'
  if(i===1&&(!connected(f,4)||!connected(f,5)))return 'PIR power fault'
  if(i===1&&f.cover)return 'Cover removed · finish assembly'
  if(i===0&&(f.door||!f.aligned)||i===1&&f.motion)return 'Open'
  if(f.double||f.nc||!f.resistor[i])return 'Check loop supervision'
  return 'Restored'
}
export function operateField(f:Field,i:number,powered:boolean) {
  if(i===0)f.door=!f.door
  else if(zoneReady(f,i,powered))f.motion=!f.motion
  const status=fieldStatus(f,i,powered)
  if(zoneReady(f,i,powered)){
    if(status==='Open')f.observed[i]=true
    if(status==='Restored'&&f.observed[i])f.restored[i]=true
  }
}
// A bounded HS2LCD training menu. The exercise starts with two unassigned zones.
export function fieldKey(f:Field,k:string):string {
  if(k==='#'){
    if(f.section==='013'||f.section==='201001'){f.section='menu';f.entry='';return 'Enter section'}
    f.section='';f.entry='';return 'Installer menu closed'
  }
  if(f.section==='013'){
    if(k==='1')f.nc=!f.nc
    if(k==='2')f.double=!f.double
    return '013 · 1 '+(f.nc?'ON':'OFF')+'  2 '+(f.double?'ON':'OFF')
  }
  if(f.section==='201001'){
    if(k==='1'||k==='2'){const i=Number(k)-1;f.partition[i]=!f.partition[i]}
    return 'P1 · Z1 '+(f.partition[0]?'ON':'OFF')+' Z2 '+(f.partition[1]?'ON':'OFF')
  }
  f.entry+=k
  if(!f.section){
    if(!'*84256'.startsWith(f.entry)){f.entry='';return 'Enter *8 and training code'}
    if(f.entry==='*84256'){f.entry='';f.section='menu';return 'Enter section'}
    return 'Installer access'
  }
  if(f.entry.length<3)return 'Entry '+f.entry
  const value=f.entry;f.entry=''
  if(f.section==='menu'){
    if(['001','013','201'].includes(value)){f.section=value;return value==='013'?'013 · 1 '+(f.nc?'ON':'OFF')+'  2 '+(f.double?'ON':'OFF'):value==='201'?'Enter group 001':'Enter zone 001 or 002'}
  }else if(f.section==='001'&&['001','002'].includes(value)){f.section='type'+value;return 'Enter zone definition'}
  else if(f.section.startsWith('type')){f.types[Number(f.section.slice(4))-1]=value;f.section='menu';return 'Definition saved · enter section'}
  else if(f.section==='201'&&value==='001'){f.section='201001';return 'P1 · 1=Z1  2=Z2'}
  return 'Check entry · retry'
}
