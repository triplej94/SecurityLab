import {type IQ,iqChecks,labCode} from './iqState'
import {type NeoState,terminals,physicalCircuit} from './neo-engine'
import {connected,routes} from './field-engine'

type Task={
 instruction:string
 button?:string
 group?:string
 selection?:[label:string,value:string]
}
const ask=(button:string,instruction=button):Task=>({button,instruction})
const group=(selector:string,instruction:string):Task=>({group:selector,instruction})
const select=(label:string,value:string,instruction:string):Task=>({selection:[label,value],instruction})

const iqInstallation=[
 ['box','Open equipment box'],['unpacked','Lift out IQ Panel 5'],['loose','Release locking screw'],
 ['plateOff','Remove SmartMount backplate'],['plateMounted','Mount backplate level'],
 ['battery','Seat battery connector'],['cable','Insert 12 V barrel plug'],
 ['seated','Latch panel on backplate'],['secured','Tighten locking screw'],
 ['adapter','Plug in supplied adapter'],['on','Hold power · 3 seconds']
] as const

function enrollIQ(s:IQ,motion:boolean):Task{
 const expected=motion?'Hall Motion in group 17':'Front Door in group 10'
 if(s.screen==='pin')return group('.iq-touch','Enter bench installer code '+labCode+' and press Enter.')
 if((s.screen==='confirm'||s.screen==='configure'||s.screen==='edit')&&(s.sensor==='motion')!==motion)return ask(s.screen==='confirm'?'Cancel':'Home','Return to the sensor menu to work on the correct device.')
 if(s.screen==='configure'||s.screen==='edit')return group('.iq-touch','Name the sensor '+expected+', then save it.')
 if(s.screen==='learn'){
   if(motion&&!s.motionCover)return ask('Open motion cover')
   return motion?ask('Press PG9914 enroll switch'):ask('Hold enroll until yellow flash')
 }
 if(s.screen==='confirm')return ask('OK · Confirm ID','Match the displayed ID to the device label and confirm it.')
 const name:Record<string,string>={home:'IQ Panel 5  ·  Settings tray',tray:'Settings',settings:'Advanced Settings',advanced:'Installation',dealer:'Save dealer details',installation:'Devices',devices:'Security Sensors',status:'Back to sensors'}
 return ask(s.screen==='sensors'?(motion?s.motionZone?'Edit motion detector':'Auto Learn Sensor':s.zone?'Edit door contact':'Auto Learn Sensor'):name[s.screen]||'Home')
}

export function iqTask(s:IQ,stage:string):Task|null{
 switch(stage){
 case 'iq-panel':{
   const next=iqInstallation.find(([key])=>!s[key])
   return next?ask(next[1],next[1]+'.'):null
 }
 case 'iq-contact':
   if(s.transmitter!=='frame')return ask('Mount transmitter on frame','Mount the PG9945 transmitter on the fixed door header.')
   if(s.magnet!=='aligned')return ask('Mount magnet · 4 mm gap','Align the magnet on the moving door with a 4 mm gap.')
   return enrollIQ(s,false)
 case 'iq-door-test':
   return s.door?ask('Close door','Close the door and verify that Front Door restores.'):ask('Open door','Open the door and verify that Front Door trips.')
 case 'iq-motion':
   if(!s.motionMounted)return ask('Mount motion detector in hallway','Mount the PG9914 above the doorway.')
   return enrollIQ(s,true)
 case 'iq-walk':
   if(s.motionCover)return ask('Close motion cover')
   if(!iqChecks(s)[6].pass)return ask('Walk across hallway','Cross the motion coverage and verify that Hall Motion trips.')
 }
 return null
}

function wireCorbus(s:NeoState):Task{
 if(s.ac||s.battery)return ask('Isolate power','Isolate power before changing the Corbus wiring.')
 if(!s.service)return ask('Corbus terminal close-up','Open the Corbus terminal close-up.')
 if(!s.cable)return ask('Select 22/4 cable')
 if(!s.routed)return ask('Route cable')
 if(!s.jacket.board)return ask('Strip board jacket')
 if(!s.jacket.keypad)return ask('Strip keypad jacket')
 for(const side of ['board','keypad'] as const){
   const fault=s.ends.findIndex((wire,i)=>!wire[side].stripped||!wire[side].tight||wire[side].terminal!==i)
   if(fault<0)continue
   const occupant=s.ends.findIndex((wire,i)=>i!==fault&&wire[side].terminal===fault)
   const wire=occupant>=0?occupant:fault
   const end=s.ends[wire][side]
   const name=side+' '+terminals[wire]
   if(s.side!==side||s.wire!==wire)return select('Conductor end',side+':'+wire,'Select the '+name+' lead.')
   if(!end.stripped)return ask('Strip conductor','Strip the '+name+' lead.')
   if(end.tight)return ask('Loosen screw','Loosen the '+name+' lead so you can correct its connection.')
   if(end.terminal!==null&&end.terminal!==wire)return ask('Withdraw lead','Withdraw the lead from the wrong terminal.')
   if(end.terminal===null)return {...ask('Insert lead','Insert the '+name+' lead into the '+terminals[wire]+' terminal.'),selection:['Destination terminal',String(wire)]}
   return ask('Tighten screw','Tighten the terminal screw on the '+name+' lead.')
 }
 return ask('Return to mechanical room')
}

function wireField(s:NeoState):Task{
 const f=s.field
 if(s.service)return ask('Return to mechanical room')
 if(s.ac||s.battery)return ask('Isolate power','Isolate power before changing the field wiring.')
 if(!s.coverOpen)return ask('Open cabinet')
 if(!f.mounted[0])return ask('Mount 7939WG header contact','Mount the wired contact at the door header.')
 if(!f.aligned)return ask('Align magnet')
 if(!f.mounted[1])return ask('Mount LC-100-PI above door','Mount the LC-100-PI above the door.')
 const wire=routes.findIndex((_,i)=>!connected(f,i))
 if(wire>=2&&!f.cover)return ask('Remove detector cover','Open the motion detector to access its wiring terminals.')
 if(wire>=0){
   const [name,destination]=routes[wire]
   if(f.selected!==wire)return select('Field conductor',String(wire),'Select '+name+'.')
   if(f.ends[wire]!==destination){
     if(f.tight[wire])return ask('Loosen field lead','Loosen '+name+' before moving it.')
     return ask('Land at '+destination,'Land '+name+' at '+destination+'.')
   }
   return ask('Clamp field lead','Clamp '+name+' at '+destination+'.')
 }
 if(!f.resistor[0])return ask('Fit Door 5.6 kΩ resistor')
 if(!f.resistor[1])return f.cover?ask('Fit Motion 5.6 kΩ resistor'):ask('Remove detector cover')
 return ask('Close detector cover')
}

function programZones(s:NeoState):Task{
 const {field:f}=s
 let instruction:string
 switch(f.section){
 case '':instruction='Enter *8 and the training code 4256.';break
 case 'menu':
   instruction=f.types[0]!=='001'||f.types[1]!=='005'?'Enter section 001 to set the zone types.':
     f.nc||f.double?'Enter section 013 to set single end-of-line supervision.':'Enter section 201 to assign the zones to partition 1.'
   break
 case '001':instruction=f.types[0]!=='001'?'Enter zone 001 for Front Door.':'Enter zone 002 for Hall Motion.';break
 case 'type001':instruction='Enter 001 for Delay 1.';break
 case 'type002':instruction='Enter 005 for Interior Stay/Away.';break
 case '013':instruction=f.nc||f.double?'Turn off the options that are on. Press 1 for NC and 2 for DEOL.':'Press # to return to the section menu.';break
 case '201':instruction='Enter group 001.';break
 case '201001':instruction='Turn on each unassigned zone using 1 for Front Door or 2 for Hall Motion.';break
 default:instruction='Press # to return to the installer menu.'
 }
 return group('[data-guide="neo-programming"]',instruction)
}

export function neoTask(s:NeoState,stage:string):Task|null{
 switch(stage){
 case 'neo-mount':
   if(!s.unpacked)return ask('Open HS2032 carton')
   if(!s.cabinet)return ask('Mount cabinet on backboard')
   if(!s.board)return s.coverOpen?ask('Mount HS2032'):ask('Open cabinet')
   return ask('Mount HS2LCD')
 case 'neo-corbus':return wireCorbus(s)
 case 'neo-field':return wireField(s)
 case 'neo-power':
   if(s.service)return ask('Return to mechanical room')
   if(!s.coverOpen)return ask('Open cabinet')
   if(!s.inspected)return ask('Inspect wiring')
   if(!s.battery)return ask('Connect battery')
   if(!s.ac)return ask('Apply transformer power')
   if(!physicalCircuit(s).communicating)return ask('Isolate power','The keypad is offline. Isolate power, then check the Corbus leads.')
   return group('[data-guide="neo-confirmation"]',s.enrolled?'Enter *8, training code 4256, section 903, subsection 000, and *.':'Press any keypad key to enroll the HS2LCD.')
 case 'neo-program':return programZones(s)
 case 'neo-test':
   if(!s.field.restored[0])return s.field.door?ask('Close front door','Close the door and verify the zone restores.'):ask('Open front door','Open the door and verify that Front Door trips.')
   if(!s.field.restored[1])return s.field.motion?ask('Leave detection area','Leave the coverage area and verify the zone restores.'):ask('Walk across detection area','Walk through the coverage and verify that Hall Motion trips.')
 }
 return null
}

export function showTask(host:HTMLElement,controls:HTMLElement,task:Task|null,review:()=>void){
 host.replaceChildren()
 const heading=document.createElement('h3');heading.textContent='What to do next'
 const instruction=document.createElement('p');instruction.textContent=task?.instruction??'Review your commissioning results.'
 host.append(heading)
 if(task?.instruction!==task?.button||!task?.button)host.append(instruction)
 if(task?.group){
   const inputs=controls.querySelector(task.group)
   if(inputs){host.append(inputs);return}
 }
 const original=task?.button?[...controls.querySelectorAll('button')].find(button=>button.textContent===task.button):undefined
 const source=task?.selection?[...controls.querySelectorAll('select')].find(input=>input.ariaLabel===task.selection![0]):undefined
 if(original&&!source){
   original.classList.add('primary');host.append(original);return
 }
 const primary=document.createElement('button')
 primary.type='button';primary.className='primary'
 if(source&&task?.selection){
   const value=task.selection[1]
   primary.textContent=task.button??'Select '+(source.querySelector<HTMLOptionElement>('option[value="'+CSS.escape(value)+'"]')?.textContent??value)
   primary.onclick=()=>{
     source.value=value
     if(original)original.click()
     else source.dispatchEvent(new Event('change',{bubbles:true}))
   }
 }else{
   primary.textContent=task?'Show all controls':'Review results'
   primary.onclick=task?()=>{const details=controls.closest('details');if(details){details.open=true;details.scrollIntoView({block:'nearest'})}}:review
 }
 host.append(primary)
}

