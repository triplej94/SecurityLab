"""Build the wired doorway kit using the Neo modeler's original materials and primitives."""
from pathlib import Path
source = Path(__file__).with_name('neo-equipment.py').read_text(encoding='utf-8')
exec(source.split('# HS2032-style')[0])
lens = material('Molded milky polyethylene', (.84,.88,.83),0,.26)
green = material('Relay board',(.045,.27,.135))
paper = material('Corrugated kraft',(.49,.31,.15))
foam = material('Graphite antistatic foam',(.09,.10,.10))
for magnet in [False, True]:
    height = .18 if magnet else .24
    block('Base flange',0,0,0,1,height,.075,ivory,.030)
    block('Housing',0,0,.065,.80,height,.145,poly,.055)
    for x in [-.44,.44]: screw(x,0,.046,.028)
    stroke('Alignment index',-.024,height*.38,.024,height*.38,.012,.139,seam)
    if not magnet:
        for x in [-.18,.18]: screw(x,-.02,.145,.041)
    export('7939WG-magnet' if magnet else '7939WG')
for opened in [False, True]:
    block('Mounting shell',0,0,0,.60,.92,.12,poly,.05)
    if opened:
        block('Circuit board',0,0,.071,.51,.81,.025,green,.023)
        block('PIR sensing can',0,.01,.115,.14,.115,.065,tin,.018)
        for i,t in enumerate(['T1','T2','NC','C','EOL','−','+']):
            x=-.216+i*.072
            block('Terminal cage',x,-.24,.109,.070,.106,.070,green,.006)
            screw(x,-.235,.15,.024)
            label(t,x,-.16,.089,.035)
        chipbody=block('Controller',-.12,.22,.10,.09,.12,.03,ic,.006)
        cyl('Walk LED',.08,.29,.114,.021,.035,cyan)
    else:
        block('Cover',0,0,.085,.59,.91,.20,poly,.092)
        block('Wide angle lens',0,-.078,.185,.485,.40,.055,lens,.025)
        for row in range(5):
            for col in range(8):
                x=(col-3.5)*.056
                block('Optical facet',x,-.215+row*.07,.214-.011*abs(col-3.5)/3.5,.054,.066,.013,lens,.006)
        cyl('Status window',0,.247,.19,.021,.009,cyan)
        screw(0,-.372,.177,.018)
    export('LC-100-PI-open' if opened else 'LC-100-PI')
block('Tray floor',0,0,0,1.6,.93,.04,paper,.01)
for x in [-.78,.78]: block('Folded side',x,0,.12,.04,.93,.22,paper)
for y in [-.445,.445]: block('Folded end',0,y,.12,1.56,.04,.22,paper)
block('Conductive foam',0,0,.048,1.50,.81,.055,foam,.015)
export('neo-packing-tray')
block('Lift flap',0,0,0,1.32,.64,.044,poly,.021)
block('Finger recess',0,-.29,.024,.23,.037,.013,seam,.009)
label('DSC',-.47,-.20,.026,.07,ink)
export('neo-keypad-flap')
block('Plug body',0,0,0,.44,.56,.26,poly,.06)
for x in [-.10,.10]: block('Adapter blade',x,.09,-.18,.034,.112,.14,tin,.006)
block('Strain relief',0,-.294,.01,.096,.065,.081,seam,.009)
label('12 V DC',0,.01,.132,.052,ink)
export('iq-adapter')
block('Wrapped standby pack',0,0,0,.60,.37,.12,ic,.035)
block('Label stock',0,0,.064,.43,.23,.007,ivory,.008)
label('Li-ion',0,.01,.071,.062,ink)
block('Keyed connector',.35,.10,.02,.09,.065,.052,ivory,.008)
export('iq-battery')

