"""Original anti-static bench mat. Build with Blender -b -P mat.py -- output.glb."""
import math
import sys
import bpy
from pathlib import Path
bpy.ops.wm.read_factory_settings(use_empty=True)

def surface(name,rgb,roughness,metal=0.0):
    material=bpy.data.materials.new(name)
    material.diffuse_color=(*rgb,1)
    material.use_nodes=True
    shader=material.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value=(*rgb,1)
    shader.inputs['Roughness'].default_value=roughness
    shader.inputs['Metallic'].default_value=metal
    return material

rubber=surface('Graphite blue dissipative rubber',(.057,.088,.104),.81)
edge=surface('Pressed perimeter',(.035,.058,.069),.61)
steel=surface('Nickel snap',(.55,.57,.56),.28,.78)
def plate(name,width,height,r,z,bottom,material):
    outline=[]
    for cx,cy,start in [(width/2-r,height/2-r,0),(-width/2+r,height/2-r,90),(-width/2+r,-height/2+r,180),(width/2-r,-height/2+r,270)]:
        for i in range(9):
            angle=math.radians(start+i*90/8)
            outline.append((cx+r*math.cos(angle),cy+r*math.sin(angle)))
    n=len(outline)
    vertices=[(x,-depth,y) for depth in (bottom,z) for x,y in outline]
    faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]
    faces.extend((i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n))
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(vertices,[],faces);mesh.update()
    o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);o.data.materials.append(material)
    bevel=o.modifiers.new('Soft rolled lip','BEVEL');bevel.width=.009;bevel.segments=3
    o.modifiers.new('Surface normals','WEIGHTED_NORMAL')
plate('Moulded lip',5.6,3.65,.16,.025,0,edge)
plate('Work surface',5.52,3.57,.14,.04,.019,rubber)
for x in [-2.59,2.59]:
    bpy.ops.mesh.primitive_torus_add(major_radius=.037,minor_radius=.009,location=(x,-.047,1.60),rotation=(math.pi/2,0,0),major_segments=28,minor_segments=8)
    o=bpy.context.object;o.name='Ground snap eyelet';o.data.materials.append(steel)
bpy.ops.export_scene.gltf(filepath=str(Path(sys.argv[-1]).resolve()),export_format='GLB',export_yup=True)
