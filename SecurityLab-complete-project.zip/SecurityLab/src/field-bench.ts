import * as T from 'three'
import type {RegisterPart} from './bench'
import {detail} from './visual'
import {routes,fieldStatus,operateField,fieldKey} from './field-engine'
import type {Field} from './field-engine'
type Context={register:RegisterPart;scene:T.Scene;ui:HTMLElement;hit:(o:T.Object3D,fn:()=>void)=>void;drag:(o:T.Object3D,move:(p:T.Vector3)=>void,end:(p:T.Vector3)=>void,cancel:()=>void)=>void;focus:(p:T.Vector3,span:number)=>void;update:()=>void;say:(m:string)=>void;action:(label:string,fn:()=>void)=>void}
export function fieldBench(c:Context,f:Field,isolated:boolean,online:boolean,lcd:string,setLCD:(m:string)=>void,terminalsVisible:boolean){
 const {scene,ui}=c
 function button(name:string,run:()=>void){const b=document.createElement('button');b.type='button';b.textContent=name;b.style.margin='0 .35rem .35rem 0';b.onclick=run;ui.append(b)}
 function line(value:string,tag='p'){const e=document.createElement(tag);e.textContent=value;ui.append(e)}
 function model(file:string,x:number,y:number,z:number,w:number,h:number,d:number,parent:T.Object3D=scene){
   const g=new T.Group();g.position.set(x,y,z);parent.add(g);detail(g,file+'.glb',[0,0,0],[w,h,d]);return g
 }
 function block(name:string,x:number,y:number,z:number,w:number,h:number,d:number,color:number,parent:T.Object3D=scene){
   const m=new T.Mesh(new T.BoxGeometry(w,h,d),new T.MeshStandardMaterial({color}));m.name=name;m.position.set(x,y,z);parent.add(m);return m
 }
 function label(value:string,x:number,y:number,z:number,width:number){
   const canvas=document.createElement('canvas');canvas.width=value.length<=4?112:384;canvas.height=72
   const ctx=canvas.getContext('2d')!;ctx.fillStyle='#132c34';ctx.fillRect(0,0,384,72);ctx.fillStyle='#fff';ctx.textAlign='center';ctx.font='bold 44px sans-serif';ctx.fillText(value,canvas.width/2,51,canvas.width-10)
   const map=new T.CanvasTexture(canvas);map.colorSpace=T.SRGBColorSpace
   const m=new T.Mesh(new T.PlaneGeometry(width,width*72/canvas.width),new T.MeshBasicMaterial({map}));m.position.set(x,y,z);scene.add(m);return m
 }
 const change=(i:number,msg:string,fn:()=>void)=>{if(!isolated){c.say('Isolate both power sources on the control bench before wiring.');return}c.action(msg,()=>{fn();f.observed[i]=false;f.restored[i]=false;if(i===1)f.motion=false})}
 const mount=(i:number)=>change(i,'Mount '+(i?'LC-100-PI':'7939WG'),()=>f.mounted[i]=true)
 const operate=(i:number)=>c.action(i?'Walk test · hallway':'Operate front door',()=>{operateField(f,i,online);if(online){f.section='';f.entry='';setLCD((i?'Hall Motion':'Front Door')+' '+fieldStatus(f,i,online))}})
 const setEnd=(dest:string)=>{const i=f.selected;if(f.tight[i]){c.say('Loosen the selected lead first.');return}change(i<2?0:1,'Land '+routes[i][0]+' at '+dest,()=>f.ends[i]=dest)}
 line('Wired doorway','h3')
 line('Mount the switch on the fixed header, align the magnet on the door, and aim the PIR across the walking path. Open the cabinet to see the enlarged zone and AUX terminals.')
 block('Wall above door',-.95,1.25,-.12,1.65,.60,.13,0xa1ada8)
 for(const x of [-1.75,-.17])block('Door jamb',x,-.27,-.10,.085,2.45,.13,0x987551)
 block('Door header',-.96,.99,-.05,1.66,.15,.13,0xb08e69)
 const hinge=new T.Group();hinge.position.set(-1.70,-1.47,.015);hinge.rotation.y=f.door?-.88:0;scene.add(hinge)
 const door=model('iq-door',.74,1.19,.02,1.48,2.38,.12,hinge);c.hit(door,()=>operate(0));c.register('neo-door','Entry door',door,2.60)
 const contact=model('7939WG',f.mounted[0]?-.5:-1.05,f.mounted[0]?.99:-1.45,.12,.21,.058,.041)
 c.register('neo-contact','7939WG wired contact',contact,.36)
 const magnet=f.mounted[0]?model('7939WG-magnet',f.aligned?1.20:.87,2.35,.085,.21,.047,.035,hinge):model('7939WG-magnet',-.82,-1.45,.12,.21,.047,.035)
 c.register('neo-magnet','7939WG magnet',magnet,.30)
 const pir=model(f.cover?'LC-100-PI-open':'LC-100-PI',f.mounted[1]?-1.04:-.57,f.mounted[1]?1.35:-1.44,.12,.20,.31,.13)
 c.register('neo-pir','LC-100-PI motion detector',pir,.48)
 for(const [i,part,target] of [[0,contact,new T.Vector2(-.5,.99)],[1,pir,new T.Vector2(-1.04,1.35)]] as const){
   if(!f.mounted[i])c.drag(part,p=>part.position.set(p.x,p.y,.18),p=>{if(Math.hypot(p.x-target.x,p.y-target.y)<.39)mount(i);else c.update()},c.update)
 }
 for(const [i,name] of ['7939WG header contact','LC-100-PI above door'].entries())if(!f.mounted[i])button('Mount '+name,()=>mount(i))
 if(f.mounted[1]&&!f.cover){
   const shape=new T.Shape();shape.moveTo(0,0);shape.lineTo(-.48,-1.02);shape.quadraticCurveTo(0,-1.18,.48,-1.02);shape.closePath()
   const wedge=new T.Mesh(new T.ShapeGeometry(shape),new T.MeshBasicMaterial({color:f.motion?0xa8d984:0x8bc6d3,transparent:true,opacity:.19,depthWrite:false}))
   wedge.position.set(-1.04,1.20,.29);scene.add(wedge);c.hit(wedge,()=>operate(1));c.register('neo-coverage','Motion coverage',pir,.48,wedge)
 }
 if(f.mounted[0])button(f.aligned?'Misalign magnet':'Align magnet',()=>change(0,'Adjust magnet',()=>f.aligned=!f.aligned))
 if(f.mounted[1])button(f.cover?'Close detector cover':'Remove detector cover',()=>change(1,'PIR cover',()=>f.cover=!f.cover))
 line('Field wiring','h3')
 const leads=document.createElement('select');leads.ariaLabel='Field conductor';routes.forEach(([n],i)=>leads.add(new Option(n,String(i))));leads.value=String(f.selected);leads.onchange=()=>c.action('Select field conductor',()=>f.selected=Number(leads.value));ui.append(leads)
 const ports=['Z1','COM','Z2','AUX+','AUX−']
 const slot=(name:string)=>.57+ports.indexOf(name)*.215
 const land=(dest:string)=>{const i=f.selected;if(!f.mounted[i<2?0:1]||(i>=2&&!f.cover)){c.say('Mount the device and expose its wiring terminals first.');return}setEnd(dest)}
 for(const name of ports)button('Land at '+name,()=>land(name))
 if(terminalsVisible)for(const name of ports){const x=slot(name);const clamp=model('neo-corbus-clamp',x,.48,.25,.18,.16,.10)
   c.hit(clamp,()=>land(name));c.register('neo-port-'+name,name+' field terminal',clamp,.30);label(name,x,.61,.26,.15)}
 button(f.tight[f.selected]?'Loosen field lead':'Clamp field lead',()=>{const i=f.selected;if(!f.ends[i]){c.say('Choose a destination first.');return}change(i<2?0:1,'Field clamp',()=>f.tight[i]=!f.tight[i])})
 for(const [i,n] of ['Door','Motion'].entries()){
   button((f.resistor[i]?'Remove':'Fit')+' '+n+' 5.6 kΩ resistor',()=>{if(!f.mounted[i]||i===1&&!f.cover){c.say('Mount the contact or expose the PIR terminals first.');return}change(i,n+' field resistor',()=>f.resistor[i]=!f.resistor[i])})
   if(f.resistor[i]){
     const x=i?-1.0:-.48,y=i?1.22:.91
     block('Field resistor leads',x,y,.23,.15,.008,.008,0xbfc4c4);block('5.6 kΩ',x,y,.23,.083,.024,.019,0xc2a278)
     ;[0x67aa65,0x579ac3,0xcb5140,0xac933f].forEach((col,k)=>block('Resistance band',x-.028+.017*k,y,.24,.008,.026,.008,col))
   }
 }
 for(const [i,r] of routes.entries()){
   const y=.28-i*.064, end=f.ends[i]
   const tip=new T.Vector3(end?slot(end)+(i%2)*.024:1.68,end?.40:y,.24+i*.012)
   if(!f.mounted[i<2?0:1])continue
   const sx=i<2?-.50:-1.04,sy=i<2?.99:1.35
   if(i===0||i===2){
     const route=new T.CatmullRomCurve3([[sx,sy,.13],[sx+.12,sy+.09,.02],[.25,sy+.09,-.07],[.30,-.32+i*.05,-.05],[.58,-.32+i*.05,.12],[.60,-.23,.14]].map(p=>new T.Vector3(...p)))
     scene.add(new T.Mesh(new T.TubeGeometry(route,40,.025,8,false),new T.MeshStandardMaterial({color:i===0?0xe0dbbf:0xbfc8bd})))
     for(const yy of [.93,.69,-.07])block('Field cable clip',.29,yy,-.045,.079,.041,.032,0x69786b)
   }
   if(!terminalsVisible)continue
   const pts=[new T.Vector3(.57+i*.012,-.23,.15),new T.Vector3(.67+i*.014,y,.23),new T.Vector3(tip.x-.04,y,tip.z),tip]
   const pipe=new T.Mesh(new T.TubeGeometry(new T.CatmullRomCurve3(pts),32,i===f.selected?.023:.014,8,false),new T.MeshStandardMaterial({color:[0xededdf,0x87684e,0x83a286,0xe5c870,0xe06352,0x353745][i]}));scene.add(pipe);c.hit(pipe,()=>c.action('Select '+r[0],()=>f.selected=i))
   const grip=block('Conductor tip',tip.x,tip.y,tip.z,.075,.065,.045,f.tight[i]?0x719979:0xc99368)
   const handle=block('Selected lead grip',tip.x,tip.y,tip.z+.035,.13,.13,.09,0);handle.material.visible=false; if(i===f.selected)c.drag(handle,p=>{
     if(!isolated||f.tight[i])return
     grip.position.set(p.x,p.y,.30)
     pipe.geometry.dispose()
     pipe.geometry=new T.TubeGeometry(new T.CatmullRomCurve3([...pts.slice(0,-1),grip.position.clone()]),32,.023,8,false)
   },p=>{const dst=ports.find(n=>Math.abs(p.x-slot(n))<.103&&Math.abs(p.y-.48)<.13);if(dst&&i===f.selected){land(dst);c.update()}else{c.say('Select this conductor and drop it at a labeled clamp.');c.update()}},c.update)
 }
 line('NC/C is the PIR alarm relay. Fit each 5.6 kΩ resistor in series at the field device. The LC-100-PI has a spare EOL tie point at terminal 5.');
 line(routes[f.selected][0]+' → '+(f.ends[f.selected]||'free end')+(f.tight[f.selected]?' · clamped':' · loose'))
 line('Zone programming and test','h3')
 line('Apply power and confirm the keypad before programming zones. Use *8 and training code 4256 here. Section 001 sets zone 001 to 001 (Delay 1) and zone 002 to 005 (Interior Stay/Away). In 013 set options 1 and 2 OFF for SEOL. In 201, group 001, turn zones 1 and 2 ON. Use # to leave each option screen.')
 const key=(k:string)=>{if(!online){c.say('Power and confirm the keypad on the control bench first.');return}c.action('HS2LCD '+k,()=>{const prior=JSON.stringify([f.types,f.partition,f.nc,f.double]);const msg=fieldKey(f,k);if(prior!==JSON.stringify([f.types,f.partition,f.nc,f.double])){f.observed.fill(false);f.restored.fill(false)}setLCD(msg)})}
 const pad=document.createElement('div');pad.className='neo-buttons';pad.dataset.guide='neo-programming';ui.append(pad)
 const display=document.createElement('output');display.textContent=online?(lcd||'System ready'):'Keypad offline';pad.append(display)
 if(online)for(const k of '123456789*0#'){
   const b=document.createElement('button');b.textContent=k;b.onclick=()=>key(k);pad.append(b)
 }
 button(f.door?'Close front door':'Open front door',()=>operate(0));button(f.motion?'Leave detection area':'Walk across detection area',()=>operate(1))
 for(const [i,name] of ['Front Door','Hall Motion'].entries())line('Z'+(i+1)+' · '+name+' · '+fieldStatus(f,i,online))
 button('Inspect doorway header',()=>c.focus(new T.Vector3(-.88,1.14,.12),1.3))
 button('Inspect field wiring',()=>c.focus(new T.Vector3(1.22,.46,.19),1.65))
 return key
}


