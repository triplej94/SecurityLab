export type Placement = 'bench' | 'frame' | 'aligned' | 'wide'
export interface Zone {
  name:string; group:string; chime:string; voice:boolean
}
export const zoneID = 'LAB-0945'
export const motionID = 'LAB-0914'
export const labCode = '4726'
export function initialIQ() {
  return {
    box:false, unpacked:false, loose:false, plateOff:false, plateMounted:false,
    battery:false, cable:false, seated:false, secured:false, adapter:false, on:false,
    transmitter:'bench' as Placement, magnet:'bench' as Placement, door:false,
    screen:'home', dealer:false, identified:false, zone:null as Zone|null,
    motionMounted:false, motionCover:false, motionZone:null as Zone|null,
    motionDetected:false, motionTested:false, sensor:'contact' as 'contact'|'motion',
    pin:'', testedOpen:false, testedClosed:false, commissioned:false,
    statusMessage:'', log:[] as string[]
  }
}
export type IQ = ReturnType<typeof initialIQ>
export function contactClosed(s:IQ) {
  return !s.door && s.transmitter==='frame' && s.magnet==='aligned'
}
export function iqChecks(s:IQ) {
  return [
    {label:'Panel secured on its SmartMount',pass:s.plateMounted && s.secured},
    {label:'Battery, supplied 12 V adapter and panel power',pass:s.battery && s.cable && s.adapter && s.on},
    {label:'PowerG ID confirmed and Front Door programmed in group 10',pass:s.identified && s.zone?.name.toLowerCase()==='front door' && s.zone?.group==='10'},
    {label:'Transmitter on frame and magnet within 6 mm',pass:s.transmitter==='frame' && s.magnet==='aligned'},
    {label:'Observed open, then restored with door closed',pass:s.testedOpen && s.testedClosed && contactClosed(s)},
    {label:'Hall Motion mounted and programmed in group 17',pass:s.motionMounted && s.motionZone?.name.toLowerCase()==='hall motion' && s.motionZone.group==='17'},
    {label:'Hallway walk test recorded',pass:s.motionMounted && s.motionTested}
  ]
}
export function installAction(s:IQ, key:string):string|null {
  const rules:Record<string,[boolean,string,keyof IQ]> = {
    box:[true,'','box'],
    unpacked:[s.box,'Open the equipment box first.','unpacked'],
    loose:[s.unpacked && !s.adapter,'Inspect the unpacked panel with external power disconnected.','loose'],
    plateOff:[s.loose,'Release the rear locking screw first.','plateOff'],
    plateMounted:[s.plateOff,'Remove the backplate before mounting it.','plateMounted'],
    battery:[s.plateOff && !s.seated && !s.adapter,'Expose the rear battery connector with external power disconnected.','battery'],
    cable:[s.plateOff && s.battery && !s.seated && !s.adapter,'Connect the battery first, with the back of the panel accessible.','cable'],
    seated:[s.plateMounted && s.battery && s.cable,'Mount the plate and connect the battery and barrel cable first.','seated'],
    secured:[s.seated,'Latch the panel to the mounted backplate first.','secured'],
    adapter:[s.cable && s.battery && s.secured,'Secure the panel and check both low-voltage connections first.','adapter'],
    on:[s.adapter && s.battery && s.secured,'The panel needs its connected battery and supplied adapter.','on']
  }
  const rule=rules[key];if(!rule)return 'Unknown installation action.'
  if(!rule[0])return rule[1]
  if(s[rule[2]])return 'That part is already in position.'
  Object.assign(s,{[rule[2]]:true});return null
}
export function placePart(s:IQ,part:'transmitter'|'magnet',pos:Placement) {
  s[part]=pos;s.testedOpen=false;s.testedClosed=false;s.commissioned=false
}
export function moveDoor(s:IQ) {
  const wasClosed=contactClosed(s);s.door=!s.door
  const nowClosed=contactClosed(s)
  if(s.on && s.zone && wasClosed!==nowClosed) {
    if(nowClosed && s.testedOpen)s.testedClosed=true
    if(!nowClosed)s.testedOpen=true
    return s.zone.name+' · '+(nowClosed?'Closed':'Open')
  }
  return s.door?'Door opened':'Door closed'
}
