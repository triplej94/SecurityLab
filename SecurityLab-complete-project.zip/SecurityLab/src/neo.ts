import * as THREE from 'three';
import {fieldBench} from './field-bench';
import type {RegisterPart} from './bench';
import {drawRoom} from './neo-room';
import {detail} from './visual';
import {initialNeo, physicalCircuit, wiringFaults, programKey, terminals} from './neo-engine';
import type {Side, NeoState} from './neo-engine';
export {initialNeo};
type Context = {
 register:RegisterPart;scene:THREE.Scene;state:NeoState;mode:string;update:()=>void;
 action:(label:string,fn:()=>void)=>void;say:(msg:string)=>void;hit:(obj:THREE.Object3D,fn:()=>void)=>void;
 drag:(obj:THREE.Object3D,fn:(pt:THREE.Vector3)=>void,end?:(pt:THREE.Vector3)=>void,cancel?:()=>void)=>void;
 focus:(pt:THREE.Vector3,span:number)=>void;ui:HTMLElement
};
const sides:Side[]=['board','keypad'];
const colors=[0xf2604d,0x333941,0xffcc42,0x53aa73];
const vec=(x:number,y:number,z=.1)=>new THREE.Vector3(x,y,z);
const center=(side:Side)=>side==='board'?-1.04:1.04;
const pos=(side:Side,port:number)=>vec(center(side)-.33+.22*port,-.32,.28);
function objective(s:NeoState){
 if(!s.board)return 'Seat the HS2032 in the enclosure.';
 if(!s.keypad)return 'Position the HS2LCD keypad on its mount.';
 if(!s.cable)return 'Select a four-conductor 22 AWG cable.';
 if(!s.routed)return 'Route the cable between the panel and keypad.';
 if(!s.jacket.board||!s.jacket.keypad)return 'Strip the outer jacket at each end.';
 if(s.ends.some(w=>sides.some(side=>w[side].terminal===null||!w[side].tight)))return 'Strip each lead, drag its copper end to a terminal, then tighten the screw. Complete both ends.';
 if(!s.inspected)return 'Inspect the wiring and trace each conductor.';
 if(!s.battery)return 'Connect the simulated standby battery.';
 if(!s.ac)return 'Apply simulated transformer power.';
 if(!physicalCircuit(s).communicating)return 'Use the inspector and continuity tool to diagnose the wiring. Isolate power before repairs.';
 if(!s.enrolled)return 'Press a keypad key to enroll the first wired keypad.';
 if(!s.confirmed)return 'Confirm the enrolled module. Enter *8, training code 4256, section 903, subsection 000, then *. # clears an entry.';
 return 'Return to the mechanical room to program and test both field zones.';
}
export function createNeo(c:Context){
 const s=c.state;const parent=c.scene;const panel=c.ui;
 const circuit=physicalCircuit(s);
 const landingRadius=.14;
 const nearestPort=(side:Side,p:THREE.Vector3)=>{
   let best=-1,distance=landingRadius;
   for(const [i] of terminals.entries()){
     const port=pos(side,i),d=Math.hypot(p.x-port.x,p.y-port.y);
     if(d<distance){best=i;distance=d}
   }
   return best;
 };
 const box=(n:string,p:THREE.Vector3,w:number,h:number,d:number,color:number,metal=0)=>{
  const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshStandardMaterial({color,metalness:metal,roughness:.5}));
  o.name=n;o.position.copy(p);parent.add(o);return o;
 };
 const text=(str:string,p:THREE.Vector3,width:number,height:number,fg='#e1e9e4',bg='')=>{
   const canvas=document.createElement('canvas');canvas.width=640;canvas.height=128;
   const g=canvas.getContext('2d')!;g.font='bold 88px Arial';canvas.width=Math.ceil(g.measureText(str).width)+24; if(bg){g.fillStyle=bg;g.fillRect(0,0,canvas.width,128)}
   g.fillStyle=fg;g.font='bold 88px Arial';g.textAlign='center';g.textBaseline='middle';g.fillText(str,canvas.width/2,65);
   const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;
   const o=new THREE.Mesh(new THREE.PlaneGeometry(width,height),new THREE.MeshBasicMaterial({map:texture,transparent:true,depthWrite:false}));o.position.copy(p);parent.add(o);return o;
 };
 const tube=(pts:THREE.Vector3[],r:number,color:number)=>{
  const curve=new THREE.CatmullRomCurve3(pts);
  const obj=new THREE.Mesh(new THREE.TubeGeometry(curve,22,r,8,false),new THREE.MeshStandardMaterial({color,roughness:.54}));
  parent.add(obj);return obj;
 };
 const note=(s:string)=>{const e=document.createElement('p');e.textContent=s;panel.append(e)};
 const title=(s:string)=>{const h=document.createElement('h3');h.textContent=s;panel.append(h)};
 const controls=()=>{const e=document.createElement('div');e.className='neo-buttons';e.style.cssText='display:flex;gap:.35rem;flex-wrap:wrap;margin:.45rem 0';panel.append(e);return e};
 const button=(e:HTMLElement,t:string,f:()=>void)=>{const b=document.createElement('button');b.type='button';b.textContent=t;b.onclick=f;e.append(b);return b};
 const change=(label:string,fn:()=>void)=>c.action(label,fn);
 const manipulate=(label:string,fn:()=>void)=>{if(s.ac||s.battery){c.say('Isolate transformer and battery power before changing the wiring.');return}change(label,()=>{fn();s.inspected=false;s.confirmed=false;s.test=''})};
 const install=(side:Side)=>{if(!s.unpacked||(side==='board'&&(!s.cabinet||!s.coverOpen))){c.say('Unpack the kit and open the mounted cabinet before fitting the board.');return}manipulate(side==='board'?'Mount HS2032':'Mount HS2LCD',()=>s[side]=true)};
 const select=(side:Side,i:number)=>change('Select '+side+' '+terminals[i]+' lead',()=>{s.side=side;s.wire=i});
 const active=()=>s.ends[s.wire][s.side];
 const strip=()=>{if(!s.jacket[s.side]){c.say('Remove the outer jacket first.');return}manipulate('Strip '+s.side+' '+terminals[s.wire]+' lead',()=>active().stripped=true)};
 const insert=(side:Side,i:number,port:number)=>{
   if(!s[side]||!s.jacket[side]){c.say('Mount the equipment and expose the conductor bundle first.');return}
   const e=s.ends[i][side];
   if(!e.stripped){c.say('Strip insulation from this conductor end before inserting it.');return}
   if(e.tight){c.say('Loosen the screw first.');return}
   if(s.ends.some((w,j)=>j!==i&&w[side].terminal===port)){c.say('That terminal is occupied. Select an empty terminal.');return}
   manipulate('Insert '+terminals[i]+' lead into '+side+' '+terminals[port],()=>{e.terminal=port;e.position=null;s.side=side;s.wire=i});
 };
 const screw=()=>{const e=active();if(e.terminal===null){c.say('Insert the selected conductor into a terminal first.');return}manipulate(e.tight?'Loosen terminal screw':'Tighten terminal screw',()=>e.tight=!e.tight)};
 const press=(key:string)=>{if(!circuit.communicating){c.say(circuit.powered?'Power is present. Inspect the data pair.':'No keypad power.');return}change('Keypad '+key,()=>{programKey(s,key)})};
 const inspect=()=>{const faults=wiringFaults(s);
   const secured=s.field.tight.filter(Boolean).length;
   const fieldSummary=secured+' of 6 field leads clamped. '+s.field.resistor.filter(Boolean).length+' of 2 resistors fitted.';
   change('Inspect wiring',()=>{s.inspected=true;s.test=(faults.length?faults.join(' '):'All four Corbus paths match.')+' '+fieldSummary})
};
 const battery=()=>{if(!s.routed||!s.inspected||!s.field.mounted.every(Boolean)||!s.field.tight.every(Boolean)||!s.field.resistor.every(Boolean)||s.field.cover){c.say('Finish and inspect the Corbus and both field circuits, then close the PIR cover before connecting the battery.');return}change('Connect standby battery',()=>s.battery=true)};
 const ac=()=>{if(!s.battery){c.say('Connect the standby battery first.');return}change('Apply transformer power',()=>s.ac=true)};
 const isolate=()=>change('Isolate transformer and battery power',()=>{s.ac=false;s.battery=false;s.lcd='';s.keys='';s.field.entry='';s.field.section=''});
 const cable=()=>{if(!s.board||!s.keypad){c.say('Mount the board and keypad first.');return}manipulate('Select 22/4 cable',()=>s.cable=true)};
 const route=()=>manipulate('Route cable',()=>s.routed=true);
 const jacket=(side:Side)=>{if(!s.routed){c.say('Route the cable first.');return}manipulate('Remove '+side+' jacket',()=>{s.jacket[side]=true;s.side=side})};
 const readout=!circuit.powered?'':!circuit.communicating?'Bus unavailable':!s.enrolled?'Press any key':s.lcd||'System ready';
 // Blender surfaces carry the fine detail. Pick targets match the moving controls.
 const pick=(name:string,p:THREE.Vector3,w:number,h:number,d:number)=>{
   const o=box(name,p,w,h,d,0);
   (o.material as THREE.MeshStandardMaterial).visible=false;
   return o;
 };
 if(!s.service){
   const unpack=()=>change('Unpack HS2032 board kit',()=>s.unpacked=true)
   const cabinet=()=>{if(!s.unpacked){c.say('Open the equipment carton first.');return}change('Mount Neo cabinet on plywood',()=>s.cabinet=true)}
   const cover=()=>change(s.coverOpen?'Close cabinet':'Open cabinet',()=>s.coverOpen=!s.coverOpen)
   const service=()=>{change('Corbus terminal close-up',()=>s.service=true);c.focus(vec(0,0,0),4)}
   title('Mechanical room')
   const installRow=controls()
   if(!s.unpacked)button(installRow,'Open HS2032 carton',unpack)
   if(s.unpacked&&!s.cabinet)button(installRow,'Mount cabinet on backboard',cabinet)
   if(s.cabinet)button(installRow,s.coverOpen?'Close cabinet':'Open cabinet',cover)
   if(s.cabinet&&s.coverOpen&&!s.board)button(installRow,'Mount HS2032',()=>install('board'))
   if(s.unpacked&&!s.keypad)button(installRow,'Mount HS2LCD',()=>install('keypad'))
   if(s.board&&s.keypad)button(installRow,'Corbus terminal close-up',service)
   const power=controls()
   if(s.cabinet&&s.coverOpen&&!s.battery)button(power,'Connect battery',battery)
   if(!s.ac)button(power,'Apply transformer power',ac)
   if(s.battery||s.ac)button(power,'Isolate power',isolate)
   if(s.routed)button(power,'Inspect wiring',inspect)
   if(s.test)note(s.test)
   const fieldUI=s.unpacked&&s.board?panel:document.createElement('div')
   const fieldKey=fieldBench({...c,ui:fieldUI},s.field,!s.ac&&!s.battery,circuit.communicating&&s.confirmed,readout,msg=>s.lcd=msg,s.cabinet&&s.coverOpen&&s.board)
   drawRoom(c,s,{unpack,cabinet,cover,board:()=>install('board'),keypad:()=>install('keypad'),key:s.confirmed?fieldKey:press,battery,transformer:ac},readout)
   if(circuit.communicating&&!s.confirmed){
     title('Enroll and confirm keypad');note('Press any key to enroll. Then enter *8, training code 4256, section 903, subsection 000, and *. Use the keypad on the wall or below.')
     const pad=controls();pad.dataset.guide='neo-confirmation';const lcd=document.createElement('output');lcd.textContent=readout;pad.append(lcd);for(const key of '123456789*0#')button(pad,key,()=>press(key))
   }
   return
 }
 if(!s.unpacked){
   detail(parent,'neo-packing-tray.glb',[0,0,.03],[2.2,1.35,.24]);
   detail(parent,'iq-box-lid.glb',[0,0,.24],[2.23,1.37,.10]);
   const unpack=()=>change('Unpack HS2032 board kit',()=>s.unpacked=true);
   c.hit(pick('Open carton',vec(0,0,.30),2.23,1.37,.10),unpack);
   title('HS2032 installation kit');note('Open the carton and lift the board from its protective tray. The cabinet, keypad and field devices are staged separately.');
   button(controls(),'Open HS2032 carton',unpack);return;
 }
 if(!s.board)detail(parent,'neo-packing-tray.glb',[-1.04,-.98,.07],[1.68,.98,.15]);
 button(controls(),'Return to mechanical room',()=>{change('Mechanical room',()=>s.service=false);c.focus(vec(0,.14,.21),5.6)});
 detail(parent,'neo-cabinet.glb',[-1.04,.28,-.13],[1.89,1.59,.23]);
 const boardY=s.board ? .40 : -.97,boardZ=s.board ? .15 : .31;
 c.register('neo-board','HS2032 control board',detail(parent,'neo-hs2032-board.glb',[-1.04,boardY,boardZ],[1.60,.89,.19]),1.84);
 if(!s.board){
   const mount=()=>install('board');
   c.hit(pick('Seat HS2032',vec(-1.04,boardY,boardZ),1.60,.89,.20),mount);
   const caption=text('Seat board in enclosure',vec(-1.04,-.13,.23),1.0,.096);
   c.hit(caption,mount);
 }
 const keypadY=s.keypad ? .52 : .60;
 const keypadZ=s.keypad ? .115 : .21;
 c.register('neo-keypad','HS2LCD keypad',detail(parent,'neo-hs2lcd.glb',[1.04,keypadY,keypadZ],[1.52,1.076,.19]),1.62);
 const flapY=keypadY+(s.flap?-.21:-.55);
 const flap=pick('HS2LCD key cover',vec(1.04,flapY,.25),1.38,s.flap?.63:.10,.03);
 detail(parent,'neo-keypad-flap.glb',[1.04,flapY,.24],[1.38,s.flap?.63:.10,.035]);
 const flip=()=>change('HS2LCD cover',()=>s.flap=!s.flap);
 c.hit(flap,flip);button(controls(),s.flap?'Open keypad flap':'Close keypad flap',flip);
 if(!s.keypad){
   c.hit(pick('Seat HS2LCD',vec(1.04,keypadY,keypadZ),1.50,1.06,.20),()=>install('keypad'));
   c.hit(text('Seat keypad on mount',vec(1.04,-.07,.20),1.0,.096),()=>install('keypad'));
 }else{
   // The LCD is drawn over the GLB lens so its content is always live.
   const displayY=keypadY+.275;
   box('LCD glass',vec(.983,displayY,.201),.943,.232,.008,circuit.powered?0x87bdc7:0x72898a);
   text(readout,vec(.983,displayY,.209),.89,.080,'#132e35');
   if(!s.flap)for(const [i,k] of [...'123456789*0#'].entries()){
     const x=1.04+(-.16+(i%3)*.151)*1.035;
     const y=keypadY+(-.01-Math.floor(i/3)*.112)*1.04;
     c.hit(pick('Key '+k,vec(x,y,.218),.137,.088,.018),()=>press(k));
   }
 }
 for(const side of sides){
   if(!s[side])continue;
   // The four bus clamps form an enlarged service view for lead placement.
   const strip=box('Service strip backing',vec(center(side),-.275,.14),1.03,.39,.07,0x244951);
   c.register('neo-'+side+'-corbus',side==='board'?'Board Corbus terminals':'Keypad Corbus terminals',strip,1.20);
   for(let i=0;i<4;i++){
     const p=pos(side,i);
     const clamped=s.ends.some(w=>w[side].terminal===i&&w[side].tight);
     detail(parent,'neo-corbus-clamp.glb',[p.x,p.y,.29],[.207,.196,.123]);
     const port=pick(side+' '+terminals[i],p,.213,.224,.147);
     const slot=box('Clamp slot',vec(p.x,p.y+.029,.354),.050,.009,.004,0x354243);
     slot.rotation.z=clamped?.82:.10;
     text(terminals[i],vec(p.x,p.y+.151,.270),.169,.066,'#f3eee1');
     const operate=()=>{if(s.side!==side){c.say('Select a lead on the '+side+' end of the cable.');return}if(active().terminal===i)screw();else insert(side,s.wire,i)};
     c.hit(port,operate);c.hit(slot,operate);
   }
 }
 if(s.cable){
   const a=vec(-1.04,-.88,.19),b=vec(1.04,-.88,.19);
   const bend=vec(s.bend[0],s.bend[1],.2);
   const routePoints=(p:THREE.Vector3)=>[a,vec(-.75,-1.14,.2),p,vec(.75,-1.14,.2),b];
   const cableObj=tube(s.routed?routePoints(bend):[vec(-.4,-1.2,.2),bend,vec(.4,-1.2,.2)],.047,0xccd2cc);
   const boundedBend=(p:THREE.Vector3)=>vec(THREE.MathUtils.clamp(p.x,-1.2,1.2),THREE.MathUtils.clamp(p.y,-1.7,-.75),.2);
   const reshape=(mesh:THREE.Mesh,points:THREE.Vector3[],radius:number,segments:number)=>{
     mesh.geometry.dispose();
     mesh.geometry=new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),segments,radius,10,false);
   };
   const preview=box('Terminal landing preview',vec(0,0,.38),.196,.19,.003,0xbaf58a);
   const previewMaterial=preview.material as THREE.MeshStandardMaterial;
   previewMaterial.transparent=true;previewMaterial.opacity=.28;previewMaterial.depthWrite=false;
   preview.visible=false;
   // A sleeve on the jacket marks the routing grip.
   const handle=pick('Cable routing grip',bend.clone(),.18,.14,.13);
   const sleeve=new THREE.Group();sleeve.position.copy(bend);parent.add(sleeve);
   for(const [dx,w,r] of [[0,.11,.054],[-.06,.013,.056],[.06,.013,.056]]){
    const ring=new THREE.Mesh(new THREE.CylinderGeometry(r,r,w,18),new THREE.MeshStandardMaterial({color:dx===0?0xb3b6ad:0x747c72,roughness:.72}));
    ring.rotation.z=Math.PI/2;ring.position.x=dx;sleeve.add(ring);
   }
   c.hit(cableObj,()=>s.routed?c.say('Drag the routing grip to reroute this cable.'):route());
   c.drag(handle,p=>{
     if(s.ac||s.battery)return;
     const point=boundedBend(p);handle.position.copy(point);sleeve.position.copy(point);
     reshape(cableObj,routePoints(point),.047,40);
   },p=>manipulate('Route cable bend',()=>{const point=boundedBend(p);s.routed=true;s.bend=[point.x,point.y]}),c.update);
   for(const side of sides){if(!s.jacket[side])continue;
    for(let i=0;i<4;i++){
      const e=s.ends[i][side],cx=center(side);
      const start=vec(cx+(i-1.5)*.017,-.88,.205);
      const end=e.terminal!==null?pos(side,e.terminal):e.position?vec(...e.position,.32):vec(cx+(i-1.5)*.24,-.57,.32);
      const middle=vec((start.x+end.x)/2,start.y+.11,.23);
      const stem=vec(end.x,end.y-.06,.27);
      const wire=tube([start,middle,stem],.026,colors[i]);
      const grip=pick('Lead '+terminals[i]+' '+side,end.clone(),.10,.10,.07);
      const sleeve=new THREE.Group();parent.add(sleeve);
      const lead=end.clone().sub(stem),length=lead.length();
      const axis=new THREE.Vector3(0,1,0);
      const insulation=new THREE.Mesh(new THREE.CylinderGeometry(.023,.025,e.stripped?length*.18:length,12),new THREE.MeshStandardMaterial({color:colors[i],roughness:.57}));
      insulation.position.y=e.stripped?length*.09:length*.5;sleeve.add(insulation);
      if(e.stripped){
       const copper=new THREE.MeshStandardMaterial({color:0xc98954,metalness:.52,roughness:.42});
       const geometry=new THREE.CylinderGeometry(.0055,.0055,length*.82,8);
       for(let j=0;j<7;j++){
        const strand=new THREE.Mesh(geometry,copper);
        const theta=(j-1)*Math.PI/3;
        strand.position.set(j ? .010*Math.cos(theta):0,length*.59,j ? .010*Math.sin(theta):0);sleeve.add(strand)
       }
      }
      function placeLead(p:THREE.Vector3,base:THREE.Vector3){
       sleeve.position.copy(base);sleeve.quaternion.setFromUnitVectors(axis,p.clone().sub(base).normalize());
       grip.position.copy(p)
      }
      placeLead(end,stem);
      c.hit(wire,()=>select(side,i));
      const during=(p:THREE.Vector3)=>{if(s.ac||s.battery||e.tight)return;
        const at=vec(p.x,p.y-.06,.27);const top=vec(p.x,p.y,.32);
        placeLead(top,at);reshape(wire,[start,middle,at],.026,24);
        const port=nearestPort(side,p);
        preview.visible=port!==-1;
        if(port!==-1){
          const at=pos(side,port);
          const occupied=s.ends.some((lead,j)=>j!==i&&lead[side].terminal===port);
          preview.position.set(at.x,at.y,.386);
          previewMaterial.color.set(e.stripped&&!occupied?0xbaf58a:0xff8a65);
        }
      };
      const finish=(p:THREE.Vector3)=>{if(e.tight||s.ac||s.battery){c.say('Isolate power and loosen the terminal before moving this end.');return}
        const port=nearestPort(side,p);
        if(port>=0){insert(side,i,port);c.update();return}
        manipulate('Move '+side+' '+terminals[i]+' lead',()=>{s.side=side;s.wire=i;e.position=[p.x,p.y];e.terminal=null})};
      c.drag(grip,during,finish,c.update);c.drag(sleeve,during,finish,c.update)
    }
   }
 }

 title('Corbus workbench');
 const assessment=c.mode.toLowerCase()==='assessment';
 if(!assessment && c.mode.toLowerCase()!=='sandbox')note(objective(s));
 const mountRow=controls();
 if(!s.board)button(mountRow,'Mount HS2032',()=>install('board'));
 if(!s.keypad)button(mountRow,'Mount HS2LCD',()=>install('keypad'));
 if(!s.cable)button(mountRow,'Select 22/4 cable',cable);
 else if(!s.routed)button(mountRow,'Route cable',route);
 if(s.routed){
  for(const side of sides){if(!s.jacket[side])button(mountRow,'Strip '+side+' jacket',()=>jacket(side))}
  const conductor=document.createElement('select');conductor.setAttribute('aria-label','Conductor end');
  for(const side of sides)for(let i=0;i<4;i++){const opt=new Option((side==='board'?'Board':'Keypad')+' · '+terminals[i]+' lead',side+':'+i);conductor.append(opt)}
  conductor.value=s.side+':'+s.wire;conductor.onchange=()=>{const [side,i]=conductor.value.split(':');select(side as Side,Number(i))};panel.append(conductor);
  if(s.jacket[s.side]){
   const end=active(),prep=controls();
   if(!end.stripped)button(prep,'Strip conductor',strip);
   if(end.stripped){
    const dock=document.createElement('select');dock.setAttribute('aria-label','Destination terminal');for(const [i,t] of terminals.entries())dock.append(new Option(s.side+' '+t,String(i)));dock.value=String(end.terminal??s.wire);prep.append(dock);
    button(prep,'Insert lead',()=>insert(s.side,s.wire,Number(dock.value)));
   }
   if(end.terminal!==null){
    button(prep,end.tight?'Loosen screw':'Tighten screw',screw);
    button(prep,'Withdraw lead',()=>{if(end.tight){c.say('Loosen the terminal first.');return}manipulate('Withdraw conductor',()=>{end.terminal=null;end.position=null})});
   }
   note(terminals[s.wire]+' · '+(!end.stripped?'Insulated':end.terminal===null?'Stripped, free':terminals[end.terminal]+(end.tight?' clamped':' inserted, screw loose')));
  }
  const tests=controls();button(tests,'Inspect wiring',inspect);
  button(tests,'Trace conductor',()=>change('Trace selected conductor',()=>{
   const wire=s.ends[s.wire];const path=(side:Side)=>wire[side].terminal===null?'free end':terminals[wire[side].terminal!]+(wire[side].tight?' clamped':' loose');
   s.test='Continuity trace · Board '+path('board')+' to keypad '+path('keypad');
  }));
  const power=controls();
  if(!s.battery)button(power,'Connect battery',battery);
  if(!s.ac)button(power,'Apply transformer power',ac);
  if(s.battery||s.ac)button(power,'Isolate power',isolate);
 }
 if(s.test)note(s.test);
 title('Keypad status');
 note((s.ac?'Panel powered':s.battery?'Battery connected · awaiting AC':'Power isolated')+' · '+(circuit.powered?(circuit.communicating?'Keypad online':'Keypad powered · data unavailable'):'Keypad unpowered'));
 if(circuit.communicating){
  const display=document.createElement('output');display.textContent=readout;panel.append(display);
  const pad=controls();if(!s.flap)for(const key of '123456789*0#')button(pad,key,()=>press(key));
  if(!assessment && s.enrolled&&!s.confirmed)note('Commissioning · *8 → training code 4256 → 903 → 000 → *. Press # to clear.');
 }
 const view=controls();
 button(view,'Board detail',()=>c.focus(vec(-1.04,-.1,.1),1.65));
 button(view,'Keypad detail',()=>c.focus(vec(1.04,.12,.1),1.95));
 button(view,'Whole bench',()=>c.focus(vec(0,-.12,.1),4));
 if(assessment||s.confirmed){
  title('Commissioning report');
  for(const [ok,label] of [[s.board&&s.keypad,'Equipment mounted'],[s.routed&&s.jacket.board&&s.jacket.keypad,'Cable prepared'],[!wiringFaults(s).length,'Four clamped point-to-point circuits'],[circuit.powered,'Keypad powered'],[circuit.communicating,'Corbus data'],[s.confirmed&&circuit.communicating,'Module 01 confirmed']] as const)note((ok?'Pass · ':'Pending · ')+label);
 }
}
export {neoChecks} from './neo-engine';
