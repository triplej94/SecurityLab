import * as T from 'three'
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls.js'
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js'
import {detail} from './visual'

export type RegisterPart=(id:string,label:string,object:T.Object3D,span:number,hit?:T.Object3D)=>void
export function workbench(host:HTMLElement) {
 const renderer=new T.WebGLRenderer({antialias:true,alpha:false})
 renderer.shadowMap.enabled=true
 renderer.shadowMap.type=T.PCFSoftShadowMap
 renderer.toneMapping=T.ACESFilmicToneMapping
 renderer.toneMappingExposure=1.13
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.65))
 renderer.setClearColor(0x17252c)
 host.prepend(renderer.domElement)
 const canvas=renderer.domElement, scene=new T.Scene(), camera=new T.PerspectiveCamera(32,1,.02,100)
 // Reserve the wheel for page scrolling unless the user requests scene zoom.
 canvas.addEventListener('wheel',event=>{if(!event.ctrlKey)event.stopImmediatePropagation()},{capture:true,passive:true})
 const orbit=new OrbitControls(camera,canvas)
 orbit.enableDamping=false;orbit.minDistance=.28;orbit.maxDistance=16
 const parts=new Map<string,{label:string;object:T.Object3D;hit:T.Object3D;span:number}>()
 let inspectMode=false,selectedPart=''
 const register: RegisterPart=(id,label,object,span,hit=object)=>parts.set(id,{label,object,hit,span})
 let hits=new Map<T.Object3D,()=>void>(),drags=new Map<T.Object3D,any>()
 let active:any=null, candidate:any=null,start=new T.Vector2(),pending=false
 let dragPreview:T.Vector3|null=null
 const studio=new RoomEnvironment(),pmrem=new T.PMREMGenerator(renderer)
 scene.environment=pmrem.fromScene(studio,.035).texture
 scene.environmentIntensity=.38;studio.dispose();pmrem.dispose()
 const ray=new T.Raycaster(),pointer=new T.Vector2(),plane=new T.Plane(),normal=new T.Vector3(0,0,1)
 function render(){if(pending)return;pending=true;requestAnimationFrame(()=>{
   pending=false
   if(dragPreview&&active)active.move(dragPreview)
   dragPreview=null
   renderer.render(scene,camera)
 })}
 scene.userData.invalidate=render
 orbit.addEventListener('change',render)
 function focus(p:T.Vector3,span:number){orbit.target.copy(p);camera.position.copy(p).add(new T.Vector3(0,0,Math.max(span,span/camera.aspect)*1.86));orbit.update();render()}
 function inspectPart(id:string){
   const part=parts.get(id)
   if(!part)return
   selectedPart=id
   focus(part.object.getWorldPosition(new T.Vector3()),part.span)
   host.dispatchEvent(new CustomEvent('partfocus',{detail:id}))
 }
 function followPart(){
   const part=parts.get(selectedPart)
   if(!part){selectedPart='';return}
   const center=part.object.getWorldPosition(new T.Vector3())
   camera.position.add(center.clone().sub(orbit.target));orbit.target.copy(center);orbit.update()
 }
 function findPart(e:PointerEvent){
   scene.updateMatrixWorld(true);cast(e)
   const targets=new Map([...parts].map(([id,part])=>[part.hit,id]))
   for(const hit of ray.intersectObjects([...targets.keys()],true)){
     let target:T.Object3D|null=hit.object
     while(target){const id=targets.get(target);if(id)return id;target=target.parent}
   }
   return ''
 }
 function zoom(factor:number){
   const offset=camera.position.clone().sub(orbit.target)
   offset.setLength(T.MathUtils.clamp(offset.length()*factor,orbit.minDistance,orbit.maxDistance))
   camera.position.copy(orbit.target).add(offset);orbit.update();render()
 }
 function angle(){const distance=camera.position.distanceTo(orbit.target);camera.position.copy(orbit.target).add(new T.Vector3(.38,.22,1).normalize().multiplyScalar(distance));orbit.update();render()}
 function resize(){const w=host.clientWidth,h=host.clientHeight;if(!h||!w)return;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();render()}
 new ResizeObserver(resize).observe(host);resize();focus(new T.Vector3(),4)
 function cast(e:PointerEvent){const b=canvas.getBoundingClientRect();pointer.set((e.clientX-b.left)/b.width*2-1,1-(e.clientY-b.top)/b.height*2);ray.setFromCamera(pointer,camera)}
 function match(e:PointerEvent){scene.updateMatrixWorld(true);cast(e);for(const h of ray.intersectObjects([...hits.keys(),...drags.keys()],true)){let o:T.Object3D|null=h.object;while(o){if(hits.has(o)||drags.has(o))return {o,point:h.point};o=o.parent}}}
 canvas.addEventListener('pointerdown',e=>{if(e.button!==0)return;start.set(e.clientX,e.clientY);
 if(inspectMode){candidate=findPart(e);return}
 const m=match(e);candidate=m;if(!m)return
 if(drags.has(m.o)){orbit.enabled=false;active=drags.get(m.o);plane.setFromNormalAndCoplanarPoint(normal,m.point);canvas.setPointerCapture(e.pointerId);e.stopImmediatePropagation()}},true)
 function point(e:PointerEvent){cast(e);return ray.ray.intersectPlane(plane,new T.Vector3())}
 canvas.addEventListener('pointermove',e=>{if(active){dragPreview=point(e);render()}else canvas.style.cursor=inspectMode?(findPart(e)?'zoom-in':'grab'):(match(e)?'pointer':'grab')})
 canvas.addEventListener('pointerup',e=>{const a=active,m=candidate;active=candidate=null;orbit.enabled=true
 if(a){const p=point(e);if(p)a.end?.(p);render()}else if(m&&start.distanceTo(new T.Vector2(e.clientX,e.clientY))<6)(inspectMode?inspectPart(m):hits.get(m.o)?.())})
 function cancelDrag(){const drag=active;active=candidate=null;dragPreview=null;orbit.enabled=true;drag?.cancel?.();render()}
 canvas.addEventListener('pointercancel',e=>{
   if(!active)return
   e.stopImmediatePropagation()
   cancelDrag()
 },true)
 canvas.addEventListener('lostpointercapture',cancelDrag)
 function reset(){parts.clear();hits.clear();drags.clear();scene.traverse(o=>{if(o.userData.blenderAsset)return;if(o instanceof T.DirectionalLight)o.shadow.dispose();const m=o as T.Mesh;m.geometry?.dispose();const mats=Array.isArray(m.material)?m.material:[m.material];for(const mat of mats){if(mat){(mat as T.MeshBasicMaterial).map?.dispose();mat.dispose()}}});scene.clear()
 scene.add(new T.HemisphereLight(0xf3f6ff,0x768487,1.05))
 const l=new T.DirectionalLight(0xfff2dc,1.85);l.position.set(-2.2,3,8);l.castShadow=true
 l.shadow.mapSize.set(1024,1024);l.shadow.normalBias=.008
 Object.assign(l.shadow.camera,{left:-3.8,right:3.8,top:3.8,bottom:-3.8});l.shadow.camera.updateProjectionMatrix();scene.add(l)
 const fill=new T.DirectionalLight(0xc7e6ff,.95);fill.position.set(4,-1,3);scene.add(fill)
 const mat=new T.Mesh(new T.PlaneGeometry(30,30),new T.MeshStandardMaterial({color:0x35444a,roughness:.93}))
 mat.position.z=-.62;mat.receiveShadow=true;scene.add(mat)
 detail(scene,'work-mat.glb',[0,0,-.47],[5.6,3.65,.07])
 const grid=new T.GridHelper(20,100,0x59696b,0x455458);grid.rotation.x=Math.PI/2;grid.position.z=-.615;scene.add(grid)
 }
 return {scene,canvas,render,reset,focus,angle,zoom,orbit,register,inspectPart,followPart,parts,clearPart:()=>{selectedPart=''},setInspect:(on:boolean)=>{inspectMode=on;cancelDrag()},hit:(o:T.Object3D,f:()=>void)=>hits.set(o,f),drag:(o:T.Object3D,move:(point:T.Vector3)=>void,end?:(point:T.Vector3)=>void,cancel?:()=>void)=>drags.set(o,{move,end,cancel})}
}


