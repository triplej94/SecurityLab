import {initialIQ, iqChecks, type IQ} from './iqState'
import {initialNeo, neoChecks, type NeoState} from './neo-engine'
import {connected, routes} from './field-engine'

export type Progress = {active:string; skipped:string[]; practice:string[]}
export const newProgress=():Progress=>({active:'',skipped:[],practice:[]})
type Stage<S>={id:string; label:string; ready:(s:S)=>boolean; setup?:(s:S)=>void; reset:(s:S)=>void}
const iqKeys=['box','unpacked','loose','plateOff','plateMounted','battery','cable','seated','secured','adapter','on'] as const
const zone=(name:string,group:string)=>({name,group,chime:'Default',voice:true})
const iqDefault=initialIQ()
export const iqStages:Stage<IQ>[]=[
 {id:'iq-panel',label:'Mount and power panel',ready:s=>iqKeys.every(key=>s[key]),setup:s=>{for(const key of iqKeys)s[key]=true},
   reset:s=>{for(const key of iqKeys)s[key]=false;s.dealer=false}},
 {id:'iq-contact',label:'Mount and enroll door contact',ready:s=>iqChecks(s)[2].pass&&iqChecks(s)[3].pass,
   setup:s=>Object.assign(s,{dealer:true,identified:true,zone:zone('Front Door','10'),transmitter:'frame',magnet:'aligned'}),
   reset:s=>Object.assign(s,{identified:false,zone:null,transmitter:iqDefault.transmitter,magnet:iqDefault.magnet})},
 {id:'iq-door-test',label:'Test door',ready:s=>iqChecks(s)[4].pass,
   reset:s=>Object.assign(s,{door:false,testedOpen:false,testedClosed:false})},
 {id:'iq-motion',label:'Mount and enroll motion detector',ready:s=>iqChecks(s)[5].pass,
   setup:s=>Object.assign(s,{dealer:true,motionMounted:true,motionCover:false,motionZone:zone('Hall Motion','17')}),
   reset:s=>Object.assign(s,{motionMounted:false,motionCover:false,motionZone:null})},
 {id:'iq-walk',label:'Walk test',ready:s=>iqChecks(s)[6].pass,
   reset:s=>Object.assign(s,{motionDetected:false,motionTested:false})},
]

export const neoStages:Stage<NeoState>[]=[
 {id:'neo-mount',label:'Mount cabinet, board, and keypad',ready:s=>s.cabinet&&s.board&&s.keypad,
   setup:s=>Object.assign(s,{unpacked:true,cabinet:true,coverOpen:true,board:true,keypad:true}),
   reset:s=>Object.assign(s,{unpacked:false,cabinet:false,coverOpen:true,board:false,keypad:false,flap:true})},
 {id:'neo-corbus',label:'Wire Corbus',ready:s=>neoChecks(s)[1].pass&&neoChecks(s)[2].pass,
   setup:s=>{
     s.cable=true;s.routed=true;s.jacket={board:true,keypad:true}
     for(const [terminal,end] of s.ends.entries())for(const side of ['board','keypad'] as const)
       Object.assign(end[side],{terminal,tight:true,stripped:true,position:null})
   },
   reset:s=>{const empty=initialNeo();Object.assign(s,{cable:false,routed:false,jacket:empty.jacket,ends:empty.ends})}},
 {id:'neo-field',label:'Wire door and motion circuits',ready:s=>s.field.mounted.every(Boolean)&&s.field.aligned&&!s.field.cover&&s.field.resistor.every(Boolean)&&routes.every((_,i)=>connected(s.field,i)),
   setup:s=>Object.assign(s.field,{mounted:[true,true],aligned:true,cover:false,resistor:[true,true],ends:routes.map(route=>route[1]),tight:routes.map(()=>true)}),
   reset:s=>{const {mounted,aligned,cover,ends,tight,resistor}=initialNeo().field;Object.assign(s.field,{mounted,aligned,cover,ends,tight,resistor})}},
 {id:'neo-power',label:'Power up and confirm keypad',ready:s=>Boolean(neoChecks(s)[3].pass&&neoChecks(s)[6].pass&&s.battery),
   setup:s=>Object.assign(s,{battery:true,ac:true,inspected:true,enrolled:true,confirmed:true,lcd:'HS2LCD · Slot 01',keys:''}),
   reset:s=>Object.assign(s,{battery:false,ac:false,inspected:false,enrolled:false,confirmed:false,lcd:'',keys:'',test:''})},
 {id:'neo-program',label:'Program zones',ready:s=>s.field.types[0]==='001'&&s.field.types[1]==='005'&&s.field.partition.every(Boolean)&&!s.field.nc&&!s.field.double,
   setup:s=>Object.assign(s.field,{types:['001','005'],partition:[true,true],nc:false,double:false,section:'',entry:''}),
   reset:s=>Object.assign(s.field,{types:['000','000'],partition:[false,false],nc:true,double:false,section:'',entry:''})},
 {id:'neo-test',label:'Test door and motion',ready:s=>neoChecks(s).slice(7).every(check=>check.pass),
   reset:s=>Object.assign(s.field,{door:false,motion:false,observed:[false,false],restored:[false,false]})},
]

export function jump<S>(stages:Stage<S>[],state:S,progress:Progress,index:number){
 for(const stage of stages.slice(0,index)){
   if(stage.ready(state))continue
   stage.setup?.(state)
   if(!progress.skipped.includes(stage.id))progress.skipped.push(stage.id)
   progress.practice=progress.practice.filter(id=>id!==stage.id)
 }
 progress.active=stages[index]?.id??'review'
}

export function replay<S>(stages:Stage<S>[],state:S,progress:Progress,index:number){
 // Later work depends on this stage, so reopen it with the original parts and settings.
 const later=stages.slice(index)
 for(const stage of [...later].reverse())stage.reset(state)
 const id=stages[index].id
 progress.skipped=progress.skipped.filter(key=>key===id||!later.some(stage=>stage.id===key))
 progress.practice=[id]
 progress.active=id
}

export function stageRows<S>(stages:Stage<S>[],state:S,progress:Progress){
 const next=stages.find(stage=>!stage.ready(state)&&!progress.skipped.includes(stage.id))
 const selected=progress.active||next?.id
 return stages.map(stage=>({
   id:stage.id,label:stage.label,ready:stage.ready(state),selected:stage.id===selected,
   skipped:progress.skipped.includes(stage.id),
   practice:progress.practice.includes(stage.id)
 }))
}

export function reconcile<S>(stages:Stage<S>[],state:S,progress:Progress){
 for(const stage of stages){
   if(stage.ready(state)&&(progress.practice.includes(stage.id)||!stage.setup)){
     progress.skipped=progress.skipped.filter(id=>id!==stage.id)
     progress.practice=progress.practice.filter(id=>id!==stage.id)
   }
 }
}

