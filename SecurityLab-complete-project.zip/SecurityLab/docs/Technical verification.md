# Technical verification record

This record documents the equipment rules checked against the files in the local DSC and IQ Documentation Repository. Page numbers are one-based PDF page numbers. Manufacturer instructions establish the expected behavior. Browser test results must be recorded separately against a specific simulator build.

| Equipment and source | Pages inspected | Verification |
|---|---|---|
| Qolsys IQ Panel 5 installation manual, software 5.0 | 9, 11–12 | The wall-mount illustration shows the SmartMount plate, upper latch, lower locking screw and supply connection choices. The power-up illustration specifies connecting the battery first, connecting the supplied 12 V DC supply and holding the right-side button for three seconds. The exercise uses the supplied barrel connector. |
| Same manual | 21, 26, 60–61, 67, 84–89, 91, 93, 203 | The installer menu depends on access level. PowerG contact auto-learn uses its enrollment control and DL ID confirmation before saving. The enrollment illustration on p. 61 displays a yes/no dialog while the text calls the affirmative action OK. Group 10 is the normal entry/exit door scenario. Page 203 lists the North American contact and PIR models used in the portfolio. |
| DSC PG9945 family contact sheet D-304590, distributor copy | 1 | The mounting illustration identifies the reed-switch marking and magnet orientation. The sheet recommends a maximum installed gap of 6 mm, and separately tabulates approach/removal distances by axis and material. It shows the fixed transmitter, moving magnet, cover, battery and enrollment control. |
| DSC PowerSeries Neo reference manual v1.35, 29009812R005, distributor copy | 21–25, 41, 253 | Power-up follows completed wiring, standby battery, then AC. Battery alone does not start the controller. Corbus uses RED/BLK for power and YEL/GRN for data. Page 253 is the North American family circuit drawing including HS2032. |
| DSC HS2LCD family Installation Instructions v1.2, 29009683R001 | 2–3 | The model family is compatible with Neo, including HS2032. Page 2 includes the mounting diagram and the R/B/Y/G and P/Z terminal strip. Page 3 confirms battery before AC and describes entry to numerical installer programming. |

## Interpretation for the labs

- **Contact placement.** Score the installed closed-door alignment against the recommended 6 mm installation allowance. A simplified simulated switching distance is an educational assumption. The door and transmitter need separate transforms so movement changes their relationship.
- **Enrollment.** Use the receiving panel's menu sequence. The PG9945 instruction sheet also describes a numerical DSC host procedure. That procedure belongs to the DSC host. The IQ5 lesson uses the touchscreen path in the IQ5 manual.
- **Wire identity.** Continuity follows a conductor between its two endpoints. Colour can guide the technician. Evaluate the connected terminal functions even when a trainee chooses a different colour at both ends. Exposed ends, insertion and tightening determine whether the simulator recognizes a joint.
- **Power and communication.** A correctly powered keypad may lack a valid data pair. Model the supply, data link, and enrollment as distinct facts. The lab can show communication loss and recovery without claiming an exact hardware LCD message, timing, or protocol trace.
- **Keypad enrollment.** The controller reference distinguishes first-keypad enrollment from enrollment of additional modules. Section 903 confirms module enrollment/supervision. Treat simulated installer credentials as fictional. Reserve firmware-specific additional sections for separately sourced lessons.
- **Model fidelity.** The original room, panel screen artwork, interior geometry, terminations, strip lengths, screw movements, tool snapping, fault models and timing may be approximations. The documents reviewed do not validate every mesh coordinate or every animation.

## Provenance and distribution

The private register inventories the source tree recursively, using existing document digests to retain known source links. It indexes topics in extractable PDF text by page, lists files without usable text, and retains unknown revisions or regions as unconfirmed. A hit on a keyword is a candidate page for review. It provides no assurance that an entire document applies to a particular lesson.

The hosted evidence index contains short original descriptions, model names, document identifiers, and page references. Keep the private register, manual scans, document excerpts, distributor images, original research notes, and machine-specific paths outside the website's static output and hosted source checkout.

