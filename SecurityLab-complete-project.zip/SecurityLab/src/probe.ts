import * as T from 'three'
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js'
import React from 'react'
import {createRoot} from 'react-dom/client'
import {workbench} from './bench'
const bench=workbench(document.querySelector('#bench')!)
bench.reset()
const root=createRoot(document.querySelector('#touch')!)
const state=JSON.parse(localStorage.getItem('securitylab.calibration')||'{"x":0,"y":0,"bend":0,"connected":false}')
const metal=new T.MeshStandardMaterial({color:0xe4ae68})
const terminal=new T.Mesh(new T.BoxGeometry(.26,.26,.2),metal);terminal.position.set(1.1,.4,0);bench.scene.add(terminal)
const end=new T.Mesh(new T.SphereGeometry(.105),metal);bench.scene.add(end)
const grip=new T.Mesh(new T.SphereGeometry(.13),new T.MeshStandardMaterial({color:0x82939e}));bench.scene.add(grip)
const wire=new T.Mesh(new T.BufferGeometry(),new T.MeshStandardMaterial({color:0xf47c45}));bench.scene.add(wire)
let loaded=false
function sync(){end.position.set(state.x,state.y,.1);grip.position.set(-.5,state.bend,.1);wire.geometry.dispose()
wire.geometry=new T.TubeGeometry(new T.CatmullRomCurve3([new T.Vector3(-1.4,-.4,.1),grip.position.clone(),end.position.clone()]),30,.04,10,false)
localStorage.setItem('securitylab.calibration',JSON.stringify(state));root.render(React.createElement('section',{},React.createElement('p',{},(loaded?'GLB loaded':'Loading model')+' · '+(state.connected?'Connected':'Open circuit')),React.createElement('button',{onClick:()=>{Object.assign(state,{x:0,y:0,bend:0,connected:false});sync()}},'Reset calibration'),'Drag the copper end onto the terminal. Drag the gray handle to route the cable.'));bench.render()}
bench.drag(end,p=>{state.x=p.x;state.y=p.y;state.connected=false;sync()},p=>{state.connected=p.distanceTo(terminal.position)<.35;if(state.connected){state.x=1.1;state.y=.4}sync()})
bench.drag(grip,p=>{state.bend=p.y;sync()})
bench.hit(terminal,()=>{root.render(React.createElement('button',{onClick:sync},'Terminal inspection · '+(state.connected?'continuity':'open')+' · Back'))})
new GLTFLoader().load('/assets/PG9945.glb',g=>{g.scene.scale.setScalar(9);g.scene.position.set(-1.5,.55,0);bench.scene.add(g.scene);loaded=true;sync()})
new T.TextureLoader().load('/calibration.svg',map=>{const tile=new T.Mesh(new T.PlaneGeometry(.9,.35),new T.MeshBasicMaterial({map,transparent:true}));tile.position.set(1.1,.78,.01);bench.scene.add(tile);bench.render()})
sync()
