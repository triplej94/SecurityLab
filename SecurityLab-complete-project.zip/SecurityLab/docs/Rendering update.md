# Equipment rendering update

The workbench loads original GLB meshes built with Blender 5.3 from the scripts in design/. The geometry follows the local IQ5 front/interior diagrams, PG9945 installation drawing, HS2032 board photo and HS2LCD keypad photo. The source images are local visual references. The delivered meshes and labels were generated for the simulator.

Use the Close-up selector to inspect a panel, contact, keypad or terminal strip. Angled view tips the camera around the current part to show connector depth and surface relief. Fit view returns to the entire installation. Expand bench gives the scene the full page width. Equipment explorer provides individually rotatable front and rear models.

The Neo service terminal strip and wireless contact mounting area are enlarged for practice. Housing and board component geometry, surface colors and small markings are illustrative. The simulator continues to use its model-specific programming and wiring rules to evaluate the exercises.

The four PNGs in Visual checks show the running browser workbench and explorer with example equipment states.
